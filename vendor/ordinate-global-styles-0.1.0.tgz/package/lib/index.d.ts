export declare enum Mode {
    Light = "light",
    Dark = "dark",
    System = "system"
}
export declare enum Density {
    Comfortable = "comfortable",
    Compact = "compact"
}
/**
 * The voice of a page. `console` is the default for applications; the others are for websites.
 */
export declare enum Style {
    Console = "console",
    Editorial = "editorial",
    Studio = "studio",
    Shopfront = "shopfront"
}
export declare enum Revision {
    V2026_1 = "2026.1",
    V2026_2 = "2026.2"
}
/**
 * Sets light, dark or system mode on `target`. Passing `null` returns to the default, light.
 */
export declare function applyMode(mode: Mode | null, target?: Element): void;
/**
 * Pins every component inside `target` to one design revision. Passing `null`
 * returns to the default, the oldest supported revision.
 */
export declare function applyRevision(revision: Revision | null, target?: Element): void;
/**
 * Sets comfortable or compact density on `target`. Compact tightens padding and
 * control heights. Passing `null` returns to the default, comfortable.
 */
export declare function applyDensity(density: Density | null, target?: Element): void;
/**
 * Sets the style of every component inside `target`: `console` for applications, or
 * `editorial`, `studio` or `shopfront` for websites. A style sits on top of the pinned
 * revision. Passing `null` or `console` returns to the default.
 */
export declare function applyStyle(style: Style | null, target?: Element): void;
/**
 * Turns off component animations, on top of the user's reduced-motion setting.
 */
export declare function disableMotion(disabled: boolean, target?: Element): void;
