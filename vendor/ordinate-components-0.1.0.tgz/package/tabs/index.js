// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalTabs } from './internal';
export default function Tabs({ tabs, activeTabId, onChange, variant = 'default', ariaLabel, ariaLabelledby, disableContentPaddings = false, i18nStrings, ...props }) {
    return (_jsx(InternalTabs, { ...getBaseProps(props), tabs: tabs, activeTabId: activeTabId, onChange: onChange, variant: variant, ariaLabel: ariaLabel, ariaLabelledby: ariaLabelledby, disableContentPaddings: disableContentPaddings, i18nStrings: i18nStrings }));
}
