import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import clsx from 'clsx';
import { InternalButton } from '../button/internal';
import { InternalIcon } from '../icon/internal';
import { fireNonCancelableEvent } from '../internal/events';
import { InternalLiveRegion } from '../live-region/internal';
import { InternalSpinner } from '../spinner/internal';
import styles from './styles.css.js';
export const typeIcons = {
    success: 'status-positive',
    error: 'status-negative',
    warning: 'status-warning',
    info: 'status-info',
    'in-progress': 'status-in-progress',
};
function StatusIcon({ type, loading, ariaLabel }) {
    if (!loading) {
        return _jsx(InternalIcon, { name: typeIcons[type], ariaLabel: ariaLabel });
    }
    return (_jsx("span", { role: ariaLabel ? 'img' : undefined, "aria-label": ariaLabel, "aria-hidden": ariaLabel ? undefined : 'true', children: _jsx(InternalSpinner, {}) }));
}
/**
 * One notification, drawn as a numbered note in the margin. The icon, header and content sit in a live
 * region, so the message is read when it appears and again when its text changes, as when an operation
 * in progress succeeds. The number only repeats the item's place in the list, so it is not read.
 */
export function Flash({ item, position, statusIconAriaLabel, dismissLabel, hidden }) {
    const type = item.type ?? 'info';
    return (_jsxs("li", { className: clsx(styles.flash, styles[`type-${type}`]), hidden: hidden, children: [_jsxs("span", { className: styles.marker, "aria-hidden": "true", children: [_jsx("span", { className: styles['marker-number'], children: position }), _jsx("span", { className: styles['marker-leader'] })] }), _jsxs("div", { className: styles.note, children: [_jsxs("div", { className: styles['note-main'], children: [_jsx(InternalLiveRegion, { assertive: item.ariaRole === 'alert', children: _jsxs("div", { className: styles.body, children: [_jsx("span", { className: styles['status-icon'], children: _jsx(StatusIcon, { type: type, loading: Boolean(item.loading), ariaLabel: statusIconAriaLabel }) }), _jsxs("div", { className: styles.message, children: [item.header && _jsx("div", { className: styles.header, children: item.header }), item.content && _jsx("div", { className: styles.content, children: item.content })] })] }) }), item.action && _jsx("div", { className: styles['action-slot'], children: item.action })] }), item.dismissible && (_jsx("div", { className: styles.dismiss, children: _jsx(InternalButton, { variant: "icon", formAction: "none", ariaLabel: dismissLabel, iconSvg: _jsx(InternalIcon, { name: "close" }), onClick: () => fireNonCancelableEvent(item.onDismiss, null) }) }))] })] }));
}
