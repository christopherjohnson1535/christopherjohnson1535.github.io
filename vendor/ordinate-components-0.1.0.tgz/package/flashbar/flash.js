import { jsx as _jsx } from "react/jsx-runtime";
import clsx from 'clsx';
import { InternalAlert } from '../alert/internal';
import styles from './styles.css.js';
/**
 * One notification, drawn as Alert's margin note. The margin, header and content are read to screen readers
 * when the note appears and again when its text changes, as when an operation that is underway completes.
 */
export function Flash({ item, statusIconAriaLabel, underwayLabel, dismissLabel, hidden }) {
    const loading = Boolean(item.loading);
    return (_jsx("li", { className: clsx(styles.flash, styles[`type-${item.type}`], loading && styles.underway), hidden: hidden, children: _jsx(InternalAlert, { className: styles.note, type: item.type, header: item.header, action: item.action, dismissible: item.dismissible, dismissAriaLabel: dismissLabel, onDismiss: item.onDismiss, statusIconAriaLabel: statusIconAriaLabel, loading: loading, caption: loading ? underwayLabel : undefined, announce: item.ariaRole === 'alert' ? 'assertive' : 'polite', children: item.content }) }));
}
