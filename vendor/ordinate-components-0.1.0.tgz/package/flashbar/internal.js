import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { useId, useState } from 'react';
import clsx from 'clsx';
import { useInternalI18n } from '../internal/i18n/context';
import { Flash } from './flash';
import { NotificationBar } from './notification-bar';
import styles from './styles.css.js';
const iconLabelKeys = {
    success: 'successIconAriaLabel',
    error: 'errorIconAriaLabel',
    warning: 'warningIconAriaLabel',
    info: 'infoIconAriaLabel',
    'in-progress': 'inProgressIconAriaLabel',
};
const countKeys = {
    success: 'successCount',
    error: 'errorCount',
    warning: 'warningCount',
    info: 'infoCount',
    'in-progress': 'inProgressCount',
};
// A collapsed stack draws at most this many sheet edges under the first item, however many it holds.
const maxStackEdges = 2;
export function InternalFlashbar({ items, stackItems = false, i18nStrings, className, ...rest }) {
    const i18n = useInternalI18n('flashbar');
    const [stackExpanded, setStackExpanded] = useState(false);
    const listId = useId();
    const isStacked = stackItems && items.length > 1;
    const isCollapsed = isStacked && !stackExpanded;
    const iconLabel = (item) => {
        const key = iconLabelKeys[item.type ?? 'info'];
        return item.statusIconAriaLabel ?? i18n(key, i18nStrings?.[key]);
    };
    const countText = (type, count) => i18nStrings?.itemCountText?.(type, count) ?? i18n(countKeys[type], undefined, { count });
    return (_jsxs("div", { ...rest, className: clsx(styles.root, className), children: [_jsx("ul", { id: listId, className: styles.list, "aria-label": i18n('ariaLabel', i18nStrings?.ariaLabel), children: items.map((item, index) => (_jsx(Flash, { item: item, position: index + 1, hidden: isCollapsed && index > 0, statusIconAriaLabel: iconLabel(item), dismissLabel: i18n('dismissLabel', item.dismissLabel) }, item.id ?? index))) }), isCollapsed && (_jsx("div", { className: styles['stack-edges'], "aria-hidden": "true", children: Array.from({ length: Math.min(items.length - 1, maxStackEdges) }, (_, index) => (_jsx("div", { className: styles['stack-edge'] }, index))) })), isStacked && (_jsx(NotificationBar, { items: items, expanded: stackExpanded, controlsId: listId, text: i18n('notificationBarText', i18nStrings?.notificationBarText), countText: countText, onToggle: () => setStackExpanded(!stackExpanded) }))] }));
}
