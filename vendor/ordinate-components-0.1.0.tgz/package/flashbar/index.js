// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { warnOnce } from '../internal/logging';
import { InternalFlashbar } from './internal';
const legacyTypes = {
    info: 'note',
    success: 'complete',
    warning: 'caution',
    error: 'fault',
    'in-progress': 'note',
};
function resolveItem(item) {
    const type = item.type ?? 'note';
    if (!Object.prototype.hasOwnProperty.call(legacyTypes, type)) {
        return { ...item, type: type };
    }
    const current = legacyTypes[type];
    if (type === 'in-progress') {
        warnOnce('Flashbar', 'The type "in-progress" is now a "note" with `loading` set. The old name stops working in the next major version.');
        return { ...item, type: current, loading: item.loading ?? true };
    }
    warnOnce('Flashbar', `The type "${type}" is now called "${current}". The old name stops working in the next major version.`);
    return { ...item, type: current };
}
export default function Flashbar({ items, stackItems = false, i18nStrings, ...props }) {
    return (_jsx(InternalFlashbar, { ...getBaseProps(props), items: items.map(resolveItem), stackItems: stackItems, i18nStrings: i18nStrings }));
}
