// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalFlashbar } from './internal';
export default function Flashbar({ items, stackItems = false, i18nStrings, ...props }) {
    return _jsx(InternalFlashbar, { ...getBaseProps(props), items: items, stackItems: stackItems, i18nStrings: i18nStrings });
}
