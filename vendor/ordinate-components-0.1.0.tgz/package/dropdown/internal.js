import { jsx as _jsx } from "react/jsx-runtime";
import { Dropdown } from '../internal/components/dropdown';
import { fireNonCancelableEvent } from '../internal/events';
import styles from './styles.css.js';
export function InternalDropdown({ open, trigger, content, header, footer, onOutsideClick, onEscape, minWidth = 'trigger', maxWidth = 'none', ariaRole, ariaLabel, ariaLabelledby, ...rest }) {
    return (_jsx("div", { ...rest, className: styles.root, onKeyDown: event => {
            if (open && event.key === 'Escape') {
                // Closes only the dropdown, not a modal around it.
                event.preventDefault();
                event.stopPropagation();
                fireNonCancelableEvent(onEscape, null);
            }
        }, children: _jsx(Dropdown, { open: open, trigger: trigger, header: header, footer: footer, onOutsideClick: () => fireNonCancelableEvent(onOutsideClick, null), minWidth: minWidth, maxWidth: maxWidth, ariaRole: ariaRole, ariaLabel: ariaLabel, ariaLabelledby: ariaLabelledby, children: content }) }));
}
