// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalDropdown } from './internal';
export default function Dropdown({ open, trigger, content, header, footer, onOutsideClick, onEscape, minWidth = 'trigger', maxWidth = 'none', ariaRole, ariaLabel, ariaLabelledby, ...props }) {
    return (_jsx(InternalDropdown, { ...getBaseProps(props), open: open, trigger: trigger, content: content, header: header, footer: footer, onOutsideClick: onOutsideClick, onEscape: onEscape, minWidth: minWidth, maxWidth: maxWidth, ariaRole: ariaRole, ariaLabel: ariaLabel, ariaLabelledby: ariaLabelledby }));
}
