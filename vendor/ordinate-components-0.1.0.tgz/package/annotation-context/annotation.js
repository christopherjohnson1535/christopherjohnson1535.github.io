import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { useEffect, useId, useRef } from 'react';
import { InternalAlert } from '../alert/internal';
import { InternalButton } from '../button/internal';
import { FloatingPanel } from '../internal/components/floating-panel';
import { wrapTabFocus } from '../internal/focus';
import { useInternalI18n } from '../internal/i18n/context';
import styles from './styles.css.js';
/**
 * The popover of one tutorial step, anchored to its hotspot. Mount it with a `key` per step,
 * so focus moves into the new step when the user goes back or forward.
 */
export function Annotation({ id, context, tutorialStep, trigger, direction, onDismiss }) {
    const i18n = useInternalI18n('annotation-context');
    const panelRef = useRef(null);
    const titleId = useId();
    const { currentTutorial, steps, i18nStrings, takeFocusRequest } = context;
    const { step, index, taskIndex, indexInTask, taskStepCount } = tutorialStep;
    const task = currentTutorial?.tasks[taskIndex];
    const isFirst = index === 0;
    const isLast = index === steps.length - 1;
    useEffect(() => {
        if (takeFocusRequest('annotation')) {
            trigger.current?.scrollIntoView?.({ block: 'nearest', inline: 'nearest' });
            panelRef.current?.focus({ preventScroll: true });
        }
    }, [takeFocusRequest, trigger]);
    const handleKeyDown = (event) => {
        if (event.key === 'Escape') {
            event.preventDefault();
            event.stopPropagation();
            onDismiss();
            return;
        }
        wrapTabFocus(event, event.currentTarget);
    };
    const taskTitle = i18n('taskTitle', task && i18nStrings?.taskTitle?.(taskIndex + 1, task.title), {
        taskNumber: taskIndex + 1,
        taskTitle: task?.title ?? '',
    });
    const stepCounter = i18n('stepCounterText', i18nStrings?.stepCounterText?.(indexInTask + 1, taskStepCount), {
        stepNumber: indexInTask + 1,
        totalStepCount: taskStepCount,
    });
    return (_jsxs(FloatingPanel, { ref: panelRef, id: id, trigger: trigger, preferredSide: direction, role: "dialog", "aria-labelledby": titleId, tabIndex: -1, className: styles.annotation, onKeyDown: handleKeyDown, children: [_jsxs("span", { className: styles['header-row'], children: [_jsx("span", { className: styles['task-title'], children: taskTitle }), _jsx("span", { className: styles.dismiss, children: _jsx(InternalButton, { variant: "icon", formAction: "none", iconName: "close", ariaLabel: i18n('labelDismissAnnotation', i18nStrings?.labelDismissAnnotation), onClick: onDismiss }) })] }), _jsx("span", { id: titleId, className: styles['step-title'], children: step.title }), _jsx("span", { className: styles.content, children: step.content }), step.warningAlert && (_jsx("span", { className: styles.warning, children: _jsx(InternalAlert, { type: "warning", children: step.warningAlert }) })), _jsxs("span", { className: styles.footer, children: [_jsx("span", { className: styles['step-counter'], children: stepCounter }), _jsxs("span", { className: styles.actions, children: [!isFirst && (_jsx(InternalButton, { className: styles['previous-button'], variant: "link", formAction: "none", onClick: () => context.goToStep(index - 1, 'previous'), children: i18n('previousButtonText', i18nStrings?.previousButtonText) })), isLast ? (_jsx(InternalButton, { className: styles['finish-button'], variant: "primary", formAction: "none", onClick: () => context.finish(), children: i18n('finishButtonText', i18nStrings?.finishButtonText) })) : (_jsx(InternalButton, { className: styles['next-button'], variant: "primary", formAction: "none", onClick: () => context.goToStep(index + 1, 'next'), children: i18n('nextButtonText', i18nStrings?.nextButtonText) }))] })] })] }));
}
