// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalTableRoot } from './internal';
export default function TableRoot({ children, caption, ariaLabel, ariaLabelledby, ariaDescribedby, ariaRowcount, stickyHeader = false, stickyHeaderVerticalOffset = 0, stripedRows = false, wrapLines = false, contentDensity = 'comfortable', layout = 'auto', ...props }) {
    return (_jsx(InternalTableRoot, { ...getBaseProps(props), caption: caption, ariaLabel: ariaLabel, ariaLabelledby: ariaLabelledby, ariaDescribedby: ariaDescribedby, ariaRowcount: ariaRowcount, stickyHeader: stickyHeader, stickyHeaderVerticalOffset: stickyHeaderVerticalOffset, stripedRows: stripedRows, wrapLines: wrapLines, contentDensity: contentDensity, layout: layout, children: children }));
}
