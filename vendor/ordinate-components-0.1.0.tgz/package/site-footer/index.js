// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalSiteFooter } from './internal';
export default function SiteFooter({ brand, columns, children, legal, tone = 'default', headingLevel = 2, navigationAriaLabel, onFollow, ...props }) {
    return (_jsx(InternalSiteFooter, { ...getBaseProps(props), brand: brand, columns: columns, legal: legal, tone: tone, headingLevel: headingLevel, navigationAriaLabel: navigationAriaLabel, onFollow: onFollow, children: children }));
}
