// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalToken } from './internal';
export default function Token({ label, labelTag, description, tags, icon, variant = 'normal', disabled = false, readOnly = false, onDismiss, dismissLabel, tooltipContent, ...props }) {
    return (_jsx(InternalToken, { ...getBaseProps(props), label: label, labelTag: labelTag, description: description, tags: tags, icon: icon, variant: variant, disabled: disabled, readOnly: readOnly, onDismiss: onDismiss, dismissLabel: dismissLabel, tooltipContent: tooltipContent }));
}
