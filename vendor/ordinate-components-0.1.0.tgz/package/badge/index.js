// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { warnOnce } from '../internal/logging';
import { InternalBadge } from './internal';
const colorToTone = {
    grey: 'neutral',
    blue: 'note',
    green: 'complete',
    red: 'fault',
    'severity-critical': 'critical',
    'severity-high': 'high',
    'severity-medium': 'medium',
    'severity-low': 'low',
    'severity-neutral': 'neutral',
};
export default function Badge({ tone, color, children, ...props }) {
    if (!tone && color) {
        warnOnce('Badge', `\`color\` is now \`tone\`; "${color}" is "${colorToTone[color]}". It stops working in the next major version.`);
    }
    return (_jsx(InternalBadge, { ...getBaseProps(props), tone: tone ?? (color ? colorToTone[color] : 'neutral'), children: children }));
}
