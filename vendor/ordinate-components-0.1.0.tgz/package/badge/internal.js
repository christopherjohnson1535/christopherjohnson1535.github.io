import { jsx as _jsx } from "react/jsx-runtime";
import clsx from 'clsx';
import styles from './styles.css.js';
export function InternalBadge({ color = 'grey', children, className, ...rest }) {
    return (_jsx("span", { ...rest, className: clsx(styles.badge, styles[`color-${color}`], className), children: children }));
}
