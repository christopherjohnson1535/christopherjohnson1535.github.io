import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import clsx from 'clsx';
import styles from './styles.css.js';
/**
 * A short label in mono capitals with a key square before it. The square carries the tone; the text stays in
 * ink. The square is drawing only, so the label reads the same to everyone.
 */
export function InternalBadge({ tone = 'neutral', children, className, ...rest }) {
    return (_jsxs("span", { ...rest, className: clsx(styles.badge, styles[`tone-${tone}`], className), children: [_jsx("span", { className: styles.key, "aria-hidden": "true" }), children] }));
}
