import { jsx as _jsx } from "react/jsx-runtime";
import clsx from 'clsx';
import styles from './styles.css.js';
const variantTags = {
    'key-label': 'div',
    'value-large': 'span',
    'inline-code': 'code',
};
const spacingSides = ['horizontal', 'vertical', 'top', 'right', 'bottom', 'left'];
function spacingClassNames(property, value) {
    if (value === undefined) {
        return [];
    }
    if (typeof value === 'string') {
        return [styles[`${property}-${value}`]];
    }
    return spacingSides.filter(side => value[side]).map(side => styles[`${property}-${side}-${value[side]}`]);
}
export function InternalBox({ variant = 'div', tagOverride, display, margin, padding, textAlign, float, fontSize, fontWeight, color, className, children, ...rest }) {
    const Tag = (tagOverride ?? variantTags[variant] ?? variant);
    return (_jsx(Tag, { ...rest, className: clsx(styles.root, styles[`variant-${variant}`], fontSize && styles[`font-size-${fontSize}`], fontWeight && styles[`font-weight-${fontWeight}`], color && styles[`color-${color}`], display && styles[`display-${display}`], textAlign && styles[`text-align-${textAlign}`], float && styles[`float-${float}`], spacingClassNames('margin', margin), spacingClassNames('padding', padding), className), children: children }));
}
