// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalBox } from './internal';
export default function Box({ variant = 'div', tagOverride, display, margin, padding, textAlign, float, fontSize, fontWeight, color, children, ...props }) {
    return (_jsx(InternalBox, { ...getBaseProps(props), variant: variant, tagOverride: tagOverride, display: display, margin: margin, padding: padding, textAlign: textAlign, float: float, fontSize: fontSize, fontWeight: fontWeight, color: color, children: children }));
}
