import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { useEffect, useId, useRef, useState } from 'react';
import clsx from 'clsx';
import { InternalButton } from '../button/internal';
import { getHiddenTokenCount } from '../internal/components/token-list';
import { fireNonCancelableEvent } from '../internal/events';
import { useInternalI18n } from '../internal/i18n/context';
import { FileToken } from './file-token';
import { formatFileLastModified, formatFileSize, useFormatLocale } from './format';
import styles from './styles.css.js';
export function InternalFileTokenGroup({ items, onDismiss, showFileSize = false, showFileLastModified = false, showFileThumbnail = false, limit, alignment = 'horizontal', readOnly = false, ariaLabel, i18nStrings, onEmptied, className, ...rest }) {
    const i18n = useInternalI18n('file-token-group');
    const locale = useFormatLocale();
    const listId = useId();
    const [expanded, setExpanded] = useState(false);
    const listRef = useRef(null);
    const buttonRefs = useRef([]);
    const pendingFocus = useRef(null);
    const hiddenCount = getHiddenTokenCount(items.length, limit);
    const visible = hiddenCount > 0 && !expanded ? items.slice(0, limit) : items;
    // Removing the focused token would drop focus to the page, so it moves to the next remove button,
    // or the previous one when the last token went.
    useEffect(() => {
        const index = pendingFocus.current;
        if (index === null) {
            return;
        }
        pendingFocus.current = null;
        if (visible.length === 0) {
            onEmptied?.();
            return;
        }
        buttonRefs.current[Math.min(index, visible.length - 1)]?.focus();
    });
    const dismiss = (fileIndex) => {
        if (listRef.current?.contains(document.activeElement)) {
            pendingFocus.current = fileIndex;
        }
        fireNonCancelableEvent(onDismiss, { fileIndex });
    };
    const formatSize = i18nStrings?.formatFileSize ?? ((size) => formatFileSize(size, locale));
    const formatDate = i18nStrings?.formatFileLastModified ?? ((date) => formatFileLastModified(date, locale));
    const errorIconAriaLabel = i18n('errorIconAriaLabel', i18nStrings?.errorIconAriaLabel);
    const warningIconAriaLabel = i18n('warningIconAriaLabel', i18nStrings?.warningIconAriaLabel);
    const removeLabel = (fileIndex, fileName) => i18nStrings?.removeFileAriaLabel?.(fileIndex, fileName) ??
        i18n('removeFileAriaLabel', undefined, { fileNumber: fileIndex + 1, fileName });
    return (_jsxs("div", { ...rest, className: clsx(styles.root, styles[`alignment-${alignment}`], className), children: [items.length > 0 && (_jsx("ul", { ref: listRef, id: listId, className: styles.list, "aria-label": ariaLabel, children: visible.map((item, index) => (_jsx("li", { className: styles.item, "aria-busy": item.loading ? 'true' : undefined, children: _jsx(FileToken, { item: item, showFileSize: showFileSize, showFileLastModified: showFileLastModified, showFileThumbnail: showFileThumbnail, readOnly: readOnly, formatFileSize: formatSize, formatFileLastModified: formatDate, errorIconAriaLabel: errorIconAriaLabel, warningIconAriaLabel: warningIconAriaLabel, dismissLabel: removeLabel(index, item.file.name), onDismiss: onDismiss ? () => dismiss(index) : undefined, dismissButtonRef: button => {
                            buttonRefs.current[index] = button;
                        } }) }, `${index}-${item.file.name}`))) })), hiddenCount > 0 && (_jsx(InternalButton, { className: styles.toggle, variant: "link", formAction: "none", ariaExpanded: expanded, ariaControls: listId, onClick: () => setExpanded(current => !current), children: expanded
                    ? i18n('limitShowFewer', i18nStrings?.limitShowFewer)
                    : i18n('limitShowMore', i18nStrings?.limitShowMore, { count: hiddenCount }) }))] }));
}
