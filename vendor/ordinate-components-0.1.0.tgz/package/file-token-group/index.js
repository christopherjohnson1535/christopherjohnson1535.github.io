// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalFileTokenGroup } from './internal';
export default function FileTokenGroup({ items, onDismiss, showFileSize = false, showFileLastModified = false, showFileThumbnail = false, limit, alignment = 'horizontal', readOnly = false, ariaLabel, i18nStrings, ...props }) {
    return (_jsx(InternalFileTokenGroup, { ...getBaseProps(props), items: items, onDismiss: onDismiss, showFileSize: showFileSize, showFileLastModified: showFileLastModified, showFileThumbnail: showFileThumbnail, limit: limit, alignment: alignment, readOnly: readOnly, ariaLabel: ariaLabel, i18nStrings: i18nStrings }));
}
