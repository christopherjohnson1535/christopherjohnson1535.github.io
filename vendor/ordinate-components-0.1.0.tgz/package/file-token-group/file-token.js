import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { useEffect, useRef } from 'react';
import clsx from 'clsx';
import { InternalIcon } from '../icon/internal';
import { InternalSpinner } from '../spinner/internal';
import { InternalToken } from '../token/internal';
import { InternalTruncatedText } from '../truncated-text/internal';
import styles from './styles.css.js';
function isImage(file) {
    return file.type.startsWith('image/');
}
// An object URL keeps the file in memory until it is revoked, so each one lives only as long as its
// preview. The URL goes straight onto the image, as it never takes part in rendering.
function ImagePreview({ file }) {
    const imageRef = useRef(null);
    useEffect(() => {
        const image = imageRef.current;
        if (!image || typeof URL.createObjectURL !== 'function') {
            return;
        }
        const url = URL.createObjectURL(file);
        image.src = url;
        return () => {
            URL.revokeObjectURL(url);
            image.removeAttribute('src');
        };
    }, [file]);
    return _jsx("img", { ref: imageRef, className: styles['thumbnail-image'], alt: "" });
}
function Thumbnail({ file, loading }) {
    let content;
    if (loading) {
        content = _jsx(InternalSpinner, { className: styles.spinner });
    }
    else if (isImage(file)) {
        content = _jsx(ImagePreview, { file: file });
    }
    else {
        content = _jsx(InternalIcon, { className: styles['thumbnail-icon'], name: "file" });
    }
    return _jsx("span", { className: styles.thumbnail, children: content });
}
export function FileToken({ item, showFileSize, showFileLastModified, showFileThumbnail, readOnly, formatFileSize, formatFileLastModified, errorIconAriaLabel, warningIconAriaLabel, dismissLabel, onDismiss, dismissButtonRef, }) {
    const { file, loading = false, errorText, warningText } = item;
    const showWarning = Boolean(warningText) && !errorText;
    const hasMetadata = showFileSize || showFileLastModified;
    const label = (_jsxs("span", { className: styles.file, children: [showFileThumbnail ? (_jsx(Thumbnail, { file: file, loading: loading })) : (loading && _jsx(InternalSpinner, { className: styles.spinner })), _jsxs("span", { className: styles.details, children: [_jsx("span", { className: styles['file-name'], dir: "auto", children: _jsx(InternalTruncatedText, { children: file.name }) }), hasMetadata && (_jsxs("span", { className: styles.metadata, children: [showFileSize && (_jsx("span", { className: styles['file-size'], dir: "auto", children: formatFileSize(file.size) })), showFileLastModified && (_jsx("span", { className: styles['file-last-modified'], dir: "auto", children: formatFileLastModified(new Date(file.lastModified)) }))] }))] })] }));
    return (_jsxs(_Fragment, { children: [_jsx(InternalToken, { className: clsx(styles.token, errorText && styles.invalid, showWarning && styles.warning), label: label, readOnly: readOnly, dismissLabel: dismissLabel, onDismiss: onDismiss, dismissButtonRef: dismissButtonRef }), errorText && (_jsxs("div", { className: styles['error-text'], children: [_jsx(InternalIcon, { className: styles['message-icon'], name: "fault", size: "small", ariaLabel: errorIconAriaLabel }), _jsx("span", { children: errorText })] })), showWarning && (_jsxs("div", { className: styles['warning-text'], children: [_jsx(InternalIcon, { className: styles['message-icon'], name: "caution", size: "small", ariaLabel: warningIconAriaLabel }), _jsx("span", { children: warningText })] }))] }));
}
