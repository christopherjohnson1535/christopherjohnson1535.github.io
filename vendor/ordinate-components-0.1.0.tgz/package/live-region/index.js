// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalLiveRegion } from './internal';
export default function LiveRegion({ children, assertive = false, hidden = false, tagName = 'div', ...props }) {
    return (_jsx(InternalLiveRegion, { ...getBaseProps(props), assertive: assertive, hidden: hidden, tagName: tagName, children: children }));
}
