// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import React from 'react';
import { getBaseProps } from '../internal/base-component';
import { InternalActionCard } from './internal';
const ActionCard = React.forwardRef(({ header, description, children, iconName, kind = 'neutral', href, target, onClick, onFollow, disabled = false, ariaLabel, ...props }, ref) => (_jsx(InternalActionCard, { ...getBaseProps(props), ref: ref, header: header, description: description, iconName: iconName, kind: kind, href: href, target: target, onClick: onClick, onFollow: onFollow, disabled: disabled, ariaLabel: ariaLabel, children: children })));
ActionCard.displayName = 'ActionCard';
export default ActionCard;
