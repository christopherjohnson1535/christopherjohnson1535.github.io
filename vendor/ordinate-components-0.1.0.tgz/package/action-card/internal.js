import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React, { useId, useImperativeHandle, useRef } from 'react';
import clsx from 'clsx';
import { InternalIcon } from '../icon/internal';
import { CropMarks } from '../internal/components/crop-marks';
import { Leader } from '../internal/components/leader';
import { fireCancelableEvent, fireNonCancelableEvent } from '../internal/events';
import { isPlainLeftClick } from '../internal/link-click';
import styles from './styles.css.js';
export const InternalActionCard = React.forwardRef(({ header, description, children, iconName, kind = 'neutral', href, target, onClick, onFollow, disabled = false, ariaLabel, ...rest }, ref) => {
    const elementRef = useRef(null);
    useImperativeHandle(ref, () => ({ focus: () => elementRef.current?.focus() }));
    const baseId = useId();
    const headerId = `${baseId}header`;
    const descriptionId = `${baseId}description`;
    const content = (_jsxs(_Fragment, { children: [_jsx(CropMarks, { kind: kind, interactive: !disabled }), iconName && (_jsx("span", { className: styles.icon, children: _jsx(InternalIcon, { name: iconName, size: "medium", variant: disabled ? 'disabled' : 'normal' }) })), _jsxs("span", { className: styles.text, children: [_jsx("span", { id: headerId, className: styles.header, children: header }), description && (_jsx("span", { id: descriptionId, className: styles.description, children: description })), children && _jsx("span", { className: styles.content, children: children })] }), _jsx("span", { className: styles.arrow, "aria-hidden": "true", children: _jsx(Leader, { className: styles.leader }) })] }));
    const common = {
        ...rest,
        ref: elementRef,
        className: clsx(styles.root, disabled && styles.disabled),
        'aria-label': ariaLabel,
        'aria-labelledby': ariaLabel ? undefined : headerId,
        'aria-describedby': description ? descriptionId : undefined,
    };
    if (href === undefined) {
        return (_jsx("button", { ...common, type: "button", disabled: disabled, onClick: () => fireNonCancelableEvent(onClick, null), children: content }));
    }
    if (disabled) {
        return (_jsx("a", { ...common, role: "link", "aria-disabled": "true", children: content }));
    }
    return (_jsx("a", { ...common, href: href, target: target, rel: target === '_blank' ? 'noopener noreferrer' : undefined, onClick: event => {
            if (isPlainLeftClick(event)) {
                fireCancelableEvent(onFollow, { href, target }, event);
            }
        }, children: content }));
});
