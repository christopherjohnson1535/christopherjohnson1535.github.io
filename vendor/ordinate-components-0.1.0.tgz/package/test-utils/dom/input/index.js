// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import ButtonWrapper from '../button';
import { ComponentWrapper } from '../core';
import styles from '../../../input/styles.css.js';
class InputWrapper extends ComponentWrapper {
    findNativeInput() {
        return this.findByClassName(styles.input);
    }
    /**
     * The clear button of a `search` input. It is only there while the input has a value.
     */
    findClearButton() {
        const element = this.getElement().querySelector(`.${styles['clear-button']}`);
        return element ? new ButtonWrapper(element) : null;
    }
    findSearchIcon() {
        return this.findByClassName(styles['search-icon']);
    }
    findInlineLabel() {
        return this.findByClassName(styles['inline-label']);
    }
    /**
     * Types a new value into the input, firing `onChange`.
     */
    setInputValue(value) {
        this.findNativeInput().setNativeValue(value);
    }
    getInputValue() {
        return this.findNativeInput().getElement().value;
    }
    isDisabled() {
        return this.findNativeInput().getElement().disabled;
    }
    isReadOnly() {
        return this.findNativeInput().getElement().readOnly;
    }
    focus() {
        this.findNativeInput().focus();
    }
    blur() {
        this.findNativeInput().blur();
    }
}
InputWrapper.rootSelector = `.${styles.root}`;
export default InputWrapper;
