// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import ButtonWrapper from '../button';
import { ComponentWrapper } from '../core';
import styles from '../../../app-layout-toolbar/styles.css.js';
class AppLayoutToolbarWrapper extends ComponentWrapper {
    findNavigationToggle() {
        const element = this.getElement().querySelector(`.${styles['navigation-toggle']} button`);
        return element ? new ButtonWrapper(element) : null;
    }
    findBreadcrumbs() {
        return this.findByClassName(styles.breadcrumbs);
    }
    findDrawerTriggers() {
        return Array.from(this.getElement().querySelectorAll(`.${styles.drawers} button[data-trigger-id]`), element => new ButtonWrapper(element));
    }
    findDrawerTriggerById(id) {
        return this.findDrawerTriggers().find(trigger => trigger.getElement().dataset.triggerId === id) ?? null;
    }
}
AppLayoutToolbarWrapper.rootSelector = `.${styles.root}`;
export default AppLayoutToolbarWrapper;
