// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import ButtonWrapper from '../button';
import styles from '../../../toggle-button/styles.css.js';
class ToggleButtonWrapper extends ButtonWrapper {
    isPressed() {
        return this.getElement().getAttribute('aria-pressed') === 'true';
    }
}
ToggleButtonWrapper.rootSelector = `.${styles['toggle-button']}`;
export default ToggleButtonWrapper;
