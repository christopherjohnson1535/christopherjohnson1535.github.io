// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../media/styles.css.js';
class MediaWrapper extends ComponentWrapper {
    findImage() {
        return this.findByClassName(styles.image);
    }
    /**
     * Returns the box that holds the content passed as `children`.
     */
    findContent() {
        return this.findByClassName(styles.slot);
    }
    findPlaceholderText() {
        return this.findByClassName(styles['placeholder-text']);
    }
    /**
     * Whether the frame is empty and drawn as a placeholder.
     */
    isPlaceholder() {
        return this.element.classList.contains(styles.placeholder);
    }
}
MediaWrapper.rootSelector = `.${styles.root}`;
export default MediaWrapper;
