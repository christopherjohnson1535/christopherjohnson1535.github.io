// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../plate/styles.css.js';
class PlateWrapper extends ComponentWrapper {
    findMedia() {
        return this.findByClassName(styles.media);
    }
    findLabel() {
        return this.findByClassName(styles.label);
    }
    /**
     * Returns the heading that holds the title.
     */
    findTitle() {
        return this.findByClassName(styles.title);
    }
    /**
     * Returns the title link, when the plate has an `href`.
     */
    findTitleLink() {
        return this.findTitle().find('a');
    }
    findMeta() {
        return this.findByClassName(styles.meta);
    }
    findDescription() {
        return this.findByClassName(styles.description);
    }
}
PlateWrapper.rootSelector = `.${styles.root}`;
export default PlateWrapper;
