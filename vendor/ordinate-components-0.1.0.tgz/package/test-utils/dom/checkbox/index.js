// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { AbstractSwitchWrapper } from '../internal/abstract-switch';
import styles from '../../../checkbox/styles.css.js';
class CheckboxWrapper extends AbstractSwitchWrapper {
    isIndeterminate() {
        return this.findNativeInput().getElement().indeterminate;
    }
}
CheckboxWrapper.rootSelector = `.${styles.root}`;
export default CheckboxWrapper;
