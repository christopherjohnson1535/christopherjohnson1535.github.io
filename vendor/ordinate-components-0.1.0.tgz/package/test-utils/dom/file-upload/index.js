import { ComponentWrapper } from '../core';
import FileDropzoneWrapper from '../file-dropzone';
import FileInputWrapper from '../file-input';
import FileTokenGroupWrapper from '../file-token-group';
import { dragFilesOver } from '../internal/file-transfer';
import styles from '../../../file-upload/styles.css.js';
// The button, the drop zone and the token group are found with the generated `findFileInput`,
// `findFileDropzone` and `findFileTokenGroup`. The drop zone is only there while files are dragged
// over the page, and replaces the button meanwhile.
class FileUploadWrapper extends ComponentWrapper {
    /**
     * Returns the file tokens shown, without the ones hidden beyond `tokenLimit`.
     */
    findFileTokens() {
        return this.findComponent(FileTokenGroupWrapper)?.findFileTokens() ?? [];
    }
    /**
     * Returns the token of the file at this position, counting from 1.
     */
    findFileToken(position) {
        return this.findFileTokens()[position - 1] ?? null;
    }
    /**
     * Returns the button that shows or hides the files beyond `tokenLimit`.
     */
    findTokenToggle() {
        return this.findComponent(FileTokenGroupWrapper)?.findTokenToggle() ?? null;
    }
    findConstraint() {
        return this.findByClassName(styles.constraint);
    }
    findError() {
        return this.findByClassName(styles.error);
    }
    findWarning() {
        return this.findByClassName(styles.warning);
    }
    /**
     * Chooses files as if the user had picked them in the file chooser, firing `onChange`.
     */
    selectFiles(files) {
        this.findComponent(FileInputWrapper).selectFiles(files);
    }
    /**
     * Drags files over the page, which swaps the button for the drop zone, and drops them on the zone,
     * firing `onChange`.
     */
    dropFiles(files) {
        dragFilesOver(this, files);
        this.findComponent(FileDropzoneWrapper).dropFiles(files);
    }
}
FileUploadWrapper.rootSelector = `.${styles.root}`;
export default FileUploadWrapper;
