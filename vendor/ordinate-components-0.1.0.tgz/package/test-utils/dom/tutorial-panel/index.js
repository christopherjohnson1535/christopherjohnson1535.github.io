// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import AlertWrapper from '../alert';
import ButtonWrapper from '../button';
import { ComponentWrapper, ElementWrapper } from '../core';
import LinkWrapper from '../link';
import helpPanelStyles from '../../../help-panel/styles.css.js';
import styles from '../../../tutorial-panel/styles.css.js';
export class TutorialWrapper extends ElementWrapper {
    findTitle() {
        return this.findByClassName(styles['tutorial-title']);
    }
    findDescription() {
        return this.findByClassName(styles['tutorial-description']);
    }
    /**
     * The badge shown once the tutorial is completed.
     */
    findCompletedBadge() {
        return this.findByClassName(styles['completed-badge']);
    }
    findPrerequisitesAlert() {
        return this.findByClassName(styles.prerequisites)?.findComponent(AlertWrapper) ?? null;
    }
    /**
     * The start button, which restarts a completed tutorial.
     */
    findStartButton() {
        return this.findComponent(ButtonWrapper, `.${styles['start-button']}`);
    }
    findLearnMoreLink() {
        return this.findComponent(LinkWrapper, `.${styles['learn-more-link']}`);
    }
}
export class TutorialTaskWrapper extends ElementWrapper {
    findTitle() {
        return this.findByClassName(styles['task-title']);
    }
    /**
     * The task's progress in words: not started, in progress or done.
     */
    findStatus() {
        return this.findByClassName(styles['task-status']);
    }
    findTotalSteps() {
        return this.findByClassName(styles['total-steps']);
    }
    findSteps() {
        return this.findAllByClassName(styles.step);
    }
    /**
     * The step the user is on, or `null` when it is in another task.
     */
    findCurrentStep() {
        return this.findByClassName(styles['step-in-progress']);
    }
}
class TutorialPanelWrapper extends ComponentWrapper {
    /**
     * The panel heading: the list title, or the title of the current tutorial.
     */
    findHeader() {
        return this.findByClassName(helpPanelStyles.header);
    }
    findTutorials() {
        return this.findAllByClassName(styles.tutorial).map(tutorial => new TutorialWrapper(tutorial.getElement()));
    }
    findDownloadLink() {
        return this.findComponent(ButtonWrapper, `.${styles['download-link']}`);
    }
    findFeedbackLink() {
        return this.findComponent(LinkWrapper, `.${styles['feedback-link']}`);
    }
    /**
     * The tasks of the current tutorial, or none while the list is shown.
     */
    findTasks() {
        return this.findAllByClassName(styles.task).map(task => new TutorialTaskWrapper(task.getElement()));
    }
    findExitButton() {
        return this.findComponent(ButtonWrapper, `.${styles['exit-button']}`);
    }
    /**
     * The completion screen, shown while the current tutorial is completed.
     */
    findCompletionScreen() {
        return this.findByClassName(styles.completion);
    }
    findLoadingStatus() {
        return this.findByClassName(helpPanelStyles.loading);
    }
}
TutorialPanelWrapper.rootSelector = `.${styles.root}`;
export default TutorialPanelWrapper;
