// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../measure/styles.css.js';
class MeasureWrapper extends ComponentWrapper {
    findLabel() {
        return this.findByClassName(styles.label);
    }
    /**
     * The whole reading as it is read: the value, the maximum and the unit, as in "20 of 32 nodes".
     */
    findReading() {
        return this.findByClassName(styles.reading);
    }
    findValue() {
        return this.findByClassName(styles.value);
    }
    findDescription() {
        return this.findByClassName(styles.description);
    }
    /**
     * The ruler, drawn when `max` is set. It is hidden from screen readers.
     */
    findRuler() {
        return this.findByClassName(styles.ruler);
    }
    /**
     * The filled run of the ruler.
     */
    findRun() {
        return this.findByClassName(styles.run);
    }
    findTicks() {
        return this.findAllByClassName(styles.tick);
    }
    findLimitMark() {
        return this.findByClassName(styles['limit-mark']);
    }
    findLimitLabel() {
        return this.findByClassName(styles['limit-label']);
    }
}
MeasureWrapper.rootSelector = `.${styles.root}`;
export default MeasureWrapper;
