// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../icon/styles.css.js';
class IconWrapper extends ComponentWrapper {
}
IconWrapper.rootSelector = `.${styles.icon}`;
export default IconWrapper;
