// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import AnnotationContextWrapper from '../annotation-context';
import { ComponentWrapper } from '../core';
import styles from '../../../hotspot/styles.css.js';
class HotspotWrapper extends ComponentWrapper {
    getHotspotId() {
        return this.getElement().dataset.hotspotId ?? '';
    }
    /**
     * The marker button, or `null` while no step of the current task points at the hotspot.
     */
    findMarker() {
        return this.findByClassName(styles.marker);
    }
    /**
     * Whether the marker belongs to the current step, which makes it pulse.
     */
    isCurrent() {
        return this.findByClassName(styles['marker-current']) !== null;
    }
    /**
     * The open annotation of the current step, when it points at this hotspot.
     */
    findAnnotation() {
        return this.findComponent(AnnotationContextWrapper);
    }
    findContent() {
        return this.findByClassName(styles.content);
    }
}
HotspotWrapper.rootSelector = `.${styles.root}`;
export default HotspotWrapper;
