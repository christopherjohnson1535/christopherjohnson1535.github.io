// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../panel-layout/styles.css.js';
class PanelLayoutWrapper extends ComponentWrapper {
    findPanelContent() {
        return this.find(`:scope > .${styles.panel}`);
    }
    findMainContent() {
        return this.find(`:scope > .${styles.main}`);
    }
    /**
     * Returns the resize handle, present only when the layout is resizable and shows both panes.
     */
    findResizeHandle() {
        return this.find(`:scope > .${styles.handle}`);
    }
}
PanelLayoutWrapper.rootSelector = `.${styles.root}`;
export default PanelLayoutWrapper;
