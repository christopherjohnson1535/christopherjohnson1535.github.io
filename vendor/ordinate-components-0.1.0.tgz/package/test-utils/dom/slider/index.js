// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../slider/styles.css.js';
class SliderWrapper extends ComponentWrapper {
    findNativeInput() {
        return this.findByClassName(styles.input);
    }
    /**
     * Returns the tick marks, including the longer ones at reference values.
     */
    findTickMarks() {
        return this.findAllByClassName(styles.tick);
    }
    /**
     * Returns the value labels below the track: the minimum, the reference values and the maximum, in order.
     */
    findLabels() {
        return [
            this.findByClassName(styles['label-min']),
            ...this.findAllByClassName(styles['label-reference']),
            this.findByClassName(styles['label-max']),
        ];
    }
    getValue() {
        return Number(this.findNativeInput().getElement().value);
    }
    /**
     * Moves the slider to a value, firing `onChange` as dragging would.
     */
    setValue(value) {
        this.findNativeInput().setNativeValue(String(value));
    }
    isDisabled() {
        return this.findNativeInput().getElement().disabled;
    }
}
SliderWrapper.rootSelector = `.${styles.root}`;
export default SliderWrapper;
