// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import ButtonWrapper from '../button';
import { ComponentWrapper } from '../core';
import styles from '../../../modal/styles.css.js';
class ModalWrapper extends ComponentWrapper {
    isVisible() {
        return this.getElement().hasAttribute('open');
    }
    findHeader() {
        return this.findByClassName(styles.heading);
    }
    /**
     * The reference above the title, set with `reference`.
     */
    findReference() {
        return this.findByClassName(styles.reference);
    }
    findContent() {
        return this.findByClassName(styles.content);
    }
    findFooter() {
        return this.findByClassName(styles.footer);
    }
    /**
     * The close button in the header, or `null` when `hideDismissButton` is set.
     */
    findDismissButton() {
        const element = this.getElement().querySelector(`.${styles['close-button']}`);
        return element ? new ButtonWrapper(element) : null;
    }
    /**
     * Fires the dialog's cancel event, as pressing Escape does.
     */
    pressEscape() {
        this.fireEvent(new Event('cancel', { cancelable: true }));
    }
}
ModalWrapper.rootSelector = `.${styles.dialog}`;
export default ModalWrapper;
