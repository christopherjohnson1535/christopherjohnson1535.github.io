// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../story-card/styles.css.js';
class StoryCardWrapper extends ComponentWrapper {
    /**
     * Returns the heading that holds the title.
     */
    findTitle() {
        return this.findByClassName(styles.title);
    }
    /**
     * Returns the title link, when the card has an `href`.
     */
    findTitleLink() {
        return this.findTitle().find('a');
    }
    findSummary() {
        return this.findByClassName(styles.summary);
    }
    findKicker() {
        return this.findByClassName(styles.kicker);
    }
    findNumber() {
        return this.findByClassName(styles.number);
    }
    findMeta() {
        return this.findByClassName(styles.meta);
    }
    findMedia() {
        return this.findByClassName(styles.media);
    }
}
StoryCardWrapper.rootSelector = `.${styles.root}`;
export default StoryCardWrapper;
