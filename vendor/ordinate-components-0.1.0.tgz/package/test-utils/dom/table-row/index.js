// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import selectionStyles from '../../../internal/components/table-selection-control/styles.css.js';
import cellStyles from '../../../table-body-cell/styles.css.js';
import styles from '../../../table-row/styles.css.js';
class TableRowWrapper extends ComponentWrapper {
    /**
     * The cells of the row, header cells included.
     */
    findCells() {
        return this.findAll(':scope > td, :scope > th');
    }
    /**
     * The checkbox or radio button that selects the row.
     */
    findSelectionControl() {
        return this.find(`:scope > * > .${selectionStyles.root} input`);
    }
    /**
     * The circled tag of the row, such as "S1".
     */
    findRowTag() {
        return this.find(`:scope > .${cellStyles['row-tag']} > .${cellStyles.tag}`);
    }
    isSelected() {
        return this.getElement().classList.contains(styles.selected);
    }
}
TableRowWrapper.rootSelector = `.${styles.root}`;
export default TableRowWrapper;
