// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../item-card/styles.css.js';
class ItemCardWrapper extends ComponentWrapper {
    findHeader() {
        return this.findByClassName(styles.header);
    }
    findDescription() {
        return this.findByClassName(styles.description);
    }
    findContent() {
        return this.findByClassName(styles.content);
    }
    findFooter() {
        return this.findByClassName(styles.footer);
    }
    findActions() {
        return this.findByClassName(styles.actions);
    }
    findMedia() {
        return this.findByClassName(styles.media);
    }
    /**
     * Returns the slot that holds the card's checkbox or radio button.
     */
    findSelectionControl() {
        return this.findByClassName(styles.selection);
    }
    isSelected() {
        return this.element.classList.contains(styles.selected);
    }
    isDisabled() {
        return this.element.classList.contains(styles.disabled);
    }
}
ItemCardWrapper.rootSelector = `.${styles.root}`;
export default ItemCardWrapper;
