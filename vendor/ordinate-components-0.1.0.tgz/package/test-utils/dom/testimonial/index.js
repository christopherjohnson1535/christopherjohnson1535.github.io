// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../testimonial/styles.css.js';
class TestimonialWrapper extends ComponentWrapper {
    /**
     * Returns the `<blockquote>` with the customer's words.
     */
    findQuote() {
        return this.findByClassName(styles.quote);
    }
    findName() {
        return this.findByClassName(styles.name);
    }
    findDetail() {
        return this.findByClassName(styles.detail);
    }
    findMedia() {
        return this.findByClassName(styles.media);
    }
}
TestimonialWrapper.rootSelector = `.${styles.root}`;
export default TestimonialWrapper;
