// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import ButtonWrapper from '../button';
import { ComponentWrapper } from '../core';
import ExpandableSectionWrapper from '../expandable-section';
import formStyles from '../../../form/styles.css.js';
import styles from '../../../wizard/styles.css.js';
function wrapButton(parent, className) {
    const element = parent.findByClassName(className);
    return element ? new ButtonWrapper(element.getElement()) : null;
}
/**
 * One item of a checklist sheet.
 */
export class WizardItemWrapper extends ComponentWrapper {
    findTitle() {
        return this.findByClassName(styles['item-title']);
    }
    /**
     * The one line shown while the item is folded: its summary once checked, or its description before.
     */
    findSummary() {
        return this.findByClassName(styles['item-summary']);
    }
    /**
     * The content of the item, shown while it is open.
     */
    findContent() {
        return this.findByClassName(styles.content);
    }
    /**
     * The item's error, while it has one.
     */
    findError() {
        return this.findByClassName(styles['item-error-text']);
    }
    /**
     * The button that reopens a checked item.
     */
    findChangeButton() {
        return wrapButton(this, styles['change-button']);
    }
    /**
     * The button that opens an item not opened yet.
     */
    findOpenButton() {
        return wrapButton(this, styles['open-button']);
    }
    /**
     * The button that moves on to the next item, shown in the open item.
     */
    findNextButton() {
        return wrapButton(this, styles['next-button']);
    }
    isActive() {
        return this.getElement().classList.contains(styles['item-active']);
    }
    /**
     * Whether the item has been opened and left without an error.
     */
    isChecked() {
        const classes = this.getElement().classList;
        return classes.contains(styles['item-visited']) && !classes.contains(styles['item-has-error']);
    }
    isOptional() {
        return this.getElement().classList.contains(styles['item-optional']);
    }
}
WizardItemWrapper.rootSelector = `.${styles.item}`;
class WizardWrapper extends ComponentWrapper {
    wrapButton(className) {
        return wrapButton(this, className);
    }
    /**
     * The heading area of the active step: its title, info and description. On a checklist, the open
     * item's heading.
     */
    findHeader() {
        return this.findByClassName(styles['step-header']);
    }
    /**
     * The content of the active step, or of the open item of a checklist.
     */
    findContent() {
        return this.findByClassName(styles.content);
    }
    /**
     * The error of the active step, while it has one. On a checklist, the open item's error.
     */
    findError() {
        return this.findActiveItem()?.findError() ?? this.findByClassName(formStyles['error-text']);
    }
    findSecondaryActions() {
        return this.findByClassName(styles['secondary-actions']) ?? this.findByClassName(formStyles['secondary-actions']);
    }
    /**
     * The items of a checklist, in order.
     */
    findItems() {
        return this.findAllComponents(WizardItemWrapper);
    }
    /**
     * The item of a checklist with this number, counted from 1.
     */
    findItem(stepNumber) {
        return this.findItems()[stepNumber - 1] ?? null;
    }
    /**
     * The open item of a checklist.
     */
    findActiveItem() {
        return this.findItems().find(item => item.isActive()) ?? null;
    }
    /**
     * The line in a checklist's footer that counts the checked items and the open errors.
     */
    findStatusLine() {
        return this.findByClassName(styles['status-line']);
    }
    /**
     * The side column of a checklist.
     */
    findAside() {
        return this.findByClassName(styles.aside);
    }
    findCancelButton() {
        return this.wrapButton(styles['cancel-button']);
    }
    /**
     * The previous button. It is not shown on the first step.
     */
    findPreviousButton() {
        return this.wrapButton(styles['previous-button']);
    }
    /**
     * The next button, or the submit button on the last step. On a checklist, the submit button in the
     * footer.
     */
    findPrimaryButton() {
        return this.wrapButton(styles['primary-button']);
    }
    /**
     * The skip button, shown with `allowSkipTo` when optional steps follow the active one.
     */
    findSkipToButton() {
        return this.wrapButton(styles['skip-to-button']);
    }
    /**
     * The disclosure that holds the navigation when the wizard is too narrow to show it beside the step.
     */
    findNavigationToggle() {
        const element = this.findByClassName(styles['navigation-toggle']);
        return element ? new ExpandableSectionWrapper(element.getElement()) : null;
    }
    /**
     * The steps in the navigation, in order.
     */
    findNavigationItems() {
        return this.findAllByClassName(styles['navigation-item']);
    }
    /**
     * The step in the navigation with this number, counted from 1.
     */
    findNavigationItem(stepNumber) {
        return this.findNavigationItems()[stepNumber - 1] ?? null;
    }
    /**
     * The buttons in the navigation for the steps that can be chosen, in order.
     */
    findNavigationLinks() {
        return this.findAllByClassName(styles['navigation-link']);
    }
    findActiveNavigationItem() {
        return this.findNavigationItems().find(item => item.find('[aria-current="step"]') !== null) ?? null;
    }
}
WizardWrapper.rootSelector = `.${styles.root}`;
export default WizardWrapper;
