// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../breadcrumb-group/styles.css.js';
import dropdownStyles from '../../../internal/components/dropdown/styles.css.js';
class BreadcrumbGroupWrapper extends ComponentWrapper {
    findVisibleList() {
        return this.find(`:scope > .${styles.list}`);
    }
    /**
     * Returns the visible items, in order, as links. The current page is not a link and is
     * returned by `findCurrentPage`. Items collapsed behind the ellipsis are not included.
     */
    findBreadcrumbLinks() {
        return this.findVisibleList().findAll(`:scope > li > .${styles.link}`);
    }
    /**
     * Returns the visible link at a position, counting from 1.
     */
    findBreadcrumbLink(index) {
        return this.findBreadcrumbLinks()[index - 1] ?? null;
    }
    findCurrentPage() {
        return this.findVisibleList().find(`.${styles.current}`);
    }
    /**
     * Returns the button that shows the collapsed items, when items are collapsed.
     */
    findEllipsis() {
        return this.findVisibleList().find(`.${styles['expand-button']}`);
    }
    findDropdown() {
        return this.findVisibleList().find(`.${dropdownStyles.popup}`);
    }
    /**
     * Returns the links of the collapsed items while their menu is open.
     */
    findDropdownLinks() {
        return this.findAllByClassName(styles['menu-link']);
    }
}
BreadcrumbGroupWrapper.rootSelector = `.${styles.root}`;
export default BreadcrumbGroupWrapper;
