// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../tabs/styles.css.js';
class TabsWrapper extends ComponentWrapper {
    /**
     * Returns every tab, in order, including disabled ones.
     */
    findTabLinks() {
        return this.findAllByClassName(styles.tab);
    }
    /**
     * Returns the tab at a position, counting from 1.
     */
    findTabLinkByIndex(index) {
        return this.findTabLinks()[index - 1] ?? null;
    }
    findTabLinkById(id) {
        return this.findTabLinks().find(tab => tab.getElement().getAttribute('data-tab-id') === id) ?? null;
    }
    findActiveTab() {
        return this.findByClassName(styles['tab-active']);
    }
    /**
     * Returns the panel of the active tab.
     */
    findTabContent() {
        return this.find(`.${styles.panel}:not([hidden])`);
    }
    findExtrasByTabId(id) {
        return (this.findAllByClassName(styles['tab-extras']).find(extras => extras.getElement().getAttribute('data-tab-id') === id) ?? null);
    }
    findDismissButtonByTabId(id) {
        return this.findExtrasByTabId(id)?.findByClassName(styles['dismiss-button']) ?? null;
    }
    findActionByTabId(id) {
        return this.findExtrasByTabId(id)?.findByClassName(styles.action) ?? null;
    }
    /**
     * Returns the button that scrolls toward the first tab, while the tabs overflow.
     */
    findScrollLeftButton() {
        return this.findByClassName(styles['scroll-left']);
    }
    /**
     * Returns the button that scrolls toward the last tab, while the tabs overflow.
     */
    findScrollRightButton() {
        return this.findByClassName(styles['scroll-right']);
    }
}
TabsWrapper.rootSelector = `.${styles.root}`;
export default TabsWrapper;
