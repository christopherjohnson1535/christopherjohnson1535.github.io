// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper, ElementWrapper } from '../core';
import styles from '../../../schematic/styles.css.js';
export class SchematicPartWrapper extends ElementWrapper {
    isShown() {
        return this.getElement().classList.contains(styles.shown);
    }
    isAccent() {
        return this.getElement().classList.contains(styles.accent);
    }
    isDimmed() {
        return this.getElement().classList.contains(styles.dimmed);
    }
    isPending() {
        return this.getElement().classList.contains(styles.pending);
    }
    isRemoved() {
        return this.getElement().classList.contains(styles.removed);
    }
    findLabel() {
        return this.findByClassName(styles.label);
    }
    findDetail() {
        return this.findByClassName(styles.detail);
    }
}
class SchematicWrapper extends ComponentWrapper {
    /**
     * Returns the `<svg>` that holds the drawing.
     */
    findDrawing() {
        return this.findByClassName(styles.drawing);
    }
    /**
     * Returns a part by its ID, shown or hidden.
     */
    findPart(id) {
        const element = this.find(`.${styles.part}[data-part-id="${id.replace(/"/g, '\\"')}"]`);
        return element ? new SchematicPartWrapper(element.getElement()) : null;
    }
    /**
     * Returns a wire by its ID, shown or hidden.
     */
    findWire(id) {
        const element = this.find(`.${styles.wire}[data-wire-id="${id.replace(/"/g, '\\"')}"]`);
        return element ? new SchematicPartWrapper(element.getElement()) : null;
    }
    /**
     * Returns the parts the current scene shows.
     */
    findShownParts() {
        return this.findAll(`.${styles.part}.${styles.shown}`).map(w => new SchematicPartWrapper(w.getElement()));
    }
}
SchematicWrapper.rootSelector = `.${styles.root}`;
export default SchematicWrapper;
