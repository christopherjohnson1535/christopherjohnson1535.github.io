// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../drawer/styles.css.js';
class DrawerWrapper extends ComponentWrapper {
    findHeader() {
        return this.findByClassName(styles.header);
    }
    /**
     * The reference above the title, set with `reference`.
     */
    findReference() {
        return this.findByClassName(styles.reference);
    }
    findContent() {
        return this.findByClassName(styles.content);
    }
    findFooter() {
        return this.findByClassName(styles.footer);
    }
    /**
     * The loading indicator and its text, shown while `loading` is set.
     */
    findLoadingStatus() {
        return this.findByClassName(styles.loading);
    }
}
DrawerWrapper.rootSelector = `.${styles.root}`;
export default DrawerWrapper;
