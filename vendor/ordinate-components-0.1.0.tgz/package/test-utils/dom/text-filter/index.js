import { ComponentWrapper } from '../core';
import InputWrapper from '../input';
import styles from '../../../text-filter/styles.css.js';
class TextFilterWrapper extends ComponentWrapper {
    get input() {
        return this.findComponent(InputWrapper);
    }
    findNativeInput() {
        return this.input.findNativeInput();
    }
    /**
     * The clear button. It is only there while the filter has text.
     */
    findClearButton() {
        return this.input.findClearButton();
    }
    /**
     * The result count, while the filter has text and `countText` is set.
     */
    findResultsCount() {
        const count = this.findByClassName(styles.count);
        return count && count.getText() !== '' ? count : null;
    }
    /**
     * Types new text into the filter, firing `onChange` and, after a pause, `onDelayedChange`.
     */
    setInputValue(value) {
        this.input.setInputValue(value);
    }
    focus() {
        this.input.focus();
    }
}
TextFilterWrapper.rootSelector = `.${styles.root}`;
export default TextFilterWrapper;
