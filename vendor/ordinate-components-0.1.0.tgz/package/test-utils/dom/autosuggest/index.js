import { OptionListWrapper } from '../internal/option-list';
import styles from '../../../autosuggest/styles.css.js';
import inputStyles from '../../../input/styles.css.js';
import optionListStyles from '../../../internal/components/option-list/styles.css.js';
class AutosuggestWrapper extends OptionListWrapper {
    findNativeInput() {
        return this.findByClassName(inputStyles.input);
    }
    /**
     * Returns the option that uses the text as typed, while the list is open.
     */
    findEnteredTextOption() {
        return this.findByClassName(optionListStyles['option-extra']);
    }
    isOpen() {
        return this.findNativeInput().getElement().getAttribute('aria-expanded') === 'true';
    }
    /**
     * Types a new value into the input, firing `onChange` and opening the list.
     */
    setInputValue(value) {
        this.findNativeInput().setNativeValue(value);
    }
    focus() {
        this.findNativeInput().focus();
    }
    /**
     * Clicks a suggestion in the open list. A number picks the option at that index, counting from 1 and
     * including the entered text option. A string picks the suggestion with that value.
     */
    selectSuggestion(indexOrValue) {
        this.findOption(indexOrValue).click();
    }
}
AutosuggestWrapper.rootSelector = `.${styles.root}`;
export default AutosuggestWrapper;
