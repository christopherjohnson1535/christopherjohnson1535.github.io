// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import ButtonWrapper from '../button';
import { ComponentWrapper } from '../core';
import styles from '../../../error-boundary/styles.css.js';
/**
 * Wraps the fallback. An error boundary adds no element of its own until its content throws, so
 * `findErrorBoundary()` returns `null` while the content renders normally.
 */
class ErrorBoundaryWrapper extends ComponentWrapper {
    findHeader() {
        return this.findByClassName(styles.header);
    }
    findDescription() {
        return this.findByClassName(styles.description);
    }
    findRefreshButton() {
        const element = this.getElement().querySelector(`.${styles['refresh-button']}`);
        return element ? new ButtonWrapper(element) : null;
    }
    findFeedbackLink() {
        return this.findByClassName(styles['feedback-link']);
    }
}
ErrorBoundaryWrapper.rootSelector = `.${styles.root}`;
export default ErrorBoundaryWrapper;
