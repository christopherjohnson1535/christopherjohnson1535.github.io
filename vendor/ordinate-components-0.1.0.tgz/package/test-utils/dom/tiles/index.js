// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import RadioButtonWrapper from '../radio-button';
import styles from '../../../tiles/styles.css.js';
class TilesWrapper extends ComponentWrapper {
    findItems() {
        return this.findAllByClassName(styles.tile);
    }
    /**
     * Returns the tile with the given value.
     */
    findItemByValue(value) {
        return this.findItems().find(item => item.find('input')?.getElement().value === value) ?? null;
    }
    findSelectedItem() {
        return this.findByClassName(styles.selected);
    }
    findRadioButtons() {
        return this.findAllComponents(RadioButtonWrapper);
    }
    /**
     * Returns the image of a tile, if it has one.
     */
    findItemImage(item) {
        return item.findByClassName(styles.image);
    }
    getSelectedValue() {
        return this.find('input[type="radio"]:checked')?.getElement().value ?? null;
    }
}
TilesWrapper.rootSelector = `.${styles.root}`;
export default TilesWrapper;
