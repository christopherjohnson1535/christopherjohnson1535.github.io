// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import ButtonWrapper from '../button';
import { ComponentWrapper } from '../core';
import styles from '../../../prompt-input/styles.css.js';
class PromptInputWrapper extends ComponentWrapper {
    findNativeTextarea() {
        return this.findByClassName(styles.textarea);
    }
    /**
     * The button that sends the prompt.
     */
    findActionButton() {
        return new ButtonWrapper(this.getElement().querySelector(`.${styles['action-button']}`));
    }
    /**
     * The slot above the text, set with `secondaryContent`.
     */
    findSecondaryContent() {
        return this.findByClassName(styles['secondary-content']);
    }
    /**
     * The slot below the text, set with `secondaryActions`.
     */
    findSecondaryActions() {
        return this.findByClassName(styles['secondary-actions']);
    }
    /**
     * Types a new value into the prompt, firing `onChange`.
     */
    setTextareaValue(value) {
        this.findNativeTextarea().setNativeValue(value);
    }
    getTextareaValue() {
        return this.findNativeTextarea().getElement().value;
    }
    /**
     * Presses Enter in the prompt, which sends it unless `shiftKey` is set.
     */
    pressEnter(init = {}) {
        this.findNativeTextarea().keydown('Enter', init);
    }
    isDisabled() {
        return this.findNativeTextarea().getElement().disabled;
    }
    isReadOnly() {
        return this.findNativeTextarea().getElement().readOnly;
    }
    focus() {
        this.findNativeTextarea().focus();
    }
}
PromptInputWrapper.rootSelector = `.${styles.root}`;
export default PromptInputWrapper;
