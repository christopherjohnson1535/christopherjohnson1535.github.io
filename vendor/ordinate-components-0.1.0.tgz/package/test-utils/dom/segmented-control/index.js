// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../segmented-control/styles.css.js';
class SegmentedControlWrapper extends ComponentWrapper {
    /**
     * Returns every segment, in order, including disabled ones.
     */
    findSegments() {
        return this.findAllByClassName(styles.segment);
    }
    findSegmentById(id) {
        return this.findSegments().find(segment => segment.getElement().dataset.segmentId === id) ?? null;
    }
    findSelectedSegment() {
        return this.findByClassName(styles.selected);
    }
}
SegmentedControlWrapper.rootSelector = `.${styles.root}`;
export default SegmentedControlWrapper;
