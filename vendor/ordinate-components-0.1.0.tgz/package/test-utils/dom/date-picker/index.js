// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import ButtonWrapper from '../button';
import CalendarWrapper from '../calendar';
import { ComponentWrapper } from '../core';
import DateInputWrapper from '../date-input';
import styles from '../../../date-picker/styles.css.js';
import dropdownStyles from '../../../internal/components/dropdown/styles.css.js';
class DatePickerWrapper extends ComponentWrapper {
    findDateInput() {
        return this.findComponent(DateInputWrapper);
    }
    findNativeInput() {
        return this.findDateInput().findNativeInput();
    }
    findOpenCalendarButton() {
        return new ButtonWrapper(this.findByClassName(styles['open-button']).getElement());
    }
    /**
     * Returns the popup while the calendar is open.
     */
    findDropdown() {
        return this.findByClassName(dropdownStyles.popup);
    }
    /**
     * Returns the calendar while it is open.
     */
    findCalendar() {
        return this.findComponent(CalendarWrapper);
    }
    /**
     * Types a date into the input, firing `onChange`.
     */
    setInputValue(value) {
        this.findDateInput().setInputValue(value);
    }
    getInputValue() {
        return this.findDateInput().getInputValue();
    }
    openCalendar() {
        this.findOpenCalendarButton().click();
    }
}
DatePickerWrapper.rootSelector = `.${styles.root}`;
export default DatePickerWrapper;
