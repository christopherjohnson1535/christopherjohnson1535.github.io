import { SelectBaseWrapper } from '../internal/option-list';
import optionListStyles from '../../../internal/components/option-list/styles.css.js';
import selectStyles from '../../../select/styles.css.js';
class SelectWrapper extends SelectBaseWrapper {
    findSelectedOption() {
        return this.findByClassName(optionListStyles['option-selected']);
    }
}
SelectWrapper.rootSelector = `.${selectStyles.root}`;
export default SelectWrapper;
