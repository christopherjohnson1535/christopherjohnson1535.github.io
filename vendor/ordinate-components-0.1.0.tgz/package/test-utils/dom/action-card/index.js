// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../action-card/styles.css.js';
class ActionCardWrapper extends ComponentWrapper {
    findHeader() {
        return this.findByClassName(styles.header);
    }
    findDescription() {
        return this.findByClassName(styles.description);
    }
    findContent() {
        return this.findByClassName(styles.content);
    }
    findIconSlot() {
        return this.findByClassName(styles.icon);
    }
    isDisabled() {
        return this.element.classList.contains(styles.disabled);
    }
}
ActionCardWrapper.rootSelector = `.${styles.root}`;
export default ActionCardWrapper;
