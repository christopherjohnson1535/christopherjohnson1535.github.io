// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../opening/styles.css.js';
class OpeningWrapper extends ComponentWrapper {
    findTitle() {
        return this.findByClassName(styles.title);
    }
    findKicker() {
        return this.findByClassName(styles.kicker);
    }
    findMeta() {
        return this.findByClassName(styles.meta);
    }
    findBadge() {
        return this.findByClassName(styles.badge);
    }
    findDescription() {
        return this.findByClassName(styles.description);
    }
    findActions() {
        return this.findByClassName(styles.actions);
    }
    /**
     * Returns the links row, which is only rendered when there are `links`.
     */
    findNavigation() {
        return this.findByClassName(styles.navigation);
    }
    findLinks() {
        return this.findAllByClassName(styles.link);
    }
    findMedia() {
        return this.findByClassName(styles['media-frame']);
    }
    findMediaCaption() {
        return this.findByClassName(styles['media-caption']);
    }
}
OpeningWrapper.rootSelector = `.${styles.root}`;
export default OpeningWrapper;
