// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import AttributeEditorWrapper, { AttributeEditorRowWrapper } from '../attribute-editor';
import AutosuggestWrapper from '../autosuggest';
import { ComponentWrapper } from '../core';
import loadingStyles from '../../../internal/components/loading-status/styles.css.js';
import styles from '../../../tag-editor/styles.css.js';
export class TagEditorRowWrapper extends AttributeEditorRowWrapper {
    findKeyInput() {
        return this.findField(1)?.findComponent(AutosuggestWrapper) ?? null;
    }
    /**
     * Returns the value field, or null while the tag is marked for removal.
     */
    findValueInput() {
        return this.findField(2)?.findComponent(AutosuggestWrapper) ?? null;
    }
    /**
     * Returns the text shown in place of the value of a tag marked for removal.
     */
    findUndoPrompt() {
        return this.findByClassName(styles['undo-prompt']);
    }
}
class TagEditorWrapper extends ComponentWrapper {
    findEditor() {
        return this.findComponent(AttributeEditorWrapper);
    }
    findTagRows() {
        return (this.findEditor()?.findRows() ?? []).map(row => new TagEditorRowWrapper(row.getElement()));
    }
    /**
     * Returns the tag row at a position, counting from 1.
     */
    findTagRow(position) {
        return this.findTagRows()[position - 1] ?? null;
    }
    findAddButton() {
        return this.findEditor()?.findAddButton() ?? null;
    }
    /**
     * Returns the text below the add button about the tag limit.
     */
    findLimitInfo() {
        return this.findEditor()?.findAdditionalInfo() ?? null;
    }
    findEmptySlot() {
        return this.findEditor()?.findEmptySlot() ?? null;
    }
    findLoadingStatus() {
        return this.findByClassName(loadingStyles.root);
    }
}
TagEditorWrapper.rootSelector = `.${styles.root}`;
export default TagEditorWrapper;
