// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../stamp/styles.css.js';
const types = ['complete', 'caution', 'fault', 'note', 'neutral', 'draft'];
class StampWrapper extends ComponentWrapper {
    /**
     * The words on the stamp.
     */
    findText() {
        return this.findByClassName(styles.text);
    }
    getType() {
        return types.find(type => this.getElement().classList.contains(styles[`type-${type}`])) ?? null;
    }
    isRotated() {
        return this.getElement().classList.contains(styles['rotation-slight']);
    }
}
StampWrapper.rootSelector = `.${styles.stamp}`;
export default StampWrapper;
