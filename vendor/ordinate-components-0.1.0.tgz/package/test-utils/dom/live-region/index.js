// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../live-region/styles.css.js';
class LiveRegionWrapper extends ComponentWrapper {
    findContent() {
        return this.findByClassName(styles.content);
    }
    /**
     * Returns the text most recently passed to screen readers.
     */
    getAnnouncement() {
        return this.findByClassName(styles.announcer).getText();
    }
}
LiveRegionWrapper.rootSelector = `.${styles.root}`;
export default LiveRegionWrapper;
