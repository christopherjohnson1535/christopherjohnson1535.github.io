// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../control-group/styles.css.js';
class ControlGroupWrapper extends ComponentWrapper {
    /**
     * Returns the cells that hold the grouped controls, in order.
     */
    findItems() {
        return this.findAll(`:scope > .${styles.item}`);
    }
    /**
     * Returns the cell of the control at a position, counting from 1.
     */
    findItem(position) {
        return this.findItems()[position - 1] ?? null;
    }
}
ControlGroupWrapper.rootSelector = `.${styles.root}`;
export default ControlGroupWrapper;
