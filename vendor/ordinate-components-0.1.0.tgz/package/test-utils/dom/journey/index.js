// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import ButtonWrapper from '../button';
import { ComponentWrapper } from '../core';
import styles from '../../../journey/styles.css.js';
class JourneyWrapper extends ComponentWrapper {
    /**
     * The heading of the question shown.
     */
    findQuestion() {
        return this.findByClassName(styles.question);
    }
    findDescription() {
        return this.findByClassName(styles.description);
    }
    /**
     * The line that says which question is shown, such as "Question 2 of 5".
     */
    findCounter() {
        return this.findByClassName(styles.counter);
    }
    /**
     * The label shown next to the counter on an optional question.
     */
    findOptionalLabel() {
        return this.findByClassName(styles.optional);
    }
    /**
     * The drawn progress ruler. It is hidden from assistive technology.
     */
    findProgress() {
        return this.findByClassName(styles.ruler);
    }
    findContent() {
        return this.findByClassName(styles.content);
    }
    /**
     * The error of the question shown, while it has one.
     */
    findError() {
        return this.findByClassName(styles['error-text']);
    }
    /**
     * The back button. It is not shown on the first question.
     */
    findBackButton() {
        const element = this.findByClassName(styles['back-button']);
        return element ? new ButtonWrapper(element.getElement()) : null;
    }
    /**
     * The continue button, or the finish button on the last question.
     */
    findContinueButton() {
        return new ButtonWrapper(this.findByClassName(styles['continue-button']).getElement());
    }
}
JourneyWrapper.rootSelector = `.${styles.root}`;
export default JourneyWrapper;
