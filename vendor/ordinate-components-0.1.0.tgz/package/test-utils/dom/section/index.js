// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../section/styles.css.js';
class SectionWrapper extends ComponentWrapper {
    findHeading() {
        return this.findByClassName(styles.heading);
    }
    findDescription() {
        return this.findByClassName(styles.description);
    }
    findActions() {
        return this.findByClassName(styles.actions);
    }
    findContent() {
        return this.findByClassName(styles.content);
    }
}
SectionWrapper.rootSelector = `.${styles.root}`;
export default SectionWrapper;
