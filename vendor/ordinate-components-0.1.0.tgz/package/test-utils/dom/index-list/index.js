// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../index-list/styles.css.js';
export class IndexListItemWrapper extends ComponentWrapper {
    findLabel() {
        return this.findByClassName(styles.label);
    }
    /**
     * Returns the row's link, when the item has an `href`.
     */
    findLabelLink() {
        return this.findLabel().find('a');
    }
    findValue() {
        return this.findByClassName(styles.value);
    }
    findMeta() {
        return this.findByClassName(styles.meta);
    }
    findNumber() {
        return this.findByClassName(styles.number);
    }
}
IndexListItemWrapper.rootSelector = `.${styles.item}`;
class IndexListWrapper extends ComponentWrapper {
    /**
     * Returns the `<ol>` or `<ul>` element.
     */
    findListElement() {
        return this.findByClassName(styles.list);
    }
    findItems() {
        return this.findAllComponents(IndexListItemWrapper);
    }
}
IndexListWrapper.rootSelector = `.${styles.root}`;
export default IndexListWrapper;
