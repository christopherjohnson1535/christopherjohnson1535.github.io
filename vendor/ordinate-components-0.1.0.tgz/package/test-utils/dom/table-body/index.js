// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import TableRowWrapper from '../table-row';
import styles from '../../../table-body/styles.css.js';
class TableBodyWrapper extends ComponentWrapper {
    findRows() {
        return this.findAll(':scope > tr').map(row => new TableRowWrapper(row.getElement()));
    }
}
TableBodyWrapper.rootSelector = `.${styles.root}`;
export default TableBodyWrapper;
