// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import { dragFilesOver, dropFiles } from '../internal/file-transfer';
import styles from '../../../file-dropzone/styles.css.js';
class FileDropzoneWrapper extends ComponentWrapper {
    findContent() {
        return this.findByClassName(styles.content);
    }
    /**
     * Whether files are being dragged over the page, which outlines the zone.
     */
    isPageDragging() {
        return this.element.classList.contains(styles['page-dragging']);
    }
    /**
     * Whether files are being dragged over the zone itself, which highlights it.
     */
    isActive() {
        return this.element.classList.contains(styles.active);
    }
    /**
     * Drags files over the zone without dropping them.
     */
    dragFilesOver(files) {
        dragFilesOver(this, files);
    }
    /**
     * Drags files onto the zone and drops them, firing `onChange`.
     */
    dropFiles(files) {
        dropFiles(this, files);
    }
}
FileDropzoneWrapper.rootSelector = `.${styles.root}`;
export default FileDropzoneWrapper;
