// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper, ElementWrapper } from '../core';
import RadioButtonWrapper from '../radio-button';
import styles from '../../../radio-group/styles.css.js';
class RadioGroupWrapper extends ComponentWrapper {
    findButtons() {
        return this.findAllComponents(RadioButtonWrapper);
    }
    findInputByValue(value) {
        const input = Array.from(this.getElement().querySelectorAll('input[type="radio"]')).find(element => element.value === value);
        return input ? new ElementWrapper(input) : null;
    }
    getSelectedValue() {
        return this.find('input[type="radio"]:checked')?.getElement().value ?? null;
    }
}
RadioGroupWrapper.rootSelector = `.${styles.root}`;
export default RadioGroupWrapper;
