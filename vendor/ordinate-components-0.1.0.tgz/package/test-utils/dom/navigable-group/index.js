// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../navigable-group/styles.css.js';
class NavigableGroupWrapper extends ComponentWrapper {
    /**
     * The item that holds the tab stop: the one Tab moves focus to.
     */
    findTabStop() {
        const root = this.getElement();
        return (this.findAll('[data-navigable-group-item][tabindex="0"]').find(item => item.getElement().closest('[data-navigable-group]') === root) ?? null);
    }
}
NavigableGroupWrapper.rootSelector = `.${styles.root}`;
export default NavigableGroupWrapper;
