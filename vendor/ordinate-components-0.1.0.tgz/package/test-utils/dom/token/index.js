// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import ButtonWrapper from '../button';
import { ComponentWrapper } from '../core';
import styles from '../../../token/styles.css.js';
class TokenWrapper extends ComponentWrapper {
    findLabel() {
        return this.findByClassName(styles.label);
    }
    findLabelTag() {
        return this.findByClassName(styles['label-tag']);
    }
    findDescription() {
        return this.findByClassName(styles.description);
    }
    findTags() {
        return this.findAllByClassName(styles.tag);
    }
    findIconSlot() {
        return this.findByClassName(styles.icon);
    }
    /**
     * Returns the token's dismiss button, if it can be dismissed.
     */
    findDismissButton() {
        const element = this.findByClassName(styles['dismiss-button']);
        return element ? new ButtonWrapper(element.getElement()) : null;
    }
    isDisabled() {
        return this.element.classList.contains(styles.disabled);
    }
}
TokenWrapper.rootSelector = `.${styles.root}`;
export default TokenWrapper;
