// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import ButtonWrapper from '../button';
import { ComponentWrapper, ElementWrapper } from '../core';
import styles from '../../../list/styles.css.js';
/**
 * One row of a list.
 */
export class ListItemWrapper extends ElementWrapper {
    findContent() {
        return this.findByClassName(styles.content);
    }
    findSecondaryContent() {
        return this.findByClassName(styles['secondary-content']);
    }
    findIconSlot() {
        return this.findByClassName(styles.icon);
    }
    findActions() {
        return this.findByClassName(styles.actions);
    }
    findMoveUpButton() {
        return this.findSortButton(0);
    }
    findMoveDownButton() {
        return this.findSortButton(1);
    }
    findSortButton(position) {
        const element = this.findByClassName(styles['sort-controls'])?.findAll('button')[position];
        return element ? new ButtonWrapper(element.getElement()) : null;
    }
}
class ListWrapper extends ComponentWrapper {
    findItems() {
        return this.findAllByClassName(styles.item).map(item => new ListItemWrapper(item.getElement()));
    }
}
ListWrapper.rootSelector = `.${styles.root}`;
export default ListWrapper;
