// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import ButtonWrapper from '../button';
import { ComponentWrapper, ElementWrapper } from '../core';
import floatingPanelStyles from '../../../internal/components/floating-panel/styles.css.js';
import styles from '../../../popover/styles.css.js';
class PopoverWrapper extends ComponentWrapper {
    /**
     * The text trigger button, or the element wrapping a custom trigger.
     */
    findTrigger() {
        return this.findByClassName(styles.trigger);
    }
    /**
     * The open popover, also when it is rendered with a portal.
     */
    findBody() {
        const inside = this.findByClassName(styles.panel);
        if (inside) {
            return inside;
        }
        // A portal moves the panel out of the root; its ID follows the trigger's.
        const triggerId = this.findTrigger().getElement().id;
        const panel = triggerId ? document.getElementById(triggerId.replace(/trigger$/, 'panel')) : null;
        return panel ? new ElementWrapper(panel) : null;
    }
    findHeader() {
        return this.findBody()?.findByClassName(styles.header) ?? null;
    }
    findContent() {
        return this.findBody()?.findByClassName(styles.content) ?? null;
    }
    /**
     * The close button, or `null` when the popover is closed or has `dismissButton` set to `false`.
     */
    findDismissButton() {
        return this.findBody()?.findByClassName(styles.dismiss)?.findComponent(ButtonWrapper) ?? null;
    }
    /**
     * The leader that ties the open popover to its trigger: a dot at the trigger and a line to the plate.
     * It is drawing only and hidden from screen readers.
     */
    findLeader() {
        return this.findBody()?.findByClassName(floatingPanelStyles.leader) ?? null;
    }
    isOpen() {
        return this.findBody() !== null;
    }
}
PopoverWrapper.rootSelector = `.${styles.root}`;
export default PopoverWrapper;
