// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../spinner/styles.css.js';
class SpinnerWrapper extends ComponentWrapper {
}
SpinnerWrapper.rootSelector = `.${styles.root}`;
export default SpinnerWrapper;
