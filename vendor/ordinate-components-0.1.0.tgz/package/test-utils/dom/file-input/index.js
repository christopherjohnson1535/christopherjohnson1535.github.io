// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import ButtonWrapper from '../button';
import { ComponentWrapper } from '../core';
import { chooseFiles } from '../internal/file-transfer';
import styles from '../../../file-input/styles.css.js';
class FileInputWrapper extends ComponentWrapper {
    /**
     * The native `<input type="file">`, which holds focus and the accessible name.
     */
    findNativeInput() {
        return this.findByClassName(styles['native-input']);
    }
    /**
     * The button that draws the control and opens the file chooser.
     */
    findTrigger() {
        return new ButtonWrapper(this.findByClassName(styles.trigger).getElement());
    }
    /**
     * Chooses files as if the user had picked them in the file chooser, firing `onChange`.
     */
    selectFiles(files) {
        chooseFiles(this.findNativeInput(), files);
    }
}
FileInputWrapper.rootSelector = `.${styles.root}`;
export default FileInputWrapper;
