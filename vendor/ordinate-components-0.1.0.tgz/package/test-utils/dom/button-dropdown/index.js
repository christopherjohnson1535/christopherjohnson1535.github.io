// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import ButtonWrapper from '../button';
import { ComponentWrapper } from '../core';
import styles from '../../../button-dropdown/styles.css.js';
class ButtonDropdownWrapper extends ComponentWrapper {
    /**
     * The button that opens the menu.
     */
    findTrigger() {
        return new ButtonWrapper(this.findByClassName(styles.trigger).getElement());
    }
    /**
     * The main action of a split button.
     */
    findMainAction() {
        const element = this.findByClassName(styles['main-action']);
        return element ? new ButtonWrapper(element.getElement()) : null;
    }
    /**
     * Returns the menu while it is open.
     */
    findMenu() {
        return this.findByClassName(styles.menu);
    }
    /**
     * Returns the items in the open menu, in order, including group entries that expand and disabled items.
     */
    findItems() {
        return this.findAll('[data-menu-item]');
    }
    findItemById(id) {
        return this.findItems().find(item => item.getElement().dataset.itemId === id) ?? null;
    }
    /**
     * Returns the entry of an expandable group by the group's `id`.
     */
    findExpandableGroupById(id) {
        return this.findItems().find(item => item.getElement().dataset.groupKey === id) ?? null;
    }
    /**
     * Returns the shown reason of a disabled item, by the item's `id`.
     */
    findDisabledReason(id) {
        return this.findItemById(id)?.findByClassName(styles['disabled-reason']) ?? null;
    }
    isOpen() {
        return this.findTrigger().getElement().getAttribute('aria-expanded') === 'true';
    }
    /**
     * Opens the menu by clicking the trigger, unless it is already open.
     */
    openDropdown() {
        if (!this.isOpen()) {
            this.findTrigger().click();
        }
    }
    /**
     * Opens the menu and clicks the item with this `id`.
     */
    clickItem(id) {
        this.openDropdown();
        const item = this.findItemById(id);
        if (!item) {
            throw new Error(`No item with id ${id}.`);
        }
        item.click();
    }
}
ButtonDropdownWrapper.rootSelector = `.${styles.root}`;
export default ButtonDropdownWrapper;
