// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../article/styles.css.js';
class ArticleWrapper extends ComponentWrapper {
    findLead() {
        return this.findByClassName(styles.lead);
    }
    findByline() {
        return this.findByClassName(styles.byline);
    }
    /**
     * The text of the article: everything passed as children.
     */
    findContent() {
        return this.findByClassName(styles.body);
    }
}
ArticleWrapper.rootSelector = `.${styles.root}`;
export default ArticleWrapper;
