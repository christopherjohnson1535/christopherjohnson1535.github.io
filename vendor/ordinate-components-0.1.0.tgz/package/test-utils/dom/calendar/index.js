// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import ButtonWrapper from '../button';
import { ComponentWrapper } from '../core';
import styles from '../../../calendar/styles.css.js';
import gridStyles from '../../../internal/components/calendar-grid/styles.css.js';
/**
 * Finders for the parts of a month or year grid, shared by the calendar and the date range picker.
 */
export class CalendarGridWrapper extends ComponentWrapper {
    /**
     * Returns the title of each grid on show, such as "March 2026".
     */
    findTitles() {
        return this.findAllByClassName(gridStyles.title);
    }
    findPreviousButton() {
        return this.findPageButton(0);
    }
    findNextButton() {
        const buttons = this.findAllByClassName(gridStyles['page-button']);
        return buttons.length > 0 ? new ButtonWrapper(buttons[buttons.length - 1].getElement()) : null;
    }
    /**
     * Returns the cell for a day as `YYYY-MM-DD`, or for a month as `YYYY-MM-01`.
     */
    findDate(isoDate) {
        return this.find(`[data-date="${isoDate}"]`);
    }
    /**
     * Returns every day or month cell on show, in order.
     */
    findDates() {
        return this.findAll('[data-date]');
    }
    findSelectedDates() {
        return this.findAllByClassName(gridStyles.selected);
    }
    /**
     * Returns today's cell, or the current month's, when it is on show.
     */
    findCurrentDate() {
        return this.find('[data-date][aria-current="date"]');
    }
    /**
     * Returns the cell that holds the tab stop.
     */
    findFocusableDate() {
        return this.find('[data-date][tabindex="0"]');
    }
    findPageButton(index) {
        const button = this.findAllByClassName(gridStyles['page-button'])[index];
        return button ? new ButtonWrapper(button.getElement()) : null;
    }
}
class CalendarWrapper extends CalendarGridWrapper {
    findTitle() {
        return this.findTitles()[0];
    }
    /**
     * The line under the grid that explains why the focused or hovered date is disabled.
     */
    findDisabledReason() {
        return this.findByClassName(styles['disabled-reason']);
    }
}
CalendarWrapper.rootSelector = `.${styles.root}`;
export default CalendarWrapper;
