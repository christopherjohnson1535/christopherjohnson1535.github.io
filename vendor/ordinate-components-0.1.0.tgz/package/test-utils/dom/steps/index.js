// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../steps/styles.css.js';
export class StepWrapper extends ComponentWrapper {
    findHeader() {
        return this.findByClassName(styles.header);
    }
    findDetails() {
        return this.findByClassName(styles.details);
    }
}
StepWrapper.rootSelector = `.${styles.step}`;
class StepsWrapper extends ComponentWrapper {
    /**
     * The steps, in order. Each one finds its header, details and status indicator.
     */
    findItems() {
        return this.findAllComponents(StepWrapper);
    }
}
StepsWrapper.rootSelector = `.${styles.root}`;
export default StepsWrapper;
