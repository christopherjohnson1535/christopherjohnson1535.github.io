// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { AbstractSwitchWrapper } from '../internal/abstract-switch';
import styles from '../../../toggle/styles.css.js';
class ToggleWrapper extends AbstractSwitchWrapper {
}
ToggleWrapper.rootSelector = `.${styles.root}`;
export default ToggleWrapper;
