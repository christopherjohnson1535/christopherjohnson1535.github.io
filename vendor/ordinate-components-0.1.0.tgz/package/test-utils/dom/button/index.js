// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import IconWrapper from '../icon';
import styles from '../../../button/styles.css.js';
class ButtonWrapper extends ComponentWrapper {
    /**
     * Whether the button ignores clicks, because it is disabled or loading.
     */
    isDisabled() {
        const element = this.getElement();
        return element instanceof HTMLButtonElement
            ? element.disabled || element.getAttribute('aria-disabled') === 'true'
            : element.getAttribute('aria-disabled') === 'true';
    }
    isLoading() {
        return this.findLoadingIndicator() !== null;
    }
    findLoadingIndicator() {
        return this.findByClassName(styles['loading-indicator']);
    }
    /**
     * The element holding the button text.
     */
    findTextRegion() {
        return this.findByClassName(styles.content);
    }
    /**
     * The icon set with `iconName` or `iconSvg`.
     */
    findIcon() {
        const element = this.getElement().querySelector(`.${styles.icon}`);
        return element ? new IconWrapper(element) : null;
    }
    findExternalIcon() {
        const element = this.getElement().querySelector(`.${styles['external-icon']}`);
        return element ? new IconWrapper(element) : null;
    }
}
ButtonWrapper.rootSelector = `.${styles.button}`;
export default ButtonWrapper;
