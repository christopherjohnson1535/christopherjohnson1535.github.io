// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../key-value-pairs/styles.css.js';
export class KeyValuePairWrapper extends ComponentWrapper {
    findLabel() {
        return this.findByClassName(styles['label-text']);
    }
    findValue() {
        return this.findByClassName(styles.value);
    }
    findInfo() {
        return this.findByClassName(styles.info);
    }
}
KeyValuePairWrapper.rootSelector = `.${styles.pair}`;
export class KeyValuePairsGroupWrapper extends ComponentWrapper {
    findTitle() {
        return this.findByClassName(styles['group-title']);
    }
    findItems() {
        return this.findAllComponents(KeyValuePairWrapper);
    }
}
KeyValuePairsGroupWrapper.rootSelector = `.${styles.group}`;
class KeyValuePairsWrapper extends ComponentWrapper {
    /**
     * The cells of the grid in order: pairs and groups.
     */
    findCells() {
        const list = this.getElement().querySelector(`.${styles.list}`);
        return Array.from(list.children, element => element.classList.contains(styles.group)
            ? new KeyValuePairsGroupWrapper(element)
            : new KeyValuePairWrapper(element));
    }
    /**
     * Every pair, including the pairs inside groups.
     */
    findItems() {
        return this.findAllComponents(KeyValuePairWrapper);
    }
    findGroups() {
        return this.findAllComponents(KeyValuePairsGroupWrapper);
    }
}
KeyValuePairsWrapper.rootSelector = `.${styles.root}`;
export default KeyValuePairsWrapper;
