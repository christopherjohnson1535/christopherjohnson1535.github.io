// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../code-view/styles.css.js';
class CodeViewWrapper extends ComponentWrapper {
    /**
     * Returns every line, in order.
     */
    findLines() {
        return this.findAllByClassName(styles.line);
    }
    /**
     * Returns the line with the given number, starting from 1.
     */
    findLine(lineNumber) {
        return this.find(`.${styles.line}[data-line="${lineNumber}"]`);
    }
    /**
     * Returns the code of a line, without its number or notes.
     */
    findLineContent(lineNumber) {
        return this.find(`.${styles.line}[data-line="${lineNumber}"] > .${styles['line-content']}`);
    }
    findHighlightedLines() {
        return this.findAllByClassName(styles['line-highlighted']);
    }
    findLineNotes() {
        return this.findAllByClassName(styles['line-note']);
    }
    findLineNumbers() {
        return this.findAllByClassName(styles['line-number']);
    }
}
CodeViewWrapper.rootSelector = `.${styles.root}`;
export default CodeViewWrapper;
