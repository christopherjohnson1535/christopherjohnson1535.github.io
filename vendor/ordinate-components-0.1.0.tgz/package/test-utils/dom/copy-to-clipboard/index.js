// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import ButtonWrapper from '../button';
import { ComponentWrapper, ElementWrapper } from '../core';
import styles from '../../../copy-to-clipboard/styles.css.js';
import feedbackStyles from '../../../internal/components/feedback-panel/styles.css.js';
class CopyToClipboardWrapper extends ComponentWrapper {
    findCopyButton() {
        return new ButtonWrapper(this.findByClassName(styles.button).getElement());
    }
    /**
     * The text shown by the `inline` variant.
     */
    findDisplayedText() {
        return this.findByClassName(styles.text);
    }
    /**
     * The message shown after a copy, while it is visible. Without `popoverRenderWithPortal`
     * it is inside the component; with it, pass `true` to look in the whole document.
     */
    findStatusText(inPortal = false) {
        const container = inPortal ? this.getElement().ownerDocument.body : this.getElement();
        const element = container.querySelector(`.${feedbackStyles.panel}`);
        return element ? new ElementWrapper(element) : null;
    }
}
CopyToClipboardWrapper.rootSelector = `.${styles.root}`;
export default CopyToClipboardWrapper;
