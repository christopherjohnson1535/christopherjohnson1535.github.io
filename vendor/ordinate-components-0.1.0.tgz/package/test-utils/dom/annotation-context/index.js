// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import AlertWrapper from '../alert';
import ButtonWrapper from '../button';
import { ComponentWrapper } from '../core';
import styles from '../../../annotation-context/styles.css.js';
/**
 * The annotation of the current tutorial step, which `AnnotationContext` opens at the
 * step's hotspot.
 */
class AnnotationContextWrapper extends ComponentWrapper {
    findTaskTitle() {
        return this.findByClassName(styles['task-title']);
    }
    findStepTitle() {
        return this.findByClassName(styles['step-title']);
    }
    findContent() {
        return this.findByClassName(styles.content);
    }
    findWarningAlert() {
        return this.findByClassName(styles.warning)?.findComponent(AlertWrapper) ?? null;
    }
    findStepCounter() {
        return this.findByClassName(styles['step-counter']);
    }
    findDismissButton() {
        return this.findByClassName(styles.dismiss).findComponent(ButtonWrapper);
    }
    /**
     * The previous button, or `null` on the first step of the tutorial.
     */
    findPreviousButton() {
        return this.findComponent(ButtonWrapper, `.${styles['previous-button']}`);
    }
    /**
     * The next button, or `null` on the last step of the tutorial.
     */
    findNextButton() {
        return this.findComponent(ButtonWrapper, `.${styles['next-button']}`);
    }
    /**
     * The finish button, shown on the last step of the tutorial.
     */
    findFinishButton() {
        return this.findComponent(ButtonWrapper, `.${styles['finish-button']}`);
    }
}
AnnotationContextWrapper.rootSelector = `.${styles.annotation}`;
export default AnnotationContextWrapper;
