// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import * as React from 'react';
// React 18.3 and later export `act` from the main package. Older versions run events without it.
const act = React.act ?? (callback => callback());
export class ElementWrapper {
    constructor(element) {
        this.element = element;
    }
    getElement() {
        return this.element;
    }
    find(selector) {
        const element = this.element.querySelector(selector);
        return element ? new ElementWrapper(element) : null;
    }
    findAll(selector) {
        return Array.from(this.element.querySelectorAll(selector), element => new ElementWrapper(element));
    }
    findByClassName(className) {
        return this.find(`.${className}`);
    }
    findAllByClassName(className) {
        return this.findAll(`.${className}`);
    }
    findComponent(Wrapper, selector = '') {
        const element = this.element.querySelector(`${Wrapper.rootSelector}${selector}`);
        return element ? new Wrapper(element) : null;
    }
    findAllComponents(Wrapper, selector = '') {
        return Array.from(this.element.querySelectorAll(`${Wrapper.rootSelector}${selector}`), element => new Wrapper(element));
    }
    getText() {
        return this.element.textContent ?? '';
    }
    click(init = {}) {
        this.fireEvent(new MouseEvent('click', { bubbles: true, cancelable: true, button: 0, ...init }));
    }
    keydown(key, init = {}) {
        this.fireEvent(new KeyboardEvent('keydown', { bubbles: true, cancelable: true, key, ...init }));
    }
    focus() {
        act(() => this.element.focus());
    }
    blur() {
        act(() => this.element.blur());
    }
    fireEvent(event) {
        act(() => {
            this.element.dispatchEvent(event);
        });
    }
    /**
     * Sets the value of a native input, select or textarea the way a user would,
     * so React's onChange runs.
     */
    setNativeValue(value) {
        const element = this.element;
        const prototype = Object.getPrototypeOf(element);
        const setter = Object.getOwnPropertyDescriptor(prototype, 'value')?.set;
        act(() => {
            setter?.call(element, value);
            element.dispatchEvent(new Event('input', { bubbles: true }));
            element.dispatchEvent(new Event('change', { bubbles: true }));
        });
    }
}
export class ComponentWrapper extends ElementWrapper {
}
