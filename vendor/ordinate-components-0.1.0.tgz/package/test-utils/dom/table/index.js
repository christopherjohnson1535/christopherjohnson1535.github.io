import { TableGridWrapper } from '../internal/table-grid';
import styles from '../../../table/styles.css.js';
import rootStyles from '../../../table-root/styles.css.js';
class TableWrapper extends TableGridWrapper {
    findNativeTable() {
        return this.find(`.${rootStyles.root} > .${rootStyles.table}`);
    }
    findHeaderSlot() {
        return this.findByClassName(styles['header-slot']);
    }
    /**
     * The `reference` set above the header.
     */
    findReference() {
        return this.findByClassName(styles.reference);
    }
    /**
     * The dimension line on the construction line that opens the sheet, which holds the header's counter.
     */
    findMeasure() {
        return this.findByClassName(styles.measure);
    }
    findFooterSlot() {
        return this.findByClassName(styles['footer-slot']);
    }
    /**
     * The element holding the `filter` slot.
     */
    findTextFilter() {
        return this.findByClassName(styles['tools-filter']);
    }
    /**
     * The element holding the `pagination` slot.
     */
    findPagination() {
        return this.findByClassName(styles['tools-pagination']);
    }
    /**
     * The element holding the `preferences` slot.
     */
    findCollectionPreferences() {
        return this.findByClassName(styles['tools-preferences']);
    }
    /**
     * The `empty` content, shown when there are no items and the table is not loading.
     */
    findEmptySlot() {
        return this.findByClassName(styles.empty);
    }
    /**
     * The loading message, shown while `loading` is set.
     */
    findLoadingText() {
        return this.findByClassName(styles.loading);
    }
}
TableWrapper.rootSelector = `.${styles.root}`;
export default TableWrapper;
