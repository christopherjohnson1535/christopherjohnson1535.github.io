// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../side-navigation/styles.css.js';
class SideNavigationWrapper extends ComponentWrapper {
    findHeaderLink() {
        return this.findByClassName(styles['header-link']);
    }
    /**
     * Returns every rendered link, in order, including links in collapsed sections.
     */
    findLinks() {
        return this.findAllByClassName(styles.link);
    }
    findLinkByHref(href) {
        return this.findLinks().find(link => link.getElement().getAttribute('href') === href) ?? null;
    }
    /**
     * Returns the code of every link, in order, while any link has one. Links without a code
     * return an empty code, so the list lines up with `findLinks()`.
     */
    findLinkCodes() {
        return this.findAllByClassName(styles.code);
    }
    findActiveLink() {
        return this.findByClassName(styles['link-active']);
    }
    /**
     * Returns the buttons that expand and collapse sections, in order.
     */
    findSectionToggles() {
        return this.findAllByClassName(styles['section-toggle']);
    }
    /**
     * Returns the buttons that expand and collapse expandable link groups, in order.
     */
    findExpandToggles() {
        return this.findAllByClassName(styles['expand-toggle']);
    }
    findSectionGroupTitles() {
        return this.findAllByClassName(styles['section-group-title']);
    }
    findDividers() {
        return this.findAllByClassName(styles.divider);
    }
}
SideNavigationWrapper.rootSelector = `.${styles.root}`;
export default SideNavigationWrapper;
