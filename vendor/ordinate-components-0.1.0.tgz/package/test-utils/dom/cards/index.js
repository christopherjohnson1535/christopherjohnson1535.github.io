// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import ItemCardWrapper from '../item-card';
import styles from '../../../cards/styles.css.js';
/**
 * One card in a Cards collection.
 */
export class CardWrapper extends ItemCardWrapper {
    findSections() {
        return this.findAllByClassName(styles.section);
    }
    findSectionHeaders() {
        return this.findAllByClassName(styles['section-header']);
    }
    /**
     * Returns the native checkbox or radio input that selects the card.
     */
    findSelectionInput() {
        return this.find('input');
    }
}
class CardsWrapper extends ComponentWrapper {
    findItems() {
        return this.findAllByClassName(styles.card).map(card => new CardWrapper(card.getElement()));
    }
    findSelectedItems() {
        return this.findItems().filter(card => card.isSelected());
    }
    findHeader() {
        return this.findByClassName(styles.header);
    }
    /**
     * The dimension line on the construction line that opens the sheet, which holds the header's counter.
     */
    findMeasure() {
        return this.findByClassName(styles.measure);
    }
    findFilterSlot() {
        return this.findByClassName(styles.filter);
    }
    findPaginationSlot() {
        return this.findByClassName(styles.pagination);
    }
    findPreferencesSlot() {
        return this.findByClassName(styles.preferences);
    }
    findLoadingText() {
        return this.findByClassName(styles.loading);
    }
    findEmptySlot() {
        return this.findByClassName(styles.empty);
    }
}
CardsWrapper.rootSelector = `.${styles.root}`;
export default CardsWrapper;
