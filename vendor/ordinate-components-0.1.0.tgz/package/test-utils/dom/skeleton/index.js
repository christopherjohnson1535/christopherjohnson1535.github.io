// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../skeleton/styles.css.js';
class SkeletonWrapper extends ComponentWrapper {
    isLoading() {
        return this.getElement().getAttribute('aria-busy') === 'true';
    }
    /**
     * The lines of the `text` and `heading` variants.
     */
    findLines() {
        return this.findAllByClassName(styles.line);
    }
    /**
     * The frame of the `block` variant.
     */
    findBlock() {
        return this.findByClassName(styles.block);
    }
    /**
     * The text read by screen readers while loading.
     */
    findLoadingText() {
        return this.findByClassName(styles['loading-text']);
    }
}
SkeletonWrapper.rootSelector = `.${styles.root}`;
export default SkeletonWrapper;
