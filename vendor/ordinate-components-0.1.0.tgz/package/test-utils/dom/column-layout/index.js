// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../column-layout/styles.css.js';
class ColumnLayoutWrapper extends ComponentWrapper {
    /**
     * Returns the cells, one per child, in reading order.
     */
    findItems() {
        return this.findAll(`:scope > .${styles.item}`);
    }
    /**
     * Returns how many columns the layout currently shows.
     */
    getColumnCount() {
        return Number(this.getElement().dataset.columnCount);
    }
}
ColumnLayoutWrapper.rootSelector = `.${styles.root}`;
export default ColumnLayoutWrapper;
