// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../content-layout/styles.css.js';
class ContentLayoutWrapper extends ComponentWrapper {
    findHeader() {
        return this.find(`:scope > .${styles['header-area']} > .${styles.header}`);
    }
    findBreadcrumbs() {
        return this.find(`:scope > .${styles['header-area']} > .${styles.breadcrumbs}`);
    }
    findNotifications() {
        return this.find(`:scope > .${styles['header-area']} > .${styles.notifications}`);
    }
    findContent() {
        return this.find(`:scope > .${styles.content}`);
    }
}
ContentLayoutWrapper.rootSelector = `.${styles.root}`;
export default ContentLayoutWrapper;
