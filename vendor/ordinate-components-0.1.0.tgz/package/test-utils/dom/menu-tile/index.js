// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import leaderStyles from '../../../internal/components/leader-row/styles.css.js';
import styles from '../../../menu-tile/styles.css.js';
export class MenuTileItemWrapper extends ComponentWrapper {
    findLabel() {
        return this.findByClassName(leaderStyles.label);
    }
    findValue() {
        return this.findByClassName(leaderStyles.value);
    }
    findDescription() {
        return this.findByClassName(styles['item-description']);
    }
}
MenuTileItemWrapper.rootSelector = `.${styles.item}`;
class MenuTileWrapper extends ComponentWrapper {
    /**
     * Returns the heading that holds the title.
     */
    findTitle() {
        return this.findByClassName(styles.title);
    }
    findBadge() {
        return this.findByClassName(styles.badge);
    }
    findDescription() {
        return this.findByClassName(styles.description);
    }
    findItems() {
        return this.findAllComponents(MenuTileItemWrapper);
    }
    findFooter() {
        return this.findByClassName(styles.footer);
    }
}
MenuTileWrapper.rootSelector = `.${styles.root}`;
export default MenuTileWrapper;
