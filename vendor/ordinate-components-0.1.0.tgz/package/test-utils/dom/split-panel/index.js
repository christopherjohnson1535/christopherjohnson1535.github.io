// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import ButtonWrapper from '../button';
import { ComponentWrapper } from '../core';
import ModalWrapper from '../modal';
import styles from '../../../split-panel/styles.css.js';
class SplitPanelWrapper extends ComponentWrapper {
    buttonAt(selector) {
        const element = this.getElement().querySelector(selector);
        return element ? new ButtonWrapper(element) : null;
    }
    isOpen() {
        return this.getElement().classList.contains(styles.open);
    }
    /**
     * The position the panel is shown in.
     */
    getPosition() {
        const classes = this.getElement().classList;
        return classes.contains(styles['position-side']) || classes.contains(styles['side-rail']) ? 'side' : 'bottom';
    }
    findHeader() {
        return this.findByClassName(styles.heading);
    }
    /**
     * The circled tag before the title.
     */
    findHeaderTag() {
        return this.findByClassName(styles.tag);
    }
    /**
     * The label above the title that repeats the tag, such as "Detail S3".
     */
    findHeaderKicker() {
        return this.findByClassName(styles.kicker);
    }
    findHeaderDescription() {
        return this.findByClassName(styles.description);
    }
    findHeaderInfo() {
        return this.findByClassName(styles.info);
    }
    findHeaderActions() {
        return this.findByClassName(styles.actions);
    }
    findContent() {
        return this.findByClassName(styles.content);
    }
    /**
     * The button that opens the collapsed panel.
     */
    findOpenButton() {
        return this.isOpen() ? null : this.buttonAt('button');
    }
    findCloseButton() {
        return this.buttonAt(`.${styles['close-button']}`);
    }
    findPreferencesButton() {
        return this.buttonAt(`.${styles['preferences-button']}`);
    }
    /**
     * The separator that resizes the panel with a drag or the arrow keys.
     */
    findResizeHandle() {
        return this.find('[role="separator"]');
    }
    findPreferencesModal() {
        return this.findComponent(ModalWrapper);
    }
}
SplitPanelWrapper.rootSelector = `.${styles.root}`;
export default SplitPanelWrapper;
