// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../how-it-works/styles.css.js';
class HowItWorksWrapper extends ComponentWrapper {
    /**
     * The steps, in order.
     */
    findSteps() {
        return this.findAllByClassName(styles.step);
    }
    /**
     * The step with this number, counted from 1.
     */
    findStep(stepNumber) {
        return this.findSteps()[stepNumber - 1] ?? null;
    }
    findStepNumber(step) {
        return step.findByClassName(styles.number);
    }
    findStepTitle(step) {
        return step.findByClassName(styles.title);
    }
    findStepDescription(step) {
        return step.findByClassName(styles.description);
    }
    findStepMedia(step) {
        return step.findByClassName(styles.media);
    }
}
HowItWorksWrapper.rootSelector = `.${styles.root}`;
export default HowItWorksWrapper;
