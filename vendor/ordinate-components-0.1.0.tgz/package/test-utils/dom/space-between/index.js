// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../space-between/styles.css.js';
class SpaceBetweenWrapper extends ComponentWrapper {
    /**
     * Returns the slot around each item, in order.
     */
    findItems() {
        return this.findAll(`:scope > .${styles.child}`);
    }
}
SpaceBetweenWrapper.rootSelector = `.${styles.root}`;
export default SpaceBetweenWrapper;
