// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../anchor-navigation/styles.css.js';
class AnchorNavigationWrapper extends ComponentWrapper {
    /**
     * Every anchor link, in document order, including nested ones.
     */
    findAnchorLinks() {
        return this.findAllByClassName(styles.link);
    }
    /**
     * The anchor link with this position in document order, counted from 1.
     */
    findAnchorLinkByIndex(index) {
        return this.findAnchorLinks()[index - 1] ?? null;
    }
    findAnchorLinkByHref(href) {
        return this.findAnchorLinks().find(link => link.getElement().getAttribute('href') === href) ?? null;
    }
    findActiveAnchor() {
        return this.findByClassName(styles['link-active']);
    }
    /**
     * The info text of every anchor that has one, in order.
     */
    findInfos() {
        return this.findAllByClassName(styles.info);
    }
}
AnchorNavigationWrapper.rootSelector = `.${styles.root}`;
export default AnchorNavigationWrapper;
