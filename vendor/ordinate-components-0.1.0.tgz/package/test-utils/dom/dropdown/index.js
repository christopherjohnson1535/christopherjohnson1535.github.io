// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../dropdown/styles.css.js';
import popupStyles from '../../../internal/components/dropdown/styles.css.js';
class DropdownWrapper extends ComponentWrapper {
    /**
     * The popup, while the dropdown is open.
     */
    findOpenDropdown() {
        return this.findByClassName(popupStyles.popup);
    }
    findHeader() {
        return this.findOpenDropdown()?.findByClassName(popupStyles.header) ?? null;
    }
    findContent() {
        return this.findOpenDropdown()?.findByClassName(popupStyles.content) ?? null;
    }
    findFooter() {
        return this.findOpenDropdown()?.findByClassName(popupStyles.footer) ?? null;
    }
    isOpen() {
        return this.findOpenDropdown() !== null;
    }
    /**
     * Presses Escape inside the dropdown.
     */
    pressEscape() {
        this.keydown('Escape');
    }
}
DropdownWrapper.rootSelector = `.${styles.root}`;
export default DropdownWrapper;
