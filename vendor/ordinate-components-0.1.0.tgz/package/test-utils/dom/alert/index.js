// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import ButtonWrapper from '../button';
import { ComponentWrapper } from '../core';
import styles from '../../../alert/styles.css.js';
class AlertWrapper extends ComponentWrapper {
    /**
     * The word in the margin that names the kind of note, such as "Caution".
     */
    findLabel() {
        return this.findByClassName(styles.label);
    }
    findHeader() {
        return this.findByClassName(styles.header);
    }
    findContent() {
        return this.findByClassName(styles.content);
    }
    findActionSlot() {
        return this.findByClassName(styles['action-slot']);
    }
    /**
     * Returns the close button, which is only rendered when the alert is `dismissible`.
     */
    findDismissButton() {
        return this.findByClassName(styles.dismiss)?.findComponent(ButtonWrapper) ?? null;
    }
}
AlertWrapper.rootSelector = `.${styles.alert}`;
export default AlertWrapper;
