import { SelectBaseWrapper } from '../internal/option-list';
import { findTokens, findTokenToggle } from '../internal/token-list';
import optionListStyles from '../../../internal/components/option-list/styles.css.js';
import styles from '../../../multiselect/styles.css.js';
class MultiselectWrapper extends SelectBaseWrapper {
    /**
     * Returns the selected options in the open list, without the "Select all" row.
     */
    findSelectedOptions() {
        return this.findOptions().filter(option => option.getElement().getAttribute('aria-selected') === 'true' &&
            !option.getElement().classList.contains(optionListStyles['option-extra']));
    }
    /**
     * Returns the "Select all" row while the list is open and `enableSelectAll` is set.
     */
    findSelectAll() {
        return this.findByClassName(optionListStyles['option-extra']);
    }
    /**
     * Returns the tokens of the selected options shown below the trigger.
     */
    findTokens() {
        return findTokens(this);
    }
    /**
     * Returns the button that shows or hides the tokens beyond `tokenLimit`.
     */
    findTokenToggle() {
        return findTokenToggle(this);
    }
}
MultiselectWrapper.rootSelector = `.${styles.root}`;
export default MultiselectWrapper;
