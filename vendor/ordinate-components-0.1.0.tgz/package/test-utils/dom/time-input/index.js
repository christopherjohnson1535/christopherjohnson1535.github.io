// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import inputStyles from '../../../input/styles.css.js';
import styles from '../../../time-input/styles.css.js';
class TimeInputWrapper extends ComponentWrapper {
    findNativeInput() {
        return this.findByClassName(inputStyles.input);
    }
    /**
     * Enters text as autofill or a paste would, firing `onChange` with the text brought into the mask.
     */
    setInputValue(value) {
        this.findNativeInput().setNativeValue(value);
    }
    /**
     * Types characters one by one at the end of the current text, as a user would.
     */
    typeText(text) {
        const input = this.findNativeInput();
        const element = input.getElement();
        for (const key of Array.from(text)) {
            element.setSelectionRange(element.value.length, element.value.length);
            input.keydown(key);
        }
    }
    getInputValue() {
        return this.findNativeInput().getElement().value;
    }
    isDisabled() {
        return this.findNativeInput().getElement().disabled;
    }
    isReadOnly() {
        return this.findNativeInput().getElement().readOnly;
    }
    focus() {
        this.findNativeInput().focus();
    }
    blur() {
        this.findNativeInput().blur();
    }
}
TimeInputWrapper.rootSelector = `.${styles.root}`;
export default TimeInputWrapper;
