// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import ButtonWrapper from '../button';
import { ComponentWrapper } from '../core';
import styles from '../../../dialog/styles.css.js';
class DialogWrapper extends ComponentWrapper {
    findHeader() {
        return this.findByClassName(styles.heading);
    }
    findContent() {
        return this.findByClassName(styles.content);
    }
    findFooter() {
        return this.findByClassName(styles.footer);
    }
    findDismissButton() {
        return new ButtonWrapper(this.findByClassName(styles['close-button']).getElement());
    }
    /**
     * Presses Escape inside the dialog.
     */
    pressEscape() {
        this.keydown('Escape');
    }
}
DialogWrapper.rootSelector = `.${styles.dialog}`;
export default DialogWrapper;
