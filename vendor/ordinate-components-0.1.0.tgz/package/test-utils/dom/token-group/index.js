import { ComponentWrapper } from '../core';
import { findTokens, findTokenToggle } from '../internal/token-list';
import styles from '../../../token-group/styles.css.js';
class TokenGroupWrapper extends ComponentWrapper {
    /**
     * Returns the tokens shown, without the ones hidden beyond `limit`.
     */
    findTokens() {
        return findTokens(this);
    }
    /**
     * Returns the button that shows or hides the tokens beyond `limit`.
     */
    findTokenToggle() {
        return findTokenToggle(this);
    }
}
TokenGroupWrapper.rootSelector = `.${styles.root}`;
export default TokenGroupWrapper;
