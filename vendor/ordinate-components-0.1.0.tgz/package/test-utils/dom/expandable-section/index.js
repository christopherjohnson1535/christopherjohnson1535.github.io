// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../expandable-section/styles.css.js';
class ExpandableSectionWrapper extends ComponentWrapper {
    isExpanded() {
        return this.findExpandButton().getElement().getAttribute('aria-expanded') === 'true';
    }
    /**
     * The header area: the button, info and actions, and the description.
     */
    findHeader() {
        return this.findByClassName(styles.header);
    }
    /**
     * The button that opens and closes the section.
     */
    findExpandButton() {
        return this.findByClassName(styles.trigger);
    }
    findHeaderText() {
        return this.findByClassName(styles['header-text']);
    }
    findHeaderDescription() {
        return this.findByClassName(styles.description);
    }
    findHeaderCounter() {
        return this.findByClassName(styles.counter);
    }
    findHeaderActions() {
        return this.findByClassName(styles.actions);
    }
    /**
     * The content region. It stays in the page while the section is closed, hidden with the `hidden` attribute.
     */
    findContent() {
        return this.findByClassName(styles.content);
    }
}
ExpandableSectionWrapper.rootSelector = `.${styles.root}`;
export default ExpandableSectionWrapper;
