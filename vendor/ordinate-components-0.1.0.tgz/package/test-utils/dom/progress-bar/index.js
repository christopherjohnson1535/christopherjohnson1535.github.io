// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import ButtonWrapper from '../button';
import { ComponentWrapper } from '../core';
import styles from '../../../progress-bar/styles.css.js';
class ProgressBarWrapper extends ComponentWrapper {
    findLabel() {
        return this.findByClassName(styles.label);
    }
    findDescription() {
        return this.findByClassName(styles.description);
    }
    findAdditionalInfo() {
        return this.findByClassName(styles['additional-info']);
    }
    /**
     * The element with the `progressbar` role. Only rendered while the status is `in-progress`.
     */
    findBar() {
        return this.findByClassName(styles.track);
    }
    /**
     * The printed percentage. Only rendered while the status is `in-progress`.
     */
    findPercentageText() {
        return this.findByClassName(styles.percentage);
    }
    /**
     * The text shown with the status once the operation has finished.
     */
    findResultText() {
        return this.findByClassName(styles['result-text']);
    }
    findResultButton() {
        const element = this.getElement().querySelector(`.${styles['result-button']}`);
        return element ? new ButtonWrapper(element) : null;
    }
}
ProgressBarWrapper.rootSelector = `.${styles.root}`;
export default ProgressBarWrapper;
