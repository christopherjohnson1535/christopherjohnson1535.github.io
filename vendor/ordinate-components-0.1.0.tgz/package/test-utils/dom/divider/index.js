// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../divider/styles.css.js';
class DividerWrapper extends ComponentWrapper {
    /**
     * Returns the label, or `null` when the divider has none.
     */
    findLabel() {
        return this.findByClassName(styles.label);
    }
}
DividerWrapper.rootSelector = `.${styles.divider}`;
export default DividerWrapper;
