import { TableGridWrapper } from '../internal/table-grid';
import styles from '../../../table-root/styles.css.js';
class TableRootWrapper extends TableGridWrapper {
    /**
     * The native `<table>` element.
     */
    findTableElement() {
        return this.find(`:scope > .${styles.table}`);
    }
    findNativeTable() {
        return this.findTableElement();
    }
}
TableRootWrapper.rootSelector = `.${styles.root}`;
export default TableRootWrapper;
