// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../grid/styles.css.js';
class GridWrapper extends ComponentWrapper {
    /**
     * Returns the cells, one per child, in the order of the children.
     */
    findColumns() {
        return this.findAll(`:scope > .${styles.grid} > .${styles.column}`);
    }
}
GridWrapper.rootSelector = `.${styles.root}`;
export default GridWrapper;
