// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../title-block/styles.css.js';
export class TitleBlockItemWrapper extends ComponentWrapper {
    findLabel() {
        return this.findByClassName(styles.label);
    }
    findValue() {
        return this.findByClassName(styles.value);
    }
}
TitleBlockItemWrapper.rootSelector = `.${styles.cell}`;
class TitleBlockWrapper extends ComponentWrapper {
    /**
     * The cells of the block, in order.
     */
    findItems() {
        return this.findAllComponents(TitleBlockItemWrapper);
    }
    /**
     * The cell with this label, or `null` when there is none.
     */
    findItemByLabel(label) {
        return this.findItems().find(item => item.findLabel().getText() === label) ?? null;
    }
}
TitleBlockWrapper.rootSelector = `.${styles.root}`;
export default TitleBlockWrapper;
