// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import ButtonWrapper from '../button';
import CheckboxWrapper from '../checkbox';
import { ComponentWrapper } from '../core';
import ModalWrapper from '../modal';
import RadioGroupWrapper from '../radio-group';
import styles from '../../../code-editor/styles.css.js';
function wrapButton(parent, className) {
    const element = parent.getElement().querySelector(`.${className}`);
    return element ? new ButtonWrapper(element) : null;
}
export class CodeEditorPreferencesModalWrapper extends ModalWrapper {
    findWrapLinesCheckbox() {
        return this.findByClassName(styles['preferences-wrap-lines']).findComponent(CheckboxWrapper);
    }
    findShowGutterCheckbox() {
        return this.findByClassName(styles['preferences-show-gutter']).findComponent(CheckboxWrapper);
    }
    findThemeRadioGroup() {
        return this.findByClassName(styles['preferences-theme']).findComponent(RadioGroupWrapper);
    }
    findCancelButton() {
        return wrapButton(this, styles['preferences-cancel']);
    }
    findConfirmButton() {
        return wrapButton(this, styles['preferences-confirm']);
    }
}
class CodeEditorWrapper extends ComponentWrapper {
    /**
     * The editing area, including the loading and error states.
     */
    findEditor() {
        return this.findByClassName(styles.editor);
    }
    /**
     * The editable element of the loaded editor, or `null` while the editor loads.
     */
    findEditorContent() {
        return this.findByClassName(styles.surface)?.find('[contenteditable]') ?? null;
    }
    findLoadingState() {
        return this.findByClassName(styles['loading-state']);
    }
    findErrorState() {
        return this.findByClassName(styles['error-state']);
    }
    /**
     * The button in the error state that loads the editor engine again.
     */
    findErrorRecoveryButton() {
        return wrapButton(this, styles['error-state-recovery']);
    }
    findStatusBar() {
        return this.findByClassName(styles['status-bar']);
    }
    findLanguageLabel() {
        return this.findByClassName(styles.language);
    }
    /**
     * The cursor position in the status bar, shown once the editor has loaded.
     */
    findCursorPosition() {
        return this.findByClassName(styles['cursor-position']);
    }
    findErrorsCount() {
        return this.findByClassName(styles['errors-count']);
    }
    findWarningsCount() {
        return this.findByClassName(styles['warnings-count']);
    }
    /**
     * The status bar toggle that makes Tab move focus out of the editor.
     */
    findTabFocusToggle() {
        return this.findByClassName(styles['tab-focus-toggle']);
    }
    findPreferencesButton() {
        return this.findByClassName(styles['preferences-button']);
    }
    /**
     * The preferences modal, or `null` while it is closed.
     */
    findPreferencesModal() {
        return this.findComponent(CodeEditorPreferencesModalWrapper);
    }
    findResizeHandle() {
        return this.findByClassName(styles['resize-handle']);
    }
}
CodeEditorWrapper.rootSelector = `.${styles.root}`;
export default CodeEditorWrapper;
