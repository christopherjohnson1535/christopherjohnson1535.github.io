// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import floatingPanelStyles from '../../../internal/components/floating-panel/styles.css.js';
import styles from '../../../tooltip/styles.css.js';
class TooltipWrapper extends ComponentWrapper {
    /**
     * The element wrapping the trigger passed as `children`.
     */
    findTrigger() {
        return this.findByClassName(styles.trigger);
    }
    /**
     * The tooltip text. It stays in the document while hidden, because the trigger refers to it.
     */
    findContent() {
        return this.findByClassName(styles.tooltip);
    }
    /**
     * The short stem between the tooltip and its trigger. It is drawing only and hidden from screen readers.
     */
    findStem() {
        return this.findContent().findByClassName(floatingPanelStyles.leader);
    }
    isVisible() {
        return !this.findContent().getElement().hidden;
    }
}
TooltipWrapper.rootSelector = `.${styles.root}`;
export default TooltipWrapper;
