// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../form/styles.css.js';
class FormWrapper extends ComponentWrapper {
    findReference() {
        return this.findByClassName(styles.reference);
    }
    findHeader() {
        return this.findByClassName(styles.header);
    }
    findContent() {
        return this.findByClassName(styles.content);
    }
    findActions() {
        return this.findByClassName(styles.actions);
    }
    findSecondaryActions() {
        return this.findByClassName(styles['secondary-actions']);
    }
    findError() {
        return this.findByClassName(styles['error-text']);
    }
}
FormWrapper.rootSelector = `.${styles.root}`;
export default FormWrapper;
