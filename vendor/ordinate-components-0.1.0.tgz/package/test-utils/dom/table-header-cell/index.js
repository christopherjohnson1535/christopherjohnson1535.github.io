// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../table-header-cell/styles.css.js';
class TableHeaderCellWrapper extends ComponentWrapper {
    /**
     * The button that sorts by this column, or `null` when the column cannot be sorted.
     */
    findSortingButton() {
        return this.find(`.${styles['sorting-button']}`);
    }
    /**
     * The current order of a sortable column, from its `aria-sort` attribute: `ascending`, `descending`
     * or `none`. `null` when the column cannot be sorted.
     */
    getSortingState() {
        return this.getElement().getAttribute('aria-sort');
    }
    findResizer() {
        return this.find(`.${styles.resizer}`);
    }
    /**
     * The select-all checkbox of a selection column heading.
     */
    findSelectionControl() {
        return this.find(':scope input');
    }
}
TableHeaderCellWrapper.rootSelector = `.${styles.root}`;
export default TableHeaderCellWrapper;
