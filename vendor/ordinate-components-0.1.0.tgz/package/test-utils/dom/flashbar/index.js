// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import ButtonWrapper from '../button';
import { ComponentWrapper } from '../core';
import styles from '../../../flashbar/styles.css.js';
export class FlashWrapper extends ComponentWrapper {
    /**
     * The numbered circle in the item's margin. It shows the item's place in the list and is hidden from
     * screen readers.
     */
    findMarker() {
        return this.findByClassName(styles['marker-number']);
    }
    findStatusIcon() {
        return this.findByClassName(styles['status-icon']);
    }
    findHeader() {
        return this.findByClassName(styles.header);
    }
    findContent() {
        return this.findByClassName(styles.content);
    }
    findActionSlot() {
        return this.findByClassName(styles['action-slot']);
    }
    /**
     * Returns the close button, which is only rendered when the item is `dismissible`.
     */
    findDismissButton() {
        return this.findByClassName(styles.dismiss)?.findComponent(ButtonWrapper) ?? null;
    }
}
FlashWrapper.rootSelector = `.${styles.flash}`;
class FlashbarWrapper extends ComponentWrapper {
    /**
     * The items that are shown. While a stack is collapsed, that is only the first item.
     */
    findItems() {
        return this.findAllComponents(FlashWrapper, ':not([hidden])');
    }
    /**
     * The shown items of one type.
     */
    findItemsByType(type) {
        return this.findAllComponents(FlashWrapper, `.${styles[`type-${type}`]}:not([hidden])`);
    }
    /**
     * The button that expands and collapses a stack. Only rendered when `stackItems` is set and there are two
     * or more items.
     */
    findNotificationBar() {
        return this.findByClassName(styles['notification-bar']);
    }
    isStackExpanded() {
        return this.findNotificationBar()?.getElement().getAttribute('aria-expanded') === 'true';
    }
}
FlashbarWrapper.rootSelector = `.${styles.root}`;
export default FlashbarWrapper;
