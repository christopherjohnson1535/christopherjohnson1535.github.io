// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import ButtonWrapper from '../button';
import { ComponentWrapper } from '../core';
import alertStyles from '../../../alert/styles.css.js';
import styles from '../../../flashbar/styles.css.js';
const legacyTypes = {
    info: 'note',
    success: 'complete',
    warning: 'caution',
    error: 'fault',
    'in-progress': 'note',
};
export class FlashWrapper extends ComponentWrapper {
    /**
     * The word in the item's margin that names its type, such as "Fault", or "Underway" while it is loading.
     */
    findCaption() {
        return this.findByClassName(alertStyles.label);
    }
    /**
     * Deprecated: items are no longer numbered. Returns the word in the margin, as `findCaption` does.
     */
    findMarker() {
        return this.findCaption();
    }
    findStatusIcon() {
        return this.findByClassName(alertStyles.icon);
    }
    findHeader() {
        return this.findByClassName(alertStyles.header);
    }
    findContent() {
        return this.findByClassName(alertStyles.content);
    }
    findActionSlot() {
        return this.findByClassName(alertStyles['action-slot']);
    }
    /**
     * Returns the close button, which is only rendered when the item is `dismissible`.
     */
    findDismissButton() {
        return this.findByClassName(alertStyles.dismiss)?.findComponent(ButtonWrapper) ?? null;
    }
    /**
     * Whether the item is loading and shows the underway spinner.
     */
    isUnderway() {
        return this.getElement().classList.contains(styles.underway);
    }
}
FlashWrapper.rootSelector = `.${styles.flash}`;
class FlashbarWrapper extends ComponentWrapper {
    /**
     * The items that are shown. While a stack is collapsed, that is only the first item.
     */
    findItems() {
        return this.findAllComponents(FlashWrapper, ':not([hidden])');
    }
    /**
     * The shown items of one type. The old type names are accepted too.
     */
    findItemsByType(type) {
        const current = legacyTypes[type] ?? type;
        return this.findAllComponents(FlashWrapper, `.${styles[`type-${current}`]}:not([hidden])`);
    }
    /**
     * The summary row under a stack, with a count for each type. Only rendered when `stackItems` is set and
     * there are two or more items.
     */
    findSummary() {
        return this.findByClassName(styles.summary);
    }
    /**
     * The counts in the summary row, in order, such as "2 faults".
     */
    findSummaryCounts() {
        return this.findAllByClassName(styles.count);
    }
    /**
     * The button that shows every item of a stack and collapses it again. Only rendered when `stackItems` is
     * set and there are two or more items.
     */
    findNotificationBar() {
        return this.findByClassName(styles['notification-bar']);
    }
    isStackExpanded() {
        return this.findNotificationBar()?.getElement().getAttribute('aria-expanded') === 'true';
    }
}
FlashbarWrapper.rootSelector = `.${styles.root}`;
export default FlashbarWrapper;
