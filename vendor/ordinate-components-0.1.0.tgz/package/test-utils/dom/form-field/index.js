// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../form-field/styles.css.js';
class FormFieldWrapper extends ComponentWrapper {
    findLabel() {
        return this.findByClassName(styles.label);
    }
    findInfo() {
        return this.findByClassName(styles.info);
    }
    findDescription() {
        return this.findByClassName(styles.description);
    }
    findControl() {
        return this.findByClassName(styles.control);
    }
    findSecondaryControl() {
        return this.findByClassName(styles['secondary-control']);
    }
    findError() {
        return this.findByClassName(styles.error);
    }
    findWarning() {
        return this.findByClassName(styles.warning);
    }
    findConstraint() {
        return this.findByClassName(styles.constraint);
    }
    /**
     * The visible character count. Screen readers get a copy that updates once typing pauses.
     */
    findCharacterCount() {
        return this.findByClassName(styles['character-count']);
    }
}
FormFieldWrapper.rootSelector = `.${styles.root}`;
export default FormFieldWrapper;
