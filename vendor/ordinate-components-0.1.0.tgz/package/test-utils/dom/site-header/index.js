// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../site-header/styles.css.js';
class SiteHeaderWrapper extends ComponentWrapper {
    findBrand() {
        return this.findByClassName(styles.brand);
    }
    findNotice() {
        return this.findByClassName(styles['notice-inner']);
    }
    /**
     * Returns the navigation landmark, which is only rendered when there are `links`.
     */
    findNavigation() {
        return this.findByClassName(styles.navigation);
    }
    findLinks() {
        return this.findAllByClassName(styles.link);
    }
    findCurrentLink() {
        return this.find(`.${styles.link}[aria-current="page"]`);
    }
    /**
     * Returns the button that shows the links when they are folded into a menu. It is in the page
     * at every width and hidden by styles when the links fit.
     */
    findMenuButton() {
        return this.findByClassName(styles['menu-button']);
    }
    isMenuOpen() {
        return this.findMenuButton()?.getElement().getAttribute('aria-expanded') === 'true';
    }
    findActions() {
        return this.findByClassName(styles.actions);
    }
}
SiteHeaderWrapper.rootSelector = `.${styles.root}`;
export default SiteHeaderWrapper;
