// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../help-panel/styles.css.js';
class HelpPanelWrapper extends ComponentWrapper {
    findHeader() {
        return this.findByClassName(styles.header);
    }
    findContent() {
        return this.findByClassName(styles.content);
    }
    findFooter() {
        return this.findByClassName(styles.footer);
    }
    /**
     * The loading indicator and its text, shown while `loading` is set.
     */
    findLoadingStatus() {
        return this.findByClassName(styles.loading);
    }
}
HelpPanelWrapper.rootSelector = `.${styles.root}`;
export default HelpPanelWrapper;
