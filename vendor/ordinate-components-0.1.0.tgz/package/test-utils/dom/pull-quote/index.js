// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../pull-quote/styles.css.js';
class PullQuoteWrapper extends ComponentWrapper {
    /**
     * Returns the `<blockquote>` with the quoted words.
     */
    findQuote() {
        return this.findByClassName(styles.quote);
    }
    findAttribution() {
        return this.findByClassName(styles.attribution);
    }
    /**
     * Returns the oversized quotation mark of the `hanging` variant.
     */
    findMark() {
        return this.findByClassName(styles.mark);
    }
}
PullQuoteWrapper.rootSelector = `.${styles.root}`;
export default PullQuoteWrapper;
