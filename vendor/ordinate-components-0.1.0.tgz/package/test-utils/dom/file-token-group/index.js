// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import ButtonWrapper from '../button';
import { ComponentWrapper } from '../core';
import TokenWrapper from '../token';
import styles from '../../../file-token-group/styles.css.js';
import spinnerStyles from '../../../spinner/styles.css.js';
export class FileTokenWrapper extends ComponentWrapper {
    findFileName() {
        return this.findByClassName(styles['file-name']);
    }
    findFileSize() {
        return this.findByClassName(styles['file-size']);
    }
    findFileLastModified() {
        return this.findByClassName(styles['file-last-modified']);
    }
    /**
     * The preview of an image file, shown with `showFileThumbnail`.
     */
    findFileThumbnail() {
        return this.findByClassName(styles['thumbnail-image']);
    }
    findFileError() {
        return this.findByClassName(styles['error-text']);
    }
    findFileWarning() {
        return this.findByClassName(styles['warning-text']);
    }
    /**
     * The button that removes the file. Read-only groups and groups without `onDismiss` have none.
     */
    findRemoveButton() {
        return this.findComponent(TokenWrapper)?.findDismissButton() ?? null;
    }
    isLoading() {
        return this.findByClassName(spinnerStyles.root) !== null;
    }
}
FileTokenWrapper.rootSelector = `.${styles.item}`;
class FileTokenGroupWrapper extends ComponentWrapper {
    /**
     * Returns the file tokens shown, without the ones hidden beyond `limit`.
     */
    findFileTokens() {
        return this.findAllComponents(FileTokenWrapper);
    }
    /**
     * Returns the token of the file at this position, counting from 1.
     */
    findFileToken(position) {
        return this.findFileTokens()[position - 1] ?? null;
    }
    /**
     * Returns the button that shows or hides the files beyond `limit`.
     */
    findTokenToggle() {
        const element = this.findByClassName(styles.toggle);
        return element ? new ButtonWrapper(element.getElement()) : null;
    }
}
FileTokenGroupWrapper.rootSelector = `.${styles.root}`;
export default FileTokenGroupWrapper;
