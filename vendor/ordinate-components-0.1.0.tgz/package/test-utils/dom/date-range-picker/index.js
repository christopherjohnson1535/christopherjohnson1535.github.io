// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import ButtonWrapper from '../button';
import { CalendarGridWrapper } from '../calendar';
import { ComponentWrapper } from '../core';
import DateInputWrapper from '../date-input';
import RadioGroupWrapper from '../radio-group';
import SegmentedControlWrapper from '../segmented-control';
import TimeInputWrapper from '../time-input';
import styles from '../../../date-range-picker/styles.css.js';
import dropdownStyles from '../../../internal/components/dropdown/styles.css.js';
class DateRangePickerWrapper extends ComponentWrapper {
    findTrigger() {
        return this.findByClassName(styles.trigger);
    }
    /**
     * Returns the text shown in the trigger: the formatted range or the placeholder.
     */
    getTriggerText() {
        return this.findTrigger().getText();
    }
    openDropdown() {
        this.findTrigger().click();
    }
    /**
     * Returns the popup while it is open.
     */
    findDropdown() {
        return this.findByClassName(dropdownStyles.popup);
    }
    findModeSwitch() {
        return this.findDropdown()?.findComponent(SegmentedControlWrapper) ?? null;
    }
    /**
     * Returns the month grids of absolute mode, with finders for days and the paging buttons.
     */
    findCalendar() {
        const months = this.findByClassName(styles.months);
        return months ? new CalendarGridWrapper(months.getElement()) : null;
    }
    findStartDateInput() {
        return this.findPart(DateInputWrapper, styles['start-date']);
    }
    findStartTimeInput() {
        return this.findPart(TimeInputWrapper, styles['start-time']);
    }
    findEndDateInput() {
        return this.findPart(DateInputWrapper, styles['end-date']);
    }
    findEndTimeInput() {
        return this.findPart(TimeInputWrapper, styles['end-time']);
    }
    /**
     * Returns the list of relative ranges in relative mode.
     */
    findRelativeRanges() {
        const relative = this.findByClassName(styles.relative);
        return relative?.findComponent(RadioGroupWrapper) ?? null;
    }
    /**
     * Returns the custom duration's amount and unit fields while the custom range is chosen.
     */
    findCustomRange() {
        return this.findByClassName(styles.custom);
    }
    findValidationError() {
        return this.findByClassName(styles.error);
    }
    findApplyButton() {
        return this.findAction(1);
    }
    findCancelButton() {
        return this.findAction(2);
    }
    findClearButton() {
        const element = this.findByClassName(styles.clear);
        return element ? new ButtonWrapper(element.getElement()) : null;
    }
    findPart(Wrapper, className) {
        const element = this.findByClassName(className);
        return element ? new Wrapper(element.getElement()) : null;
    }
    // The actions are counted from the end, Apply last and Cancel before it, since the clear button is optional.
    findAction(fromEnd) {
        const actions = this.findByClassName(styles.actions);
        const buttons = actions ? actions.getElement().querySelectorAll(':scope > button') : [];
        const button = buttons[buttons.length - fromEnd];
        return button ? new ButtonWrapper(button) : null;
    }
}
DateRangePickerWrapper.rootSelector = `.${styles.root}`;
export default DateRangePickerWrapper;
