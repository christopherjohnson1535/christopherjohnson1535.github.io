// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../opening-hours/styles.css.js';
class OpeningHoursWrapper extends ComponentWrapper {
    findCaption() {
        return this.findByClassName(styles.caption);
    }
    /**
     * The rows of the table, one per day or per free-form row, in order.
     */
    findRows() {
        return this.findAllByClassName(styles.row);
    }
    /**
     * The row marked as today, once `highlightToday` has found it.
     */
    findTodayRow() {
        return this.findByClassName(styles.today);
    }
    /**
     * The rows of closed days.
     */
    findClosedRows() {
        return this.findAllByClassName(styles.closed);
    }
    /**
     * The day's name in a row, without the today mark.
     */
    findRowLabel(row) {
        return row.findByClassName(styles['day-label']);
    }
    /**
     * The hours, or the closed text, in a row, without its note.
     */
    findRowValue(row) {
        return row.findByClassName(styles.value);
    }
    findRowNote(row) {
        return row.findByClassName(styles.note);
    }
    findTodayMarker() {
        return this.findByClassName(styles['today-marker']);
    }
}
OpeningHoursWrapper.rootSelector = `.${styles.root}`;
export default OpeningHoursWrapper;
