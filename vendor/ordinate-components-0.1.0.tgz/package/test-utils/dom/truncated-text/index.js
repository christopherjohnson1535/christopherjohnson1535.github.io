// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import TooltipWrapper from '../tooltip';
import styles from '../../../truncated-text/styles.css.js';
class TruncatedTextWrapper extends ComponentWrapper {
    /**
     * Returns the element that holds the text and is cut when it does not fit.
     */
    findText() {
        return this.findByClassName(styles.text);
    }
    /**
     * Whether the text is cut, which is when hovering or focusing it shows the full text in a tooltip.
     */
    isTruncated() {
        return this.findText().getElement().dataset.truncated === 'true';
    }
    findTooltip() {
        return this.findComponent(TooltipWrapper);
    }
}
TruncatedTextWrapper.rootSelector = `.${styles.root}`;
export default TruncatedTextWrapper;
