// jsdom has no DataTransfer, so drag events get a stand-in with the parts the components read.
function dragEvent(type, files) {
    const event = new Event(type, { bubbles: true, cancelable: true });
    Object.defineProperty(event, 'dataTransfer', {
        value: { files, types: ['Files'], items: [], dropEffect: 'none', effectAllowed: 'all' },
    });
    return event;
}
/**
 * Starts dragging files over an element, without dropping them.
 */
export function dragFilesOver(target, files) {
    target.fireEvent(dragEvent('dragenter', files));
    target.fireEvent(dragEvent('dragover', files));
}
/**
 * Drags files onto an element and drops them, as a user dragging files from their desktop would.
 */
export function dropFiles(target, files) {
    dragFilesOver(target, files);
    target.fireEvent(dragEvent('drop', files));
}
/**
 * Chooses files in a native file input, as if the user had picked them in the file chooser.
 */
export function chooseFiles(input, files) {
    Object.defineProperty(input.getElement(), 'files', { configurable: true, value: files });
    input.fireEvent(new Event('change', { bubbles: true }));
}
