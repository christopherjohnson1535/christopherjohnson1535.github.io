// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../internal/components/abstract-switch/styles.css.js';
/**
 * Parts shared by the checkbox, radio button and toggle wrappers.
 */
export class AbstractSwitchWrapper extends ComponentWrapper {
    findNativeInput() {
        return this.findByClassName(styles['native-input']);
    }
    findLabel() {
        return this.findByClassName(styles.label);
    }
    findDescription() {
        return this.findByClassName(styles.description);
    }
    isChecked() {
        return this.findNativeInput().getElement().checked;
    }
    isDisabled() {
        return this.findNativeInput().getElement().disabled;
    }
}
