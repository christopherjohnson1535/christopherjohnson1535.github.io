// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../pagination/styles.css.js';
class PaginationWrapper extends ComponentWrapper {
    findPreviousPageButton() {
        return this.findByClassName(styles['previous-page']);
    }
    findNextPageButton() {
        return this.findByClassName(styles['next-page']);
    }
    /**
     * Returns the page number buttons that are shown, in order. Ellipses are not included.
     */
    findPageNumbers() {
        return this.findAllByClassName(styles['page-number']);
    }
    /**
     * Returns the button for a page number, if it is shown. Page numbers are lettered with leading zeros,
     * such as "03", so they are compared as numbers.
     */
    findPageNumberByIndex(pageIndex) {
        return this.findPageNumbers().find(button => Number(button.getText()) === pageIndex) ?? null;
    }
    /**
     * The current page in small capitals before the page numbers, shown with `showPageLabel`.
     */
    findPageLabel() {
        return this.findByClassName(styles['page-label']);
    }
    findCurrentPage() {
        return this.findByClassName(styles['current-page']);
    }
    findEllipses() {
        return this.findAllByClassName(styles.ellipsis);
    }
    isDisabled() {
        return this.getElement().classList.contains(styles['root-disabled']);
    }
}
PaginationWrapper.rootSelector = `.${styles.root}`;
export default PaginationWrapper;
