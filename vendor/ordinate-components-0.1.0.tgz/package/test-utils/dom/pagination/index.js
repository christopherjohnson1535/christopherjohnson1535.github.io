// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../pagination/styles.css.js';
class PaginationWrapper extends ComponentWrapper {
    findPreviousPageButton() {
        return this.findByClassName(styles['previous-page']);
    }
    findNextPageButton() {
        return this.findByClassName(styles['next-page']);
    }
    /**
     * Returns the page number buttons that are shown, in order. Ellipses are not included.
     */
    findPageNumbers() {
        return this.findAllByClassName(styles['page-number']);
    }
    /**
     * Returns the button for a page number, if it is shown.
     */
    findPageNumberByIndex(pageIndex) {
        return this.findPageNumbers().find(button => button.getText() === String(pageIndex)) ?? null;
    }
    findCurrentPage() {
        return this.findByClassName(styles['current-page']);
    }
    findEllipses() {
        return this.findAllByClassName(styles.ellipsis);
    }
    isDisabled() {
        return this.getElement().classList.contains(styles['root-disabled']);
    }
}
PaginationWrapper.rootSelector = `.${styles.root}`;
export default PaginationWrapper;
