// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../header/styles.css.js';
class HeaderWrapper extends ComponentWrapper {
    /**
     * Returns the heading text, without the counter.
     */
    findHeadingText() {
        return this.findByClassName(styles['heading-text']);
    }
    /**
     * The sheet code shown above the heading.
     */
    findCode() {
        return this.findByClassName(styles.code);
    }
    findCounter() {
        return this.findByClassName(styles.counter);
    }
    findDescription() {
        return this.findByClassName(styles.description);
    }
    findInfo() {
        return this.findByClassName(styles.info);
    }
    findActions() {
        return this.findByClassName(styles.actions);
    }
}
HeaderWrapper.rootSelector = `.${styles.root}`;
export default HeaderWrapper;
