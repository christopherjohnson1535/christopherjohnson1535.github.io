// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import ButtonDropdownWrapper from '../button-dropdown';
import { ComponentWrapper } from '../core';
import styles from '../../../top-navigation/styles.css.js';
class TopNavigationWrapper extends ComponentWrapper {
    findIdentityLink() {
        return this.find(`.${styles.identity} .${styles['identity-link']}`);
    }
    findTitle() {
        return this.find(`.${styles.identity} .${styles.title}`);
    }
    findLogo() {
        return this.find(`.${styles.identity} .${styles.logo}`);
    }
    findSearch() {
        return this.findByClassName(styles.search);
    }
    /**
     * Returns the utilities shown in the bar, in order, without the overflow menu.
     */
    findUtilities() {
        return this.findAll(`.${styles.utilities} > .${styles['utility-slot']}:not([data-overflow-menu])`);
    }
    /**
     * Returns the utility at this position among the ones shown in the bar, counting from 1.
     */
    findUtility(index) {
        return this.findUtilities()[index - 1] ?? null;
    }
    /**
     * Returns the badge dot of the utility at this position, counting from 1.
     */
    findUtilityBadge(index) {
        return this.findUtility(index)?.findByClassName(styles.badge) ?? null;
    }
    /**
     * Returns the menu that holds the utilities that do not fit, while there are any.
     */
    findOverflowMenu() {
        const slot = this.find(`.${styles.utilities} > [data-overflow-menu]`);
        return slot?.findComponent(ButtonDropdownWrapper) ?? null;
    }
}
TopNavigationWrapper.rootSelector = `.${styles.root}`;
export default TopNavigationWrapper;
