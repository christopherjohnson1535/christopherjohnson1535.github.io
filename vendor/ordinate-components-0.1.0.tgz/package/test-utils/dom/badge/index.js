// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../badge/styles.css.js';
class BadgeWrapper extends ComponentWrapper {
}
BadgeWrapper.rootSelector = `.${styles.badge}`;
export default BadgeWrapper;
