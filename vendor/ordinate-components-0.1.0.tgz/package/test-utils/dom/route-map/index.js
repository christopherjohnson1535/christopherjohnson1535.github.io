// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../route-map/styles.css.js';
class RouteMapWrapper extends ComponentWrapper {
    /**
     * Returns the rows of the map, one per line, in order. A line with an `href` is an `<a>`.
     */
    findLines() {
        return this.findAllByClassName(styles.row);
    }
    findLine(id) {
        return this.find(`.${styles.row}[data-line-id="${id.replace(/"/g, '\\"')}"]`);
    }
    findStop(id) {
        return this.find(`.${styles.stop}[data-stop-id="${id.replace(/"/g, '\\"')}"]`);
    }
    findTerminus() {
        return this.findByClassName(styles.terminus);
    }
    /**
     * Returns the ring and note around the current stop.
     */
    findCurrentStop() {
        return this.findByClassName(styles.current);
    }
    findSelectedBand() {
        return this.findByClassName(styles['band-selected']);
    }
}
RouteMapWrapper.rootSelector = `.${styles.root}`;
export default RouteMapWrapper;
