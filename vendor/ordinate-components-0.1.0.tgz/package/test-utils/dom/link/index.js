// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import iconStyles from '../../../icon/styles.css.js';
import styles from '../../../link/styles.css.js';
class LinkWrapper extends ComponentWrapper {
    findExternalIcon() {
        return this.findByClassName(iconStyles.icon);
    }
    getHref() {
        return this.getElement().getAttribute('href');
    }
}
LinkWrapper.rootSelector = `.${styles.link}`;
export default LinkWrapper;
