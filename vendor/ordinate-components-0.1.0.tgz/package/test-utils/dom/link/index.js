// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../link/styles.css.js';
class LinkWrapper extends ComponentWrapper {
    /**
     * The diagonal leader of an external link, which carries the "opens in a new tab" label.
     */
    findExternalIcon() {
        return this.findByClassName(styles['external-leader']);
    }
    getHref() {
        return this.getElement().getAttribute('href');
    }
}
LinkWrapper.rootSelector = `.${styles.link}`;
export default LinkWrapper;
