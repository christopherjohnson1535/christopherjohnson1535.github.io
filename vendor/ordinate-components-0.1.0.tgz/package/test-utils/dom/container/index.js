// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../container/styles.css.js';
class ContainerWrapper extends ComponentWrapper {
    findHeader() {
        return this.find(`:scope > .${styles.header}`);
    }
    /**
     * The plain text label drawn in the header when `header` is a string.
     */
    findHeaderLabel() {
        return this.find(`:scope > .${styles.header} > .${styles.label}`);
    }
    findContent() {
        return this.find(`:scope > .${styles.content}`);
    }
    findFooter() {
        return this.find(`:scope > .${styles.footer}`);
    }
}
ContainerWrapper.rootSelector = `.${styles.root}`;
export default ContainerWrapper;
