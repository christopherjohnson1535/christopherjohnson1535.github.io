// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../container/styles.css.js';
class ContainerWrapper extends ComponentWrapper {
    /**
     * The short reference set above the heading, such as R1.
     */
    findReference() {
        return this.find(`:scope > .${styles.layout} > .${styles.margin} > .${styles.reference}`);
    }
    findHeading() {
        return this.find(`:scope > .${styles.layout} > .${styles.margin} > .${styles.heading}`);
    }
    findDescription() {
        return this.find(`:scope > .${styles.layout} > .${styles.margin} > .${styles.description}`);
    }
    /**
     * The label of the dimension line along the top of the content.
     */
    findMeasure() {
        return this.find(`:scope > .${styles.layout} > .${styles.main} > .${styles.measure}`);
    }
    findActions() {
        return this.find(`:scope > .${styles.layout} > .${styles.main} > .${styles.actions}`);
    }
    findContent() {
        return this.find(`:scope > .${styles.layout} > .${styles.main} > .${styles.content}`);
    }
    findFooter() {
        return this.find(`:scope > .${styles.layout} > .${styles.main} > .${styles.footer}`);
    }
}
ContainerWrapper.rootSelector = `.${styles.root}`;
export default ContainerWrapper;
