// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../figure/styles.css.js';
class FigureWrapper extends ComponentWrapper {
    findMedia() {
        return this.findByClassName(styles.media);
    }
    /**
     * Returns the whole `<figcaption>`, with the label, caption and credit.
     */
    findCaption() {
        return this.findByClassName(styles.caption);
    }
    findCaptionText() {
        return this.findByClassName(styles.text);
    }
    findLabel() {
        return this.findByClassName(styles.label);
    }
    findCredit() {
        return this.findByClassName(styles.credit);
    }
}
FigureWrapper.rootSelector = `.${styles.root}`;
export default FigureWrapper;
