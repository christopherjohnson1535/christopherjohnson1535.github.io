// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper, ElementWrapper } from '../core';
import styles from '../../../tree-view/styles.css.js';
export class TreeViewItemWrapper extends ElementWrapper {
    /**
     * The ID that `getItemId` returned for the item.
     */
    getId() {
        return this.getElement().dataset.itemId ?? '';
    }
    /**
     * Whether the item is the one set by `currentItemId`.
     */
    isCurrent() {
        return this.getElement().getAttribute('aria-current') === 'true';
    }
    isExpanded() {
        return this.getElement().getAttribute('aria-expanded') === 'true';
    }
    /**
     * The expand and collapse button, or `null` for an item without children.
     */
    findToggle() {
        return this.find(`:scope > .${styles.row} .${styles.toggle}`);
    }
    findContent() {
        return this.find(`:scope > .${styles.row} .${styles.content}`);
    }
    findSecondaryContent() {
        return this.find(`:scope > .${styles.row} .${styles['secondary-content']}`);
    }
    findActions() {
        return this.find(`:scope > .${styles.row} > .${styles.actions}`);
    }
    /**
     * The item's rendered children: none while it is collapsed.
     */
    findChildItems() {
        return this.findAll(`:scope > .${styles.group} > .${styles.item}`).map(item => new TreeViewItemWrapper(item.getElement()));
    }
}
class TreeViewWrapper extends ComponentWrapper {
    /**
     * The top-level items.
     */
    findItems() {
        return this.findAll(`.${styles.tree} > .${styles.item}`).map(item => new TreeViewItemWrapper(item.getElement()));
    }
    /**
     * Every rendered item at any level, in reading order.
     */
    findVisibleItems() {
        return this.findAllByClassName(styles.item).map(item => new TreeViewItemWrapper(item.getElement()));
    }
    findItemById(id) {
        return this.findVisibleItems().find(item => item.getId() === id) ?? null;
    }
    /**
     * The item set by `currentItemId`, while it is rendered.
     */
    findCurrentItem() {
        return this.findVisibleItems().find(item => item.isCurrent()) ?? null;
    }
}
TreeViewWrapper.rootSelector = `.${styles.root}`;
export default TreeViewWrapper;
