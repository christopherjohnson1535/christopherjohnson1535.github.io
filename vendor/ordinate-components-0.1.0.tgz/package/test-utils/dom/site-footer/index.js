// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper, ElementWrapper } from '../core';
import styles from '../../../site-footer/styles.css.js';
export class SiteFooterColumnWrapper extends ElementWrapper {
    findTitle() {
        return this.findByClassName(styles['column-title']);
    }
    findLinks() {
        return this.findAllByClassName(styles.link);
    }
}
class SiteFooterWrapper extends ComponentWrapper {
    findBrand() {
        return this.findByClassName(styles.brand);
    }
    /**
     * Returns the content passed as `children`.
     */
    findContent() {
        return this.findByClassName(styles.content);
    }
    findNavigation() {
        return this.findByClassName(styles.navigation);
    }
    findColumns() {
        return this.findAllByClassName(styles.column).map(column => new SiteFooterColumnWrapper(column.getElement()));
    }
    findLegal() {
        return this.findByClassName(styles.legal);
    }
}
SiteFooterWrapper.rootSelector = `.${styles.root}`;
export default SiteFooterWrapper;
