// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../status-indicator/styles.css.js';
class StatusIndicatorWrapper extends ComponentWrapper {
    findStatusIcon() {
        return this.findByClassName(styles.icon);
    }
    findText() {
        return this.findByClassName(styles.text);
    }
}
StatusIndicatorWrapper.rootSelector = `.${styles.root}`;
export default StatusIndicatorWrapper;
