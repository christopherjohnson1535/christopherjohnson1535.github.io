// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../call-to-action/styles.css.js';
class CallToActionWrapper extends ComponentWrapper {
    findHeading() {
        return this.findByClassName(styles.heading);
    }
    findDescription() {
        return this.findByClassName(styles.description);
    }
    findActions() {
        return this.findByClassName(styles.actions);
    }
    /**
     * Returns the content passed as `children`, such as a sign-up form.
     */
    findContent() {
        return this.findByClassName(styles.content);
    }
}
CallToActionWrapper.rootSelector = `.${styles.root}`;
export default CallToActionWrapper;
