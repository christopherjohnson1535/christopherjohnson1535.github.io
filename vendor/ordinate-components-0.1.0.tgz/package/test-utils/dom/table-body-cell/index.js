// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import selectionStyles from '../../../internal/components/table-selection-control/styles.css.js';
import styles from '../../../table-body-cell/styles.css.js';
class TableBodyCellWrapper extends ComponentWrapper {
    /**
     * The checkbox or radio button of a selection cell.
     */
    findSelectionControl() {
        return this.find(`:scope > .${selectionStyles.root} input`);
    }
    /**
     * The circled tag of a row tag cell.
     */
    findRowTag() {
        return this.find(`:scope > .${styles.tag}`);
    }
    /**
     * Whether the cell is the header of its row.
     */
    isRowHeader() {
        return this.getElement().tagName === 'TH';
    }
}
TableBodyCellWrapper.rootSelector = `.${styles.root}`;
export default TableBodyCellWrapper;
