// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../terminal/styles.css.js';
class TerminalWrapper extends ComponentWrapper {
    /**
     * Returns every line, in order.
     */
    findLines() {
        return this.findAllByClassName(styles.line);
    }
    /**
     * Returns the lines of one type, such as `command`.
     */
    findLinesOfType(type) {
        return this.findAllByClassName(styles[`type-${type}`]);
    }
    findHighlightedLines() {
        return this.findAllByClassName(styles.highlighted);
    }
}
TerminalWrapper.rootSelector = `.${styles.root}`;
export default TerminalWrapper;
