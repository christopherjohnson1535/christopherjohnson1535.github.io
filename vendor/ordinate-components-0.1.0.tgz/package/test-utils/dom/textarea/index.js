// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { ComponentWrapper } from '../core';
import styles from '../../../textarea/styles.css.js';
class TextareaWrapper extends ComponentWrapper {
    findNativeTextarea() {
        return this.findByClassName(styles.textarea);
    }
    /**
     * Types a new value into the textarea, firing `onChange`.
     */
    setTextareaValue(value) {
        this.findNativeTextarea().setNativeValue(value);
    }
    getTextareaValue() {
        return this.findNativeTextarea().getElement().value;
    }
}
TextareaWrapper.rootSelector = `.${styles.root}`;
export default TextareaWrapper;
