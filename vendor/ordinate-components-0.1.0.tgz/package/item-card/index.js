// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalItemCard } from './internal';
export default function ItemCard({ header, description, reference, kind = 'neutral', children, footer, actions, media, selected = false, selectionControl, disabled = false, variant = 'default', ...props }) {
    return (_jsx(InternalItemCard, { ...getBaseProps(props), header: header, description: description, reference: reference, kind: kind, footer: footer, actions: actions, media: media, selected: selected, selectionControl: selectionControl, disabled: disabled, variant: variant, children: children }));
}
