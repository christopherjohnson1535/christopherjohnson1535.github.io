// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalColumnLayout } from './internal';
export default function ColumnLayout({ columns = 1, variant = 'default', borders = 'none', minColumnWidth, disableGutters = false, children, ...props }) {
    return (_jsx(InternalColumnLayout, { ...getBaseProps(props), columns: columns, variant: variant, borders: borders, minColumnWidth: minColumnWidth, disableGutters: disableGutters, children: children }));
}
