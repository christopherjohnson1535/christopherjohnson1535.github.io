// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { breakpointMinWidths } from '../internal/breakpoints';
function breakpointLimit(width) {
    if (width < breakpointMinWidths.xxs) {
        return 1;
    }
    return width < breakpointMinWidths.xs ? 2 : Infinity;
}
function minWidthLimit(width, minColumnWidth, gap) {
    return Math.floor((width + gap) / (minColumnWidth + gap));
}
/**
 * How many columns fit. Before the layout is measured, such as while rendering on the server, it
 * assumes there is room for all of them.
 */
export function getColumnCount({ columns, width, minColumnWidth, gap }) {
    if (width === null) {
        return columns;
    }
    const limit = minColumnWidth && minColumnWidth > 0 ? minWidthLimit(width, minColumnWidth, gap) : breakpointLimit(width);
    return Math.max(1, Math.min(columns, limit));
}
