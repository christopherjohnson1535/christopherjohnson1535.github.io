import { jsx as _jsx } from "react/jsx-runtime";
// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { useRef, useState } from 'react';
import clsx from 'clsx';
import { childKey, flattenChildren } from '../internal/flatten-children';
import { useResizeObserver } from '../internal/hooks/use-resize-observer';
import { getColumnCount } from './column-count';
import styles from './styles.css.js';
function useMeasurement(ref) {
    const [measurement, setMeasurement] = useState({ width: null, gap: 0 });
    useResizeObserver(ref, () => {
        const element = ref.current;
        if (!element) {
            return;
        }
        const width = element.clientWidth > 0 ? element.clientWidth : null;
        const gap = parseFloat(window.getComputedStyle(element).columnGap) || 0;
        setMeasurement(current => (current.width === width && current.gap === gap ? current : { width, gap }));
    });
    return measurement;
}
function ruleClasses(variant, borders) {
    if (variant === 'text-grid') {
        return styles['vertical-rules'];
    }
    return clsx((borders === 'vertical' || borders === 'all') && styles['vertical-rules'], (borders === 'horizontal' || borders === 'all') && styles['horizontal-rules']);
}
// Where a cell sits decides which of its rules are drawn and how far they reach.
function cellPosition(index, total, count) {
    const column = index % count;
    const lastRowStart = Math.floor((total - 1) / count) * count;
    return clsx(column === 0 && styles['first-in-row'], (column === count - 1 || index === total - 1) && styles['last-in-row'], index < count && styles['first-row'], index >= lastRowStart && styles['last-row']);
}
export function InternalColumnLayout({ columns = 1, variant = 'default', borders = 'none', minColumnWidth, disableGutters = false, children, ...rest }) {
    const rootRef = useRef(null);
    const { width, gap } = useMeasurement(rootRef);
    const count = getColumnCount({ columns, width, minColumnWidth, gap });
    const items = flattenChildren(children);
    return (_jsx("div", { ...rest, ref: rootRef, className: clsx(styles.root, styles[`variant-${variant}`], ruleClasses(variant, borders), !disableGutters && styles.gutters), style: { '--column-count': count }, "data-column-count": count, children: items.map((child, index) => (_jsx("div", { className: clsx(styles.item, cellPosition(index, items.length, count)), children: child }, childKey(child, index)))) }));
}
