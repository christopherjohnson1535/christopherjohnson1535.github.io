import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React, { useEffect, useId, useImperativeHandle, useRef } from 'react';
import clsx from 'clsx';
import { InternalButton } from '../button/internal';
import { InternalIcon } from '../icon/internal';
import { useCommandLine } from '../internal/context/command-line-context';
import { useFormFieldContext } from '../internal/context/form-field-context';
import { fireKeyboardEvent, fireNonCancelableEvent } from '../internal/events';
import { useInternalI18n } from '../internal/i18n/context';
import styles from './styles.css.js';
function toAutoCompleteValue(autoComplete) {
    if (typeof autoComplete === 'string') {
        return autoComplete;
    }
    return autoComplete ? 'on' : 'off';
}
const commandLineShortcut = '/';
function isTypingTarget(target) {
    if (!(target instanceof HTMLElement)) {
        return false;
    }
    return target.isContentEditable || ['INPUT', 'TEXTAREA', 'SELECT'].includes(target.tagName);
}
// Moves focus to the input when the user presses the shortcut outside any field.
function useShortcutFocus(enabled, inputRef) {
    useEffect(() => {
        if (!enabled) {
            return;
        }
        const onKeyDown = (event) => {
            const modified = event.ctrlKey || event.metaKey || event.altKey;
            if (event.key !== commandLineShortcut || modified || event.defaultPrevented || isTypingTarget(event.target)) {
                return;
            }
            event.preventDefault();
            inputRef.current?.focus();
        };
        document.addEventListener('keydown', onKeyDown);
        return () => document.removeEventListener('keydown', onKeyDown);
    }, [enabled, inputRef]);
}
export const InternalInput = React.forwardRef(({ value, onChange, type = 'text', inputMode, step, placeholder, inlineLabelText, disabled = false, readOnly = false, autoFocus, ariaLabel, ariaRequired, clearAriaLabel, name, autoComplete = true, disableBrowserAutocorrect = false, spellcheck, onFocus, onBlur, onKeyDown, onKeyUp, controlId, ariaLabelledby, ariaDescribedby, invalid, warning, nativeInputAttributes, commandLine: commandLineProp, ...rest }, ref) => {
    const i18n = useInternalI18n('input');
    const inputRef = useRef(null);
    useImperativeHandle(ref, () => ({
        focus: () => inputRef.current?.focus(),
        select: () => inputRef.current?.select(),
    }));
    const generatedId = useId();
    const field = useFormFieldContext({ controlId, ariaLabelledby, ariaDescribedby, invalid, warning });
    const inputId = field.controlId ?? (inlineLabelText ? `${generatedId}input` : undefined);
    const isSearch = type === 'search';
    const showClearButton = isSearch && value !== '' && !disabled && !readOnly;
    const commandLineFromContext = useCommandLine();
    const commandLine = (commandLineProp ?? commandLineFromContext) && !inlineLabelText;
    const shortcutEnabled = commandLine && !disabled && !readOnly;
    useShortcutFocus(shortcutEnabled, inputRef);
    const clear = () => {
        inputRef.current?.focus();
        fireNonCancelableEvent(onChange, { value: '' });
    };
    return (_jsxs("div", { ...rest, className: clsx(styles.root, isSearch && styles['root-search'], commandLine && styles['command-line'], field.invalid && styles.invalid, field.warning && !field.invalid && styles.warning, readOnly && !disabled && styles['read-only'], disabled && styles.disabled), children: [commandLine ? (_jsx("span", { className: styles.prompt, "aria-hidden": "true", children: '\u203a' })) : (isSearch && _jsx(InternalIcon, { className: styles['search-icon'], name: "find" })), _jsxs("div", { className: styles.main, children: [inlineLabelText && (_jsx("label", { className: styles['inline-label'], htmlFor: inputId, children: inlineLabelText })), _jsx("input", { ref: inputRef, id: inputId, className: styles.input, type: type, inputMode: inputMode, step: step, value: value, placeholder: placeholder, disabled: disabled, readOnly: readOnly, autoFocus: autoFocus, name: name, autoComplete: toAutoCompleteValue(autoComplete), autoCorrect: disableBrowserAutocorrect ? 'off' : undefined, autoCapitalize: disableBrowserAutocorrect ? 'off' : undefined, spellCheck: spellcheck, "aria-label": ariaLabel, "aria-labelledby": ariaLabel && !ariaLabelledby ? undefined : field.ariaLabelledby, "aria-describedby": field.ariaDescribedby, "aria-invalid": field.invalid ? 'true' : undefined, "aria-required": ariaRequired ? 'true' : undefined, "aria-keyshortcuts": shortcutEnabled ? commandLineShortcut : undefined, onChange: event => fireNonCancelableEvent(onChange, { value: event.target.value }), onFocus: () => fireNonCancelableEvent(onFocus, null), onBlur: () => fireNonCancelableEvent(onBlur, null), onKeyDown: onKeyDown && (event => fireKeyboardEvent(onKeyDown, event)), onKeyUp: onKeyUp && (event => fireKeyboardEvent(onKeyUp, event)), 
                        // Browsers change a focused number input when the page scrolls over it, which is easy to do by accident.
                        onWheel: type === 'number' ? event => event.currentTarget.blur() : undefined, ...nativeInputAttributes })] }), shortcutEnabled && value === '' && (_jsx("kbd", { className: styles['key-hint'], "aria-hidden": "true", children: commandLineShortcut })), showClearButton && (_jsx(InternalButton, { className: styles['clear-button'], variant: "icon", formAction: "none", iconName: "close", ariaLabel: i18n('clearAriaLabel', clearAriaLabel), onClick: clear }))] }));
});
