import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import clsx from 'clsx';
import { Band } from '../internal/components/band';
import { Heading } from '../internal/components/heading';
import styles from './styles.css.js';
export function InternalSection({ children, heading, description, headingLevel, actions, tone = 'default', width = 'default', spacing = 'default', rule = 'none', ...rest }) {
    const hasHeader = Boolean(heading || description || actions);
    return (_jsxs(Band, { ...rest, tag: "section", tone: tone, width: width, spacing: spacing, className: clsx(styles.root, styles[`tone-${tone}`]), children: [rule === 'double' && _jsx("div", { className: styles['double-rule'], "aria-hidden": "true" }), _jsxs("div", { className: clsx(styles.body, rule !== 'none' && styles[`rule-${rule}`]), children: [hasHeader && (_jsxs("div", { className: styles.header, children: [(heading || description) && (_jsxs("div", { className: styles.titles, children: [heading && (_jsx(Heading, { level: headingLevel, defaultLevel: 2, className: styles.heading, children: heading })), description && _jsx("div", { className: styles.description, children: description })] })), actions && _jsx("div", { className: styles.actions, children: actions })] })), children && _jsx("div", { className: styles.content, children: children })] })] }));
}
