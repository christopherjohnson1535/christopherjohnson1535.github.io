// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalSection } from './internal';
export default function Section({ children, heading, description, headingLevel = 2, actions, tone = 'default', width = 'default', spacing = 'default', rule = 'none', ...props }) {
    return (_jsx(InternalSection, { ...getBaseProps(props), heading: heading, description: description, headingLevel: headingLevel, actions: actions, tone: tone, width: width, spacing: spacing, rule: rule, children: children }));
}
