// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import React from 'react';
import { getBaseProps } from '../internal/base-component';
import { InternalSegmentedControl } from './internal';
const SegmentedControl = React.forwardRef(({ options = [], selectedId, onChange, label, ariaLabelledby, ...props }, ref) => (_jsx(InternalSegmentedControl, { ...getBaseProps(props), ref: ref, options: options, selectedId: selectedId, onChange: onChange, label: label, ariaLabelledby: ariaLabelledby })));
SegmentedControl.displayName = 'SegmentedControl';
export default SegmentedControl;
