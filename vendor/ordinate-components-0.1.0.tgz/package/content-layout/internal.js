import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import clsx from 'clsx';
import styles from './styles.css.js';
export function InternalContentLayout({ header, breadcrumbs, notifications, headerVariant = 'default', maxContentWidth, disableOverlap = false, defaultPadding = false, children, ...rest }) {
    const hasHeaderArea = Boolean(header || breadcrumbs || notifications);
    const highContrast = headerVariant === 'high-contrast' && hasHeaderArea;
    const style = maxContentWidth !== undefined
        ? { '--content-layout-max-width': `${maxContentWidth}px` }
        : undefined;
    return (_jsxs("div", { ...rest, className: clsx(styles.root, headerVariant !== 'default' && styles[`header-variant-${headerVariant}`], highContrast && !disableOverlap && styles.overlap, (defaultPadding || highContrast) && styles.padded, 
        // The band already keeps its content clear of the top edge.
        defaultPadding && !highContrast && styles['padded-top']), style: style, children: [highContrast && _jsx("div", { className: styles.band }), hasHeaderArea && (_jsxs("div", { className: styles['header-area'], children: [notifications && _jsx("div", { className: styles.notifications, children: notifications }), breadcrumbs && _jsx("div", { className: styles.breadcrumbs, children: breadcrumbs }), header && _jsx("div", { className: styles.header, children: header })] })), _jsx("div", { className: styles.content, children: children })] }));
}
