// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalContentLayout } from './internal';
export default function ContentLayout({ header, breadcrumbs, notifications, headerVariant = 'default', maxContentWidth, disableOverlap = false, defaultPadding = false, children, ...props }) {
    return (_jsx(InternalContentLayout, { ...getBaseProps(props), header: header, breadcrumbs: breadcrumbs, notifications: notifications, headerVariant: headerVariant, maxContentWidth: maxContentWidth, disableOverlap: disableOverlap, defaultPadding: defaultPadding, children: children }));
}
