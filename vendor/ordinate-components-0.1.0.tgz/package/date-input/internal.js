import { jsx as _jsx } from "react/jsx-runtime";
// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React, { useMemo } from 'react';
import clsx from 'clsx';
import { MaskedInput } from '../internal/components/masked-input';
import { createDateMask, dateDisplayToValue, dateValueToDisplay } from '../internal/components/masked-input/masks';
import { fireNonCancelableEvent } from '../internal/events';
import { splitBaseProps } from '../internal/split-base-props';
import styles from './styles.css.js';
export const InternalDateInput = React.forwardRef(({ value, onChange, granularity = 'day', className, ...props }, ref) => {
    const [baseProps, inputProps] = splitBaseProps(props);
    const mask = useMemo(() => createDateMask(granularity), [granularity]);
    return (_jsx("div", { ...baseProps, className: clsx(styles.root, className), children: _jsx(MaskedInput, { ...inputProps, ref: ref, mask: mask, value: dateValueToDisplay(value), onChange: event => fireNonCancelableEvent(onChange, { value: dateDisplayToValue(event.detail.value) }) }) }));
});
