// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import React from 'react';
import { getBaseProps } from '../internal/base-component';
import { InternalDateInput } from './internal';
const DateInput = React.forwardRef(({ value, onChange, granularity = 'day', placeholder, disabled = false, readOnly = false, autoFocus = false, ariaLabel, ariaRequired, name, onFocus, onBlur, controlId, ariaLabelledby, ariaDescribedby, invalid, warning, ...props }, ref) => (_jsx(InternalDateInput, { ...getBaseProps(props), ref: ref, value: value, onChange: onChange, granularity: granularity, placeholder: placeholder, disabled: disabled, readOnly: readOnly, autoFocus: autoFocus, ariaLabel: ariaLabel, ariaRequired: ariaRequired, name: name, onFocus: onFocus, onBlur: onBlur, controlId: controlId, ariaLabelledby: ariaLabelledby, ariaDescribedby: ariaDescribedby, invalid: invalid, warning: warning })));
DateInput.displayName = 'DateInput';
export default DateInput;
