// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalTableHead } from './internal';
export default function TableHead({ children, ...props }) {
    return _jsx(InternalTableHead, { ...getBaseProps(props), children: children });
}
