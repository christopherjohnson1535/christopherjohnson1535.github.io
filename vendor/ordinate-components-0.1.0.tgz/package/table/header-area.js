import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import clsx from 'clsx';
import styles from './styles.css.js';
/**
 * The reference and header slot and, below them, the tools row: the filter takes the free space, and
 * pagination and preferences sit at the end of the row.
 */
export function HeaderArea({ header, reference, filter, pagination, preferences, className }) {
    const hasTools = Boolean(filter || pagination || preferences);
    if (!header && !reference && !hasTools) {
        return null;
    }
    return (_jsxs("div", { className: clsx(styles['header-area'], className), children: [(reference || header) && (_jsxs("div", { className: styles.heading, children: [reference && _jsx("span", { className: clsx(styles.ink, styles.reference), children: reference }), header && _jsx("div", { className: styles['header-slot'], children: header })] })), hasTools && (_jsxs("div", { className: styles.tools, children: [filter && _jsx("div", { className: styles['tools-filter'], children: filter }), (pagination || preferences) && (_jsxs("div", { className: styles['tools-end'], children: [pagination && _jsx("div", { className: styles['tools-pagination'], children: pagination }), preferences && _jsx("div", { className: styles['tools-preferences'], children: preferences })] }))] }))] }));
}
