import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React, { useEffect, useId, useImperativeHandle, useRef, useState } from 'react';
import clsx from 'clsx';
import { InternalButton } from '../button/internal';
import { Dropdown } from '../internal/components/dropdown';
import { fireCancelableEvent } from '../internal/events';
import { useInternalI18n } from '../internal/i18n/context';
import { warnOnce } from '../internal/logging';
import { Menu } from './menu';
import { getItemClickDetails, isPlainLeftClick } from './utils';
import styles from './styles.css.js';
export const InternalButtonDropdown = React.forwardRef(({ items, expandableGroups = false, onItemClick, onItemFollow, children, variant = 'normal', mainAction, expandToViewport = false, disabled = false, loading = false, loadingText, ariaLabel, className, triggerClassName, triggerIconName, menuHeader, triggerTabIndex, wrapTrigger, ...rest }, ref) => {
    const i18n = useInternalI18n('button-dropdown');
    const baseId = useId();
    const triggerId = `${baseId}trigger`;
    const menuId = `${baseId}menu`;
    const triggerRef = useRef(null);
    const menuRef = useRef(null);
    const [open, setOpen] = useState(false);
    const pendingFocus = useRef(null);
    const suppressSpaceKeyUp = useRef(false);
    // The trigger's click event carries no click count, so a pointer press is tracked to tell mouse from keyboard.
    const pointerPressed = useRef(false);
    useImperativeHandle(ref, () => ({ focus: () => triggerRef.current?.focus() }));
    const isIconVariant = variant === 'icon' || variant === 'inline-icon';
    const isSplit = mainAction !== undefined && !isIconVariant;
    const inactive = disabled || loading;
    if (mainAction && isIconVariant) {
        warnOnce('ButtonDropdown', 'A main action is only supported with the normal and primary variants.');
    }
    useEffect(() => {
        const target = pendingFocus.current;
        if (!open || !target || !menuRef.current) {
            return;
        }
        pendingFocus.current = null;
        const elements = menuRef.current.querySelectorAll('[data-menu-item]');
        const element = target === 'menu' ? menuRef.current : elements[target === 'first' ? 0 : elements.length - 1];
        (element ?? menuRef.current).focus();
    }, [open]);
    const openMenu = (focusTarget) => {
        if (inactive || open) {
            return;
        }
        pendingFocus.current = focusTarget;
        setOpen(true);
    };
    const closeMenu = (returnFocus) => {
        setOpen(false);
        if (returnFocus) {
            triggerRef.current?.focus();
        }
    };
    const handleItemActivate = (item, event) => {
        const details = getItemClickDetails(item);
        fireCancelableEvent(onItemClick, details, event);
        if (item.href !== undefined && isPlainLeftClick(event)) {
            fireCancelableEvent(onItemFollow, details, event);
        }
        closeMenu(true);
    };
    const handleTriggerKeyDown = (event) => {
        pointerPressed.current = false;
        if (open || inactive) {
            return;
        }
        if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
            event.preventDefault();
            openMenu(event.key === 'ArrowDown' ? 'first' : 'last');
        }
    };
    const handleTriggerClick = () => {
        const fromPointer = pointerPressed.current;
        pointerPressed.current = false;
        if (open) {
            closeMenu(true);
            return;
        }
        // Keyboard users land on the first item; mouse users get the menu without a highlighted item.
        openMenu(fromPointer ? 'menu' : 'first');
    };
    const triggerVariant = isIconVariant ? 'icon' : variant;
    const triggerLabel = isIconVariant || isSplit ? i18n('ariaLabel', ariaLabel) : ariaLabel;
    const trigger = (_jsx(InternalButton, { ref: triggerRef, id: triggerId, className: clsx(styles.trigger, variant === 'inline-icon' && styles['inline-icon'], isSplit && styles.segment, isSplit && styles['split-trigger'], isSplit && variant === 'primary' && styles['split-trigger-primary'], triggerClassName), variant: triggerVariant, formAction: "none", iconName: isIconVariant ? (triggerIconName ?? 'more') : 'chevron-down', iconAlign: "right", disabled: disabled, loading: loading, loadingText: loadingText, ariaLabel: triggerLabel, ariaExpanded: open, ariaHaspopup: "menu", ariaControls: open ? menuId : undefined, tabIndex: triggerTabIndex, onClick: handleTriggerClick, children: isIconVariant || isSplit ? undefined : children }));
    const mainActionButton = isSplit && mainAction && (_jsx(InternalButton, { className: clsx(styles['main-action'], styles.segment), variant: variant === 'primary' ? 'primary' : 'normal', formAction: "none", iconName: mainAction.iconName, href: mainAction.href, external: mainAction.external, externalIconAriaLabel: mainAction.externalIconAriaLabel, disabled: mainAction.disabled, loading: mainAction.loading, loadingText: mainAction.loadingText, ariaLabel: mainAction.ariaLabel, onClick: mainAction.onClick, children: mainAction.text }));
    return (_jsxs("div", { ...rest, className: clsx(styles.root, isSplit && styles.split, isSplit && variant === 'primary' && styles['split-primary'], isSplit && disabled && (mainAction?.disabled ?? false) && styles['split-disabled'], className), onBlur: event => {
            if (open && !event.currentTarget.contains(event.relatedTarget)) {
                closeMenu(false);
            }
        }, onKeyUp: event => {
            // Space chose an item and moved focus to the trigger; its keyup must not reopen the menu.
            if (event.key === ' ' && suppressSpaceKeyUp.current) {
                suppressSpaceKeyUp.current = false;
                event.preventDefault();
            }
        }, children: [mainActionButton, _jsx(Dropdown, { open: open, className: styles.dropdown, expandToViewport: expandToViewport, header: menuHeader, trigger: _jsx("span", { className: styles['trigger-area'], onKeyDown: handleTriggerKeyDown, onMouseDown: () => (pointerPressed.current = true), children: wrapTrigger ? wrapTrigger(trigger) : trigger }), onOutsideClick: () => closeMenu(false), children: _jsx(Menu, { ref: menuRef, id: menuId, ariaLabelledby: triggerId, items: items, expandableGroups: expandableGroups, onItemActivate: handleItemActivate, onDismiss: () => closeMenu(true), onSpaceActivate: () => (suppressSpaceKeyUp.current = true) }) })] }));
});
