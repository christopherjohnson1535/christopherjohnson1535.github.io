// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import React from 'react';
import { getBaseProps } from '../internal/base-component';
import { InternalButtonDropdown } from './internal';
const ButtonDropdown = React.forwardRef(({ items, expandableGroups = false, onItemClick, onItemFollow, children, variant = 'normal', mainAction, expandToViewport = false, disabled = false, loading = false, loadingText, ariaLabel, ...props }, ref) => (_jsx(InternalButtonDropdown, { ...getBaseProps(props), ref: ref, items: items, expandableGroups: expandableGroups, onItemClick: onItemClick, onItemFollow: onItemFollow, variant: variant, mainAction: mainAction, expandToViewport: expandToViewport, disabled: disabled, loading: loading, loadingText: loadingText, ariaLabel: ariaLabel, children: children })));
ButtonDropdown.displayName = 'ButtonDropdown';
export default ButtonDropdown;
