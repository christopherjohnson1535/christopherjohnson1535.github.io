// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalPagination } from './internal';
export default function Pagination({ currentPageIndex, pagesCount, openEnd = false, disabled = false, showPageLabel = false, ariaLabels, onChange, onNextPageClick, onPreviousPageClick, ...props }) {
    return (_jsx(InternalPagination, { ...getBaseProps(props), currentPageIndex: currentPageIndex, pagesCount: pagesCount, openEnd: openEnd, disabled: disabled, showPageLabel: showPageLabel, ariaLabels: ariaLabels, onChange: onChange, onNextPageClick: onNextPageClick, onPreviousPageClick: onPreviousPageClick }));
}
