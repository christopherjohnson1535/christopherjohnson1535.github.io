import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import clsx from 'clsx';
import { InternalIcon } from '../icon/internal';
import { fireNonCancelableEvent } from '../internal/events';
import { useInternalI18n } from '../internal/i18n/context';
import { getPageItems } from './utils';
import styles from './styles.css.js';
function clamp(value, min, max) {
    return Math.min(Math.max(value, min), max);
}
export function InternalPagination({ currentPageIndex, pagesCount, openEnd = false, disabled = false, ariaLabels, onChange, onNextPageClick, onPreviousPageClick, ...rest }) {
    const i18n = useInternalI18n('pagination');
    // An empty list still shows page 1, so the control keeps its shape while data loads.
    const count = Math.max(Math.floor(pagesCount), 1);
    const current = clamp(Math.floor(currentPageIndex), 1, count);
    const pageLabel = (pageNumber) => i18n('pageLabel', ariaLabels?.pageLabel?.(pageNumber), {
        pageNumber,
        pagesCount: count,
        openEnd: openEnd ? 'true' : 'false',
    });
    const goTo = (pageIndex) => {
        if (pageIndex !== current) {
            fireNonCancelableEvent(onChange, { currentPageIndex: pageIndex });
        }
    };
    const previous = () => {
        const requestedPageIndex = current - 1;
        fireNonCancelableEvent(onPreviousPageClick, { requestedPageAvailable: true, requestedPageIndex });
        goTo(requestedPageIndex);
    };
    const next = () => {
        const requestedPageIndex = current + 1;
        const requestedPageAvailable = requestedPageIndex <= count;
        fireNonCancelableEvent(onNextPageClick, { requestedPageAvailable, requestedPageIndex });
        if (requestedPageAvailable) {
            goTo(requestedPageIndex);
        }
    };
    return (_jsxs("ul", { ...rest, className: clsx(styles.root, disabled && styles['root-disabled']), "aria-label": i18n('paginationLabel', ariaLabels?.paginationLabel), children: [_jsx("li", { className: styles.item, children: _jsx("button", { type: "button", className: clsx(styles.button, styles.arrow, styles['previous-page']), "aria-label": i18n('previousPageLabel', ariaLabels?.previousPageLabel), disabled: disabled || current <= 1, onClick: previous, children: _jsx(InternalIcon, { name: "angle-left" }) }) }), getPageItems(current, count, openEnd).map(item => typeof item === 'number' ? (_jsx("li", { className: styles.item, children: _jsx("button", { type: "button", className: clsx(styles.button, styles['page-number'], item === current && styles['current-page']), "aria-label": pageLabel(item), "aria-current": item === current ? 'true' : undefined, disabled: disabled, onClick: () => goTo(item), children: item }) }, item)) : (_jsx("li", { className: clsx(styles.item, styles.ellipsis), "aria-hidden": "true", children: _jsx(InternalIcon, { name: "ellipsis" }) }, item))), _jsx("li", { className: styles.item, children: _jsx("button", { type: "button", className: clsx(styles.button, styles.arrow, styles['next-page']), "aria-label": i18n('nextPageLabel', ariaLabels?.nextPageLabel), disabled: disabled || (!openEnd && current >= count), onClick: next, children: _jsx(InternalIcon, { name: "angle-right" }) }) })] }));
}
