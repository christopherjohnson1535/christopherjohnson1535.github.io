// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalStoryCard } from './internal';
/**
 * A teaser for an article or post: a title that links to it, with an optional picture, number,
 * kicker, summary and byline. It has no box, so it sits in columns and lists like print.
 */
export default function StoryCard({ title, href, onFollow, summary, kicker, number, meta, media, headingLevel = 3, variant = 'default', ...props }) {
    return (_jsx(InternalStoryCard, { ...getBaseProps(props), title: title, href: href, onFollow: onFollow, summary: summary, kicker: kicker, number: number, meta: meta, media: media, headingLevel: headingLevel, variant: variant }));
}
