import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React, { useId, useImperativeHandle, useRef } from 'react';
import clsx from 'clsx';
import { InternalFileDropzone } from '../file-dropzone/internal';
import { InternalFileInput } from '../file-input/internal';
import { InternalFileTokenGroup } from '../file-token-group/internal';
import { InternalIcon } from '../icon/internal';
import { useFormFieldContext } from '../internal/context/form-field-context';
import { fireNonCancelableEvent } from '../internal/events';
import { useFilesDragging } from '../internal/hooks/use-files-dragging';
import { useInternalI18n } from '../internal/i18n/context';
import { warnOnce } from '../internal/logging';
import styles from './styles.css.js';
function joinIds(...ids) {
    return ids.filter(Boolean).join(' ') || undefined;
}
export const InternalFileUpload = React.forwardRef(({ value, onChange, multiple = false, accept, showFileSize = false, showFileLastModified = false, showFileThumbnail = false, tokenLimit, fileErrors, fileWarnings, constraintText, errorText, warningText, ariaLabel, ariaRequired, i18nStrings, controlId, ariaLabelledby, ariaDescribedby, invalid, warning, ...rest }, ref) => {
    const i18n = useInternalI18n('file-upload');
    const field = useFormFieldContext({ controlId, ariaLabelledby, ariaDescribedby, invalid, warning });
    const inputRef = useRef(null);
    const baseId = useId();
    const errorId = `${baseId}error`;
    const warningId = `${baseId}warning`;
    const constraintId = `${baseId}constraint`;
    const dragging = useFilesDragging();
    useImperativeHandle(ref, () => ({ focus: () => inputRef.current?.focus() }));
    if (errorText && warningText) {
        warnOnce('FileUpload', '`warningText` is not shown while `errorText` is set.');
    }
    const showWarning = Boolean(warningText) && !errorText;
    const change = (files) => fireNonCancelableEvent(onChange, { value: files });
    const add = (files) => change(multiple ? [...value, ...files] : files.slice(0, 1));
    const items = value.map((file, index) => ({
        file,
        errorText: fileErrors?.[index] || undefined,
        warningText: fileWarnings?.[index] || undefined,
    }));
    return (_jsxs("div", { ...rest, className: styles.root, children: [dragging ? (_jsxs(InternalFileDropzone, { className: styles.dropzone, onChange: event => add(event.detail.value), children: [_jsx(InternalIcon, { name: "upload", size: "medium" }), _jsx("span", { children: i18n('dropzoneText', i18nStrings?.dropzoneText, { multiple: String(multiple) }) })] })) : (_jsx(InternalFileInput, { ref: inputRef, value: value, onChange: event => change(event.detail.value), multiple: multiple, accept: accept, ariaLabel: ariaLabel, ariaRequired: ariaRequired, controlId: field.controlId, ariaLabelledby: field.ariaLabelledby, ariaDescribedby: joinIds(field.ariaDescribedby, Boolean(errorText) && errorId, showWarning && warningId, Boolean(constraintText) && constraintId), invalid: field.invalid || Boolean(errorText), warning: field.warning || showWarning, children: i18nStrings?.uploadButtonText })), (errorText || showWarning || constraintText) && (_jsxs("div", { className: styles.hints, children: [errorText && (_jsxs("div", { id: errorId, className: clsx(styles.message, styles.error), children: [_jsx(InternalIcon, { className: styles['message-icon'], name: "status-negative", size: "small", ariaLabel: i18n('errorIconAriaLabel', i18nStrings?.errorIconAriaLabel) }), _jsx("span", { children: errorText })] })), showWarning && (_jsxs("div", { id: warningId, className: clsx(styles.message, styles.warning), children: [_jsx(InternalIcon, { className: styles['message-icon'], name: "status-warning", size: "small", ariaLabel: i18n('warningIconAriaLabel', i18nStrings?.warningIconAriaLabel) }), _jsx("span", { children: warningText })] })), constraintText && (_jsx("div", { id: constraintId, className: styles.constraint, children: constraintText }))] })), _jsx(InternalFileTokenGroup, { className: styles.tokens, items: items, alignment: "vertical", limit: tokenLimit, showFileSize: showFileSize, showFileLastModified: showFileLastModified, showFileThumbnail: showFileThumbnail, i18nStrings: {
                    removeFileAriaLabel: i18nStrings?.removeFileAriaLabel,
                    limitShowMore: i18nStrings?.limitShowMore,
                    limitShowFewer: i18nStrings?.limitShowFewer,
                    errorIconAriaLabel: i18nStrings?.errorIconAriaLabel,
                    warningIconAriaLabel: i18nStrings?.warningIconAriaLabel,
                    formatFileSize: i18nStrings?.formatFileSize,
                    formatFileLastModified: i18nStrings?.formatFileLastModified,
                }, onDismiss: event => change(value.filter((_, index) => index !== event.detail.fileIndex)), onEmptied: () => inputRef.current?.focus() })] }));
});
