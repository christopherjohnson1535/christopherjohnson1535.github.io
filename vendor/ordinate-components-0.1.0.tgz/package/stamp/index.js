// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalStamp } from './internal';
export default function Stamp({ type = 'neutral', rotation = 'slight', size = 'medium', children, ...props }) {
    return (_jsx(InternalStamp, { ...getBaseProps(props), type: type, rotation: rotation, size: size, children: children }));
}
