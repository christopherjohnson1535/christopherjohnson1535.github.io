// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { warnOnce } from '../internal/logging';
import { InternalStamp } from './internal';
const legacyTypes = {
    info: 'note',
    success: 'complete',
    warning: 'caution',
    error: 'fault',
};
function resolveType(type) {
    if (Object.prototype.hasOwnProperty.call(legacyTypes, type)) {
        const current = legacyTypes[type];
        warnOnce('Stamp', `The type "${type}" is now called "${current}". The old name stops working in the next major version.`);
        return current;
    }
    return type;
}
export default function Stamp({ type = 'neutral', rotation = 'slight', size = 'medium', children, ...props }) {
    return (_jsx(InternalStamp, { ...getBaseProps(props), type: resolveType(type), rotation: rotation, size: size, children: children }));
}
