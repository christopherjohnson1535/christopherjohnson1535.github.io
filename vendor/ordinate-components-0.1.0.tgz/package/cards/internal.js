import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { useId, useRef, useState } from 'react';
import clsx from 'clsx';
import { InternalCheckbox } from '../checkbox/internal';
import { DimensionLine } from '../internal/components/dimension-line';
import { SheetFrame } from '../internal/components/sheet-frame';
import { FormFieldContext } from '../internal/context/form-field-context';
import { fireNonCancelableEvent } from '../internal/events';
import { useResizeObserver } from '../internal/hooks/use-resize-observer';
import { useInternalI18n } from '../internal/i18n/context';
import { InternalItemCard } from '../item-card/internal';
import { InternalRadioButton } from '../radio-button/internal';
import { InternalStatusIndicator } from '../status-indicator/internal';
import { liftHeaderCounter } from '../table/header-counter';
import { defaultCardsPerRow, getCardsPerRow, getSectionWidth, getTrackKey, getVisibleSections } from './utils';
import styles from './styles.css.js';
export function InternalCards({ items, cardDefinition, cardsPerRow = defaultCardsPerRow, trackBy, selectionType, selectedItems = [], onSelectionChange, isItemDisabled, loading = false, loadingText, empty, header, filter, pagination, preferences, visibleSections, ariaLabels, variant = 'container', entireCardClickable = false, kind = 'neutral', ...rest }) {
    const i18n = useInternalI18n('cards');
    const baseId = useId();
    const headerId = `${baseId}header`;
    const groupName = `ord-cards-${baseId}`;
    const rootRef = useRef(null);
    const [width, setWidth] = useState(0);
    useResizeObserver(rootRef, () => setWidth(rootRef.current?.getBoundingClientRect().width ?? 0));
    const columns = getCardsPerRow(cardsPerRow, width);
    const controlRefs = useRef([]);
    const selectedKeys = new Set(selectedItems.map(item => getTrackKey(trackBy, item)));
    const isSelected = (item) => selectedKeys.has(getTrackKey(trackBy, item));
    const isDisabled = (item) => Boolean(isItemDisabled?.(item));
    const select = (item) => {
        if (isDisabled(item)) {
            return;
        }
        if (selectionType === 'single') {
            if (!isSelected(item)) {
                fireNonCancelableEvent(onSelectionChange, { selectedItems: [item] });
            }
            return;
        }
        const key = getTrackKey(trackBy, item);
        const next = isSelected(item)
            ? selectedItems.filter(selected => getTrackKey(trackBy, selected) !== key)
            : [...selectedItems, item];
        fireNonCancelableEvent(onSelectionChange, { selectedItems: next });
    };
    // Clicks on the control or on links and buttons inside the card do their own thing.
    const handleCardClick = (event, item, index) => {
        if (event.target.closest('input, label, a, button') || isDisabled(item)) {
            return;
        }
        controlRefs.current[index]?.focus();
        select(item);
    };
    const sections = getVisibleSections(cardDefinition.sections ?? [], visibleSections);
    const renderSelectionControl = (item, index, cardHeaderId) => {
        const label = ariaLabels?.itemSelectionLabel?.({ selectedItems }, item);
        const common = {
            ref: (control) => {
                controlRefs.current[index] = control;
            },
            disabled: isDisabled(item),
            ariaLabel: label,
            ariaLabelledby: label ? undefined : cardHeaderId,
        };
        return selectionType === 'single' ? (_jsx(InternalRadioButton, { ...common, name: groupName, checked: isSelected(item), onSelect: () => select(item) })) : (_jsx(InternalCheckbox, { ...common, checked: isSelected(item), onChange: () => select(item) }));
    };
    const renderCard = (item, index) => {
        const cardHeaderId = `${baseId}card${index}`;
        const selected = Boolean(selectionType) && isSelected(item);
        const disabled = isDisabled(item);
        const cardHeader = cardDefinition.header?.(item);
        return (_jsx(InternalItemCard, { className: clsx(styles.card, Boolean(selectionType) && disabled && styles['card-disabled']), header: cardHeader !== undefined && _jsx("span", { id: cardHeaderId, children: cardHeader }), reference: cardDefinition.reference?.(item), kind: kind, selected: selected, disabled: Boolean(selectionType) && disabled, selectionControl: selectionType && renderSelectionControl(item, index, cardHeaderId), onClick: selectionType && entireCardClickable ? event => handleCardClick(event, item, index) : undefined, children: sections.length > 0 && (_jsx("div", { className: styles.sections, children: sections.map((section, sectionIndex) => (_jsxs("div", { className: styles.section, style: { flexBasis: `${getSectionWidth(section.width)}%` }, children: [section.header && _jsx("div", { className: styles['section-header'], children: section.header }), section.content && _jsx("div", { className: styles['section-content'], children: section.content(item) })] }, section.id ?? sectionIndex))) })) }));
    };
    const listLabel = ariaLabels?.cardsLabel ?? (selectionType ? ariaLabels?.selectionGroupLabel : undefined);
    let body;
    if (loading) {
        body = (_jsx("div", { className: styles.loading, children: _jsx(InternalStatusIndicator, { state: "loading", children: i18n('loadingText', loadingText) }) }));
    }
    else if (items.length === 0) {
        body = _jsx("div", { className: styles.empty, children: empty });
    }
    else {
        body = (_jsx("ul", { className: styles.list, style: { gridTemplateColumns: `repeat(${columns}, minmax(0, 1fr))` }, "aria-label": listLabel, "aria-labelledby": !listLabel && header ? headerId : undefined, children: _jsx(FormFieldContext.Provider, { value: {}, children: items.map((item, index) => (_jsx("li", { className: styles.item, children: renderCard(item, index) }, String(trackBy ? getTrackKey(trackBy, item) : index)))) }) }));
    }
    // On a sheet the count stands in a dimension line under the heading, as in Container.
    // The heading still holds it for screen readers. The full-page variant has no sheet, so its header shows it.
    const onSheet = variant === 'container';
    const lifted = onSheet ? liftHeaderCounter(header, styles['screenreader-only']) : { header, measure: undefined };
    const hasTools = Boolean(filter || pagination || preferences);
    const heading = header || hasTools ? (_jsxs("div", { className: styles.heading, children: [header && (_jsx("div", { id: headerId, className: styles.header, children: lifted.header })), lifted.measure !== undefined && (_jsx("div", { className: styles.measure, "aria-hidden": "true", children: _jsx(DimensionLine, { label: lifted.measure }) })), hasTools && (_jsxs("div", { className: styles.tools, children: [filter && _jsx("div", { className: styles.filter, children: filter }), (pagination || preferences) && (_jsxs("div", { className: styles['tools-end'], children: [pagination && _jsx("div", { className: styles.pagination, children: pagination }), preferences && _jsx("div", { className: styles.preferences, children: preferences })] }))] }))] })) : undefined;
    return (_jsx("div", { ...rest, ref: rootRef, className: clsx(styles.root, styles[`variant-${variant}`]), children: variant === 'container' ? (_jsx(SheetFrame, { header: heading, children: body })) : (_jsxs(_Fragment, { children: [heading, body] })) }));
}
