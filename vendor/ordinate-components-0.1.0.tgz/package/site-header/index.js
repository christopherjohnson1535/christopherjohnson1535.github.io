// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalSiteHeader } from './internal';
export default function SiteHeader({ brand, links, actions, notice, sticky = false, navigationAriaLabel, menuButtonText, onFollow, ...props }) {
    return (_jsx(InternalSiteHeader, { ...getBaseProps(props), brand: brand, links: links, actions: actions, notice: notice, sticky: sticky, navigationAriaLabel: navigationAriaLabel, menuButtonText: menuButtonText, onFollow: onFollow }));
}
