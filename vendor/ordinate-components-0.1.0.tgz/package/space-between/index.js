// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalSpaceBetween } from './internal';
export default function SpaceBetween({ direction = 'vertical', size, alignItems, children, ...props }) {
    return (_jsx(InternalSpaceBetween, { ...getBaseProps(props), direction: direction, size: size, alignItems: alignItems, children: children }));
}
