import { jsx as _jsx } from "react/jsx-runtime";
import clsx from 'clsx';
import { warnOnce } from '../internal/logging';
import styles from './styles.css.js';
export function InternalMedia({ src, alt, aspectRatio = '3:2', fit = 'cover', children, placeholderText, className, ...rest }) {
    if (src && alt === undefined) {
        warnOnce('Media', 'Set `alt` whenever `src` is set. Use an empty string only for decoration.');
    }
    const hasChildren = children !== undefined && children !== null && children !== false;
    const content = hasChildren ? (_jsx("div", { className: styles.slot, children: children })) : src ? (_jsx("img", { className: styles.image, src: src, alt: alt ?? '' })) : null;
    return (_jsx("div", { ...rest, className: clsx(styles.root, styles[`ratio-${aspectRatio.replace(':', '-')}`], styles[`fit-${fit}`], !content && styles.placeholder, className), children: content ??
            (placeholderText && (_jsx("span", { className: styles['placeholder-text'], "aria-hidden": "true", children: placeholderText }))) }));
}
