// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalMedia } from './internal';
/**
 * An image, video or drawing in a frame of a fixed shape. With nothing in it, it draws a hatched
 * placeholder, so a draft page shows where the pictures will go.
 */
export default function Media({ src, alt, aspectRatio = '3:2', fit = 'cover', children, placeholderText, ...props }) {
    return (_jsx(InternalMedia, { ...getBaseProps(props), src: src, alt: alt, aspectRatio: aspectRatio, fit: fit, placeholderText: placeholderText, children: children }));
}
