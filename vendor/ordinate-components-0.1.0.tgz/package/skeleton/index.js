// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalSkeleton } from './internal';
export default function Skeleton({ variant = 'text', lines = 1, width = 'full', height = 'medium', loading = true, loadingText, children, ...props }) {
    return (_jsx(InternalSkeleton, { ...getBaseProps(props), variant: variant, lines: lines, width: width, height: height, loading: loading, loadingText: loadingText, children: children }));
}
