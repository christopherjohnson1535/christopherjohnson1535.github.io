import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import clsx from 'clsx';
import { InternalIcon } from '../icon/internal';
import { ConstructionTopLine, RuleEndMarks } from '../internal/components/construction';
import styles from './styles.css.js';
// The component does not render a <form> element, so consumers can nest it in their own
// <form> and control submission themselves.
//
// It is drawn like a section: a construction line in the kind's color opens it, the reference sits above the
// header, and the actions stand on a rule closed by hash marks.
export function InternalForm({ kind = 'neutral', reference, children, header, errorText, errorIconAriaLabel, actions, secondaryActions, variant = 'full-page', ...rest }) {
    const hasReference = reference !== undefined && reference !== '';
    return (_jsxs("div", { ...rest, className: clsx(styles.root, styles[`kind-${kind}`]), "data-variant": variant, children: [_jsx(ConstructionTopLine, { kind: kind }), (header || hasReference) && (_jsxs("div", { className: styles['header-block'], children: [hasReference && _jsx("span", { className: styles.reference, children: reference }), header && _jsx("div", { className: styles.header, children: header })] })), children && _jsx("div", { className: styles.content, children: children }), _jsx("div", { role: "alert", className: styles['error-region'], children: errorText && (_jsxs("div", { className: styles.error, children: [_jsx(InternalIcon, { className: styles['error-icon'], name: "fault", variant: "error", ariaLabel: errorIconAriaLabel }), _jsx("div", { className: styles['error-text'], children: errorText })] })) }), (actions || secondaryActions) && (_jsxs("div", { className: styles.footer, children: [_jsx(RuleEndMarks, { kind: kind }), secondaryActions && _jsx("div", { className: styles['secondary-actions'], children: secondaryActions }), actions && _jsx("div", { className: styles.actions, children: actions })] }))] }));
}
