import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { InternalIcon } from '../icon/internal';
import styles from './styles.css.js';
// The component does not render a <form> element, so consumers can nest it in their own
// <form> and control submission themselves.
export function InternalForm({ children, header, errorText, errorIconAriaLabel, actions, secondaryActions, variant = 'full-page', ...rest }) {
    return (_jsxs("div", { ...rest, className: styles.root, "data-variant": variant, children: [header && _jsx("div", { className: styles.header, children: header }), children && _jsx("div", { className: styles.content, children: children }), _jsx("div", { role: "alert", className: styles['error-region'], children: errorText && (_jsxs("div", { className: styles.error, children: [_jsx(InternalIcon, { className: styles['error-icon'], name: "status-negative", variant: "error", ariaLabel: errorIconAriaLabel }), _jsx("div", { className: styles['error-text'], children: errorText })] })) }), (actions || secondaryActions) && (_jsxs("div", { className: styles.footer, children: [secondaryActions && _jsx("div", { className: styles['secondary-actions'], children: secondaryActions }), actions && _jsx("div", { className: styles.actions, children: actions })] }))] }));
}
