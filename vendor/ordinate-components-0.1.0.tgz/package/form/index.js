// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalForm } from './internal';
export default function Form({ children, header, errorText, errorIconAriaLabel, actions, secondaryActions, variant = 'full-page', ...props }) {
    return (_jsx(InternalForm, { ...getBaseProps(props), header: header, errorText: errorText, errorIconAriaLabel: errorIconAriaLabel, actions: actions, secondaryActions: secondaryActions, variant: variant, children: children }));
}
