// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalHowItWorks } from './internal';
export default function HowItWorks({ steps, headingLevel = 3, orientation = 'horizontal', ariaLabel, ...props }) {
    return (_jsx(InternalHowItWorks, { ...getBaseProps(props), steps: steps, headingLevel: headingLevel, orientation: orientation, ariaLabel: ariaLabel }));
}
