import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import clsx from 'clsx';
import { getHeadingTag } from '../internal/heading-level';
import styles from './styles.css.js';
export function InternalHowItWorks({ steps, headingLevel, orientation = 'horizontal', ariaLabel, ...rest }) {
    const HeadingTag = getHeadingTag('HowItWorks', headingLevel, 3);
    return (_jsx("ol", { ...rest, role: "list", className: clsx(styles.root, styles[`orientation-${orientation}`]), "aria-label": ariaLabel, children: steps.map((step, index) => (_jsxs("li", { className: styles.step, children: [_jsx("span", { className: styles.number, "aria-hidden": "true", children: index + 1 }), _jsxs("div", { className: styles.body, children: [_jsx(HeadingTag, { className: styles.title, children: step.title }), step.description && _jsx("div", { className: styles.description, children: step.description }), step.media && _jsx("div", { className: styles.media, children: step.media })] })] }, index))) }));
}
