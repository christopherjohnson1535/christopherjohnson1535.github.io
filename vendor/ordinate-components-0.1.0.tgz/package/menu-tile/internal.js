import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import clsx from 'clsx';
import { Heading } from '../internal/components/heading';
import { LeaderRow } from '../internal/components/leader-row';
import styles from './styles.css.js';
export function InternalMenuTile({ title, items = [], description, badge, tone = 'default', footer, headingLevel = 3, ...rest }) {
    return (_jsxs("div", { ...rest, className: clsx(styles.root, styles[`tone-${tone}`]), children: [_jsxs("div", { className: styles.header, children: [_jsx(Heading, { level: headingLevel, defaultLevel: 3, className: styles.title, children: title }), badge && _jsx("span", { className: styles.badge, children: badge })] }), description && _jsx("div", { className: styles.description, children: description }), items.length > 0 && (_jsx("ul", { className: styles.items, children: items.map((item, index) => (_jsxs("li", { className: styles.item, children: [_jsx(LeaderRow, { label: item.label, value: item.value, valueClassName: styles['item-value'] }), item.description && _jsx("span", { className: styles['item-description'], children: item.description })] }, index))) })), footer && _jsx("div", { className: styles.footer, children: footer })] }));
}
