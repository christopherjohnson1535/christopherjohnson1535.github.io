// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalIcon } from './internal';
export default function Icon({ name, svg, size = 'normal', variant = 'normal', ariaLabel, ...props }) {
    return (_jsx(InternalIcon, { ...getBaseProps(props), name: name, svg: svg, size: size, variant: variant, ariaLabel: ariaLabel }));
}
