// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalRouteMap } from './internal';
/**
 * A route of lines, each a row of stops, that bend at right angles onto one shared run into a
 * terminus, drawn like a transit map. Use it to show the parts of a course or a program and how far
 * someone has come. Each line can be a link.
 */
export default function RouteMap({ lines, terminus, selectedLineId, currentStopId, currentStopLabel, ariaLabel, onFollow, ...props }) {
    return (_jsx(InternalRouteMap, { ...getBaseProps(props), lines: lines, terminus: terminus, selectedLineId: selectedLineId, currentStopId: currentStopId, currentStopLabel: currentStopLabel, ariaLabel: ariaLabel, onFollow: onFollow }));
}
