import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React, { useEffect, useId, useImperativeHandle, useRef, useState } from 'react';
import clsx from 'clsx';
import { InternalButton } from '../button/internal';
import { getBreakpoint } from '../internal/breakpoints';
import { fireNonCancelableEvent } from '../internal/events';
import { getFirstTabbable } from '../internal/focus';
import { useContainerWidth } from '../internal/hooks/use-container-width';
import { useInternalI18n } from '../internal/i18n/context';
import { InternalLiveRegion } from '../live-region/internal';
import { AttributeField } from './field';
import { isColumnLayout, resolveLayout, toGridTemplate } from './layout';
import styles from './styles.css.js';
const gridStyle = (template) => ({ '--attribute-editor-columns': template });
function InternalAttributeEditorWithRef({ items = [], definition, onAddButtonClick, onRemoveButtonClick, addButtonText, removeButtonText, removeButtonAriaLabel, isItemRemovable = () => true, empty, additionalInfo, disableAddButton = false, gridLayout, i18nStrings, getRemoveButtonText, ...rest }, ref) {
    const i18n = useInternalI18n('attribute-editor');
    const baseId = useId();
    const headingId = (fieldIndex) => `${baseId}heading-${fieldIndex}`;
    const rootRef = useRef(null);
    const width = useContainerWidth(rootRef);
    // Until the editor is measured, as on the server, the stacked layout is the one that always fits.
    const layout = resolveLayout(gridLayout, definition.length, width === null ? 'default' : getBreakpoint(width));
    const columns = isColumnLayout(layout);
    const hasHeadings = definition.some(field => field.label || field.info);
    const addButtonRef = useRef(null);
    const pendingFocusRef = useRef(null);
    const [announcement, setAnnouncement] = useState('');
    // Rows and their buttons are looked up when needed, so render never depends on refs to them.
    const findRow = (itemIndex) => rootRef.current?.querySelector(`.${styles.rows} > :nth-child(${itemIndex + 1})`) ?? null;
    const focusRemoveButton = (itemIndex) => {
        const button = findRow(itemIndex)?.querySelector(`.${styles['remove-button']}`);
        if (button) {
            button.focus();
        }
        else {
            addButtonRef.current?.focus();
        }
    };
    useImperativeHandle(ref, () => ({
        focusRemoveButton,
        focusAddButton: () => addButtonRef.current?.focus(),
    }));
    // Focus follows the change only once the new items arrive, which may be after an async update.
    useEffect(() => {
        const pending = pendingFocusRef.current;
        pendingFocusRef.current = null;
        if (pending?.type === 'add' && items.length > pending.itemCount) {
            const row = findRow(items.length - 1);
            (row && getFirstTabbable(row))?.focus();
        }
        else if (pending?.type === 'remove' && items.length < pending.itemCount) {
            focusRemoveButton(pending.itemIndex);
            setAnnouncement(i18n('itemRemovedAriaLive', i18nStrings?.itemRemovedAriaLive, { itemNumber: pending.itemIndex + 1 }) ?? '');
        }
        // Only a change of items settles a pending focus move.
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [items]);
    const handleAdd = () => {
        pendingFocusRef.current = { type: 'add', itemCount: items.length };
        setAnnouncement('');
        fireNonCancelableEvent(onAddButtonClick, null);
    };
    const handleRemove = (itemIndex) => {
        pendingFocusRef.current = { type: 'remove', itemIndex, itemCount: items.length };
        setAnnouncement('');
        fireNonCancelableEvent(onRemoveButtonClick, { itemIndex });
    };
    const renderRemoveButton = (item, itemIndex) => isItemRemovable(item) ? (_jsx(InternalButton, { className: styles['remove-button'], formAction: "none", ariaLabel: removeButtonAriaLabel?.(item), onClick: () => handleRemove(itemIndex), children: getRemoveButtonText?.(item, itemIndex) ?? i18n('removeButtonText', removeButtonText) })) : null;
    const renderField = (item, itemIndex, fieldIndex) => (_jsx("div", { className: styles.field, children: _jsx(AttributeField, { definition: definition[fieldIndex], item: item, itemIndex: itemIndex, headingId: columns && hasHeadings ? headingId(fieldIndex) : undefined }) }, fieldIndex));
    const renderColumnRow = (item, itemIndex) => (_jsxs(_Fragment, { children: [definition.map((_, fieldIndex) => renderField(item, itemIndex, fieldIndex)), _jsx("div", { className: clsx(styles['remove-cell'], styles['remove-cell-aligned']), children: renderRemoveButton(item, itemIndex) })] }));
    const renderStackedRow = (item, itemIndex) => {
        let nextField = 0;
        const lastLine = layout.rows.length - 1;
        return (_jsxs(_Fragment, { children: [layout.rows.map((widths, lineIndex) => {
                    const fieldIndexes = widths.map(() => nextField++);
                    const withButton = lineIndex === lastLine && !layout.removeButtonOwnRow;
                    return (_jsxs("div", { className: styles.line, style: gridStyle(toGridTemplate(widths, withButton)), children: [fieldIndexes.map(fieldIndex => renderField(item, itemIndex, fieldIndex)), withButton && (_jsxs("div", { className: styles['remove-cell'], children: [hasHeadings && _jsx("span", { className: styles['label-spacer'], "aria-hidden": "true" }), _jsx("div", { className: styles['remove-cell-aligned'], children: renderRemoveButton(item, itemIndex) })] }))] }, lineIndex));
                }), layout.removeButtonOwnRow && _jsx("div", { className: styles['own-row'], children: renderRemoveButton(item, itemIndex) })] }));
    };
    return (_jsxs("div", { ...rest, ref: rootRef, className: styles.root, children: [items.length === 0 ? (empty && _jsx("div", { className: styles.empty, children: empty })) : (_jsxs("div", { className: clsx(styles.grid, columns ? styles.columns : styles.stacked), style: columns ? gridStyle(toGridTemplate(layout.rows[0], true)) : undefined, children: [columns && hasHeadings && (_jsx("div", { className: styles.headings, children: definition.map((field, fieldIndex) => (_jsxs("div", { className: styles.heading, children: [field.label && (_jsx("span", { id: headingId(fieldIndex), className: styles['heading-label'], children: field.label })), field.info && _jsx("span", { className: styles['heading-info'], children: field.info })] }, fieldIndex))) })), _jsx("ul", { className: styles.rows, children: items.map((item, itemIndex) => (_jsx("li", { className: styles.row, children: columns ? renderColumnRow(item, itemIndex) : renderStackedRow(item, itemIndex) }, itemIndex))) })] })), _jsxs("div", { className: styles.footer, children: [_jsx(InternalButton, { ref: addButtonRef, className: styles['add-button'], formAction: "none", disabled: disableAddButton, onClick: handleAdd, children: i18n('addButtonText', addButtonText) }), additionalInfo && _jsx("div", { className: styles['additional-info'], children: additionalInfo })] }), _jsx(InternalLiveRegion, { hidden: true, children: announcement })] }));
}
export const InternalAttributeEditor = React.forwardRef(InternalAttributeEditorWithRef);
