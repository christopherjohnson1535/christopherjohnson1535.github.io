import { jsx as _jsx } from "react/jsx-runtime";
// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { useContext } from 'react';
import { InternalFormField } from '../form-field/internal';
import { FormFieldContext } from '../internal/context/form-field-context';
// Under shared column headings, a control is named by its column's heading instead of a label of its own.
function LabelledBy({ id, children }) {
    const field = useContext(FormFieldContext);
    return _jsx(FormFieldContext.Provider, { value: { ...field, ariaLabelledby: id }, children: children });
}
export function AttributeField({ definition, item, itemIndex, headingId }) {
    const control = typeof definition.control === 'function' ? definition.control(item, itemIndex) : definition.control;
    const showLabel = headingId === undefined;
    return (_jsx(InternalFormField, { label: showLabel ? definition.label : undefined, info: showLabel ? definition.info : undefined, errorText: definition.errorText?.(item, itemIndex), warningText: definition.warningText?.(item, itemIndex), constraintText: definition.constraintText?.(item, itemIndex), stretch: true, children: headingId && definition.label ? _jsx(LabelledBy, { id: headingId, children: control }) : control }));
}
