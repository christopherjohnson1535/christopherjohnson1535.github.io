// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import React from 'react';
import { getBaseProps } from '../internal/base-component';
import { InternalAttributeEditor } from './internal';
function AttributeEditorWithRef({ items = [], definition, onAddButtonClick, onRemoveButtonClick, addButtonText, removeButtonText, removeButtonAriaLabel, isItemRemovable, empty, additionalInfo, disableAddButton = false, gridLayout, i18nStrings, ...props }, ref) {
    return (_jsx(InternalAttributeEditor, { ...getBaseProps(props), ref: ref, items: items, definition: definition, onAddButtonClick: onAddButtonClick, onRemoveButtonClick: onRemoveButtonClick, addButtonText: addButtonText, removeButtonText: removeButtonText, removeButtonAriaLabel: removeButtonAriaLabel, isItemRemovable: isItemRemovable, empty: empty, additionalInfo: additionalInfo, disableAddButton: disableAddButton, gridLayout: gridLayout, i18nStrings: i18nStrings }));
}
const AttributeEditor = React.forwardRef(AttributeEditorWithRef);
AttributeEditor.displayName = 'AttributeEditor';
export default AttributeEditor;
