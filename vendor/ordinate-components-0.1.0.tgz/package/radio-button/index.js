// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import React from 'react';
import { getBaseProps } from '../internal/base-component';
import { InternalRadioButton } from './internal';
const RadioButton = React.forwardRef(({ checked, name, value, onSelect, children, description, disabled = false, readOnly = false, ariaLabel, controlId, ariaLabelledby, ariaDescribedby, ...props }, ref) => (_jsx(InternalRadioButton, { ...getBaseProps(props), ref: ref, checked: checked, name: name, value: value, onSelect: onSelect, description: description, disabled: disabled, readOnly: readOnly, ariaLabel: ariaLabel, controlId: controlId, ariaLabelledby: ariaLabelledby, ariaDescribedby: ariaDescribedby, children: children })));
RadioButton.displayName = 'RadioButton';
export default RadioButton;
