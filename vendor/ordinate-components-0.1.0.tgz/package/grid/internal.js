import { jsx as _jsx } from "react/jsx-runtime";
import clsx from 'clsx';
import { childKey, flattenChildren } from '../internal/flatten-children';
import { warnOnce } from '../internal/logging';
import { getPlacements, placementStyle } from './placement';
import styles from './styles.css.js';
export function InternalGrid({ gridDefinition = [], disableGutters = false, children, ...rest }) {
    const items = flattenChildren(children);
    if (gridDefinition.length > 0 && gridDefinition.length !== items.length) {
        warnOnce('Grid', '`gridDefinition` should have one entry per child.');
    }
    const placements = getPlacements(items.map((_, index) => gridDefinition[index] ?? {}));
    return (_jsx("div", { ...rest, className: styles.root, children: _jsx("div", { className: clsx(styles.grid, !disableGutters && styles.gutters), children: items.map((child, index) => (_jsx("div", { className: styles.column, style: placementStyle(placements, index), children: child }, childKey(child, index)))) }) }));
}
