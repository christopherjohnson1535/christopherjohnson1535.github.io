// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalGrid } from './internal';
export default function Grid({ gridDefinition, disableGutters = false, children, ...props }) {
    return (_jsx(InternalGrid, { ...getBaseProps(props), gridDefinition: gridDefinition, disableGutters: disableGutters, children: children }));
}
