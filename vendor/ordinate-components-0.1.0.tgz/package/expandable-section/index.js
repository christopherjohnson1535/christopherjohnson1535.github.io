// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import React from 'react';
import { getBaseProps } from '../internal/base-component';
import { InternalExpandableSection } from './internal';
const ExpandableSection = React.forwardRef(({ variant = 'default', headerText, header, headerDescription, headerCounter, headerInfo, headerActions, headerAriaLabel, expanded, defaultExpanded = false, onChange, disableContentPaddings = false, headingTagOverride, children, ...props }, ref) => (_jsx(InternalExpandableSection, { ...getBaseProps(props), ref: ref, variant: variant, headerText: headerText, header: header, headerDescription: headerDescription, headerCounter: headerCounter, headerInfo: headerInfo, headerActions: headerActions, headerAriaLabel: headerAriaLabel, expanded: expanded, defaultExpanded: defaultExpanded, onChange: onChange, disableContentPaddings: disableContentPaddings, headingTagOverride: headingTagOverride, children: children })));
ExpandableSection.displayName = 'ExpandableSection';
export default ExpandableSection;
