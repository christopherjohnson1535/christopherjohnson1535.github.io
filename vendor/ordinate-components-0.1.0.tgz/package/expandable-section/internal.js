import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React, { useId, useImperativeHandle, useRef, useState } from 'react';
import clsx from 'clsx';
import { ConstructionTopLine } from '../internal/components/construction';
import { DimensionLine } from '../internal/components/dimension-line';
import { ExpandIcon } from '../internal/components/expand-icon';
import { fireNonCancelableEvent } from '../internal/events';
import { warnOnce } from '../internal/logging';
import { toMeasure } from '../table/header-counter';
import styles from './styles.css.js';
const containerVariants = ['container', 'stacked'];
const variantsWithoutDescription = ['navigation', 'inline'];
export const InternalExpandableSection = React.forwardRef(({ variant = 'default', headerText, header, headerDescription, headerCounter, headerInfo, headerActions, headerAriaLabel, expanded: controlledExpanded, defaultExpanded = false, onChange, disableContentPaddings = false, headingTagOverride, className, children, ...rest }, ref) => {
    const [uncontrolledExpanded, setUncontrolledExpanded] = useState(defaultExpanded);
    const isControlled = controlledExpanded !== undefined;
    const expanded = isControlled ? controlledExpanded : uncontrolledExpanded;
    const triggerRef = useRef(null);
    useImperativeHandle(ref, () => ({ focus: () => triggerRef.current?.focus() }));
    const id = useId();
    const triggerId = `${id}-trigger`;
    const contentId = `${id}-content`;
    const descriptionId = `${id}-description`;
    const isContainer = containerVariants.includes(variant);
    const showDescription = Boolean(headerDescription) && !variantsWithoutDescription.includes(variant);
    const hasCounter = isContainer && headerCounter !== undefined && headerCounter !== null;
    const HeadingTag = headingTagOverride ?? (isContainer ? 'h2' : undefined);
    if (!isContainer && (headerInfo || headerActions || headerCounter)) {
        warnOnce('ExpandableSection', '`headerCounter`, `headerInfo` and `headerActions` are only shown in the container and stacked variants.');
    }
    const toggle = () => {
        if (!isControlled) {
            setUncontrolledExpanded(!expanded);
        }
        fireNonCancelableEvent(onChange, { expanded: !expanded });
    };
    const trigger = (_jsxs("button", { ref: triggerRef, type: "button", id: triggerId, className: styles.trigger, "aria-expanded": expanded, "aria-controls": contentId, "aria-label": headerAriaLabel, "aria-describedby": showDescription ? descriptionId : undefined, onClick: toggle, children: [_jsx(ExpandIcon, { expanded: expanded, className: styles.icon }), _jsxs("span", { className: styles['header-text'], children: [headerText ?? header, hasCounter && (_jsxs(_Fragment, { children: [' ', _jsx("span", { className: styles['screenreader-only'], children: headerCounter })] }))] })] }));
    return (_jsxs("div", { ...rest, className: clsx(styles.root, styles[`variant-${variant}`], expanded && styles.expanded, className), children: [isContainer && _jsx(ConstructionTopLine, {}), _jsxs("div", { className: styles.header, children: [_jsxs("div", { className: styles['header-row'], children: [HeadingTag ? _jsx(HeadingTag, { className: styles.heading, children: trigger }) : trigger, isContainer && headerInfo && _jsx("span", { className: styles.info, children: headerInfo }), isContainer && headerActions && _jsx("div", { className: styles.actions, children: headerActions })] }), showDescription && (_jsx("p", { id: descriptionId, className: styles.description, children: headerDescription }))] }), hasCounter && (_jsx("div", { className: styles.counter, "aria-hidden": "true", children: _jsx(DimensionLine, { label: toMeasure(headerCounter) }) })), _jsx("div", { id: contentId, role: "group", "aria-labelledby": triggerId, className: clsx(styles.content, disableContentPaddings && styles['no-paddings']), hidden: !expanded, children: children })] }));
});
