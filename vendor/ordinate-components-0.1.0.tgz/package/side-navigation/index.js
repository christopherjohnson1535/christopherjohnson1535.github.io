// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalSideNavigation } from './internal';
export default function SideNavigation({ header, items = [], activeHref, ariaLabel, externalIconAriaLabel, onFollow, onChange, ...props }) {
    return (_jsx(InternalSideNavigation, { ...getBaseProps(props), header: header, items: items, activeHref: activeHref, ariaLabel: ariaLabel, externalIconAriaLabel: externalIconAriaLabel, onFollow: onFollow, onChange: onChange }));
}
