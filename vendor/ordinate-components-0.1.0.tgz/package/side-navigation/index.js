// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { warnOnce } from '../internal/logging';
import { InternalSideNavigation } from './internal';
import { containsCode } from './utils';
export default function SideNavigation({ header, items = [], activeHref, ariaLabel, externalIconAriaLabel, onFollow, onChange, ...props }) {
    if (containsCode(items)) {
        warnOnce('SideNavigation', 'Item codes are no longer drawn: the navigation shows item names only. `code` stops working in the next major version.');
    }
    return (_jsx(InternalSideNavigation, { ...getBaseProps(props), header: header, items: items, activeHref: activeHref, ariaLabel: ariaLabel, externalIconAriaLabel: externalIconAriaLabel, onFollow: onFollow, onChange: onChange }));
}
