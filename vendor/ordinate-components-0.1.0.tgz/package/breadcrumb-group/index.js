// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalBreadcrumbGroup } from './internal';
export default function BreadcrumbGroup({ items, ariaLabel, expandAriaLabel, onFollow, onClick, ...props }) {
    return (_jsx(InternalBreadcrumbGroup, { ...getBaseProps(props), items: items, ariaLabel: ariaLabel, expandAriaLabel: expandAriaLabel, onFollow: onFollow, onClick: onClick }));
}
