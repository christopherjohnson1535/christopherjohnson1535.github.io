import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { useEffect, useId, useRef, useState } from 'react';
import clsx from 'clsx';
import { InternalIcon } from '../icon/internal';
import { Dropdown } from '../internal/components/dropdown';
import { Leader } from '../internal/components/leader';
import { fireCancelableEvent } from '../internal/events';
import { useResizeObserver } from '../internal/hooks/use-resize-observer';
import { useInternalI18n } from '../internal/i18n/context';
import { isPlainLeftClick } from '../internal/link-click';
import { getHiddenCount } from './utils';
import styles from './styles.css.js';
// Each step leads to the next with a short leader, the mark for "goes somewhere else".
const separator = _jsx(Leader, { size: "short", className: styles.separator });
export function InternalBreadcrumbGroup({ items, ariaLabel, expandAriaLabel, onFollow, onClick, ...rest }) {
    const i18n = useInternalI18n('breadcrumb-group');
    const menuId = useId();
    const navRef = useRef(null);
    const measureRef = useRef(null);
    const expandButtonRef = useRef(null);
    const menuRef = useRef(null);
    const [hiddenCount, setHiddenCount] = useState(0);
    const [menuOpen, setMenuOpen] = useState(false);
    // Items are measured at their natural width in a hidden copy of the list, so the
    // decision does not depend on what is currently collapsed.
    const collapse = () => {
        const nav = navRef.current;
        const measure = measureRef.current;
        if (!nav || !measure) {
            return;
        }
        const widths = Array.from(measure.children, child => child.getBoundingClientRect().width);
        const ellipsisWidth = widths.pop() ?? 0;
        setHiddenCount(getHiddenCount(widths, ellipsisWidth, nav.clientWidth));
    };
    useResizeObserver(navRef, collapse);
    // The hidden copy changes width when the items change.
    useResizeObserver(measureRef, collapse);
    useEffect(() => {
        if (menuOpen) {
            menuRef.current?.querySelector('a')?.focus();
        }
    }, [menuOpen]);
    const follow = (item, event) => {
        const detail = { item, text: item.text, href: item.href };
        fireCancelableEvent(onClick, detail, event);
        if (isPlainLeftClick(event)) {
            fireCancelableEvent(onFollow, detail, event);
        }
    };
    const menuLinks = () => Array.from(menuRef.current?.querySelectorAll('a') ?? []);
    const closeMenuAndRestoreFocus = () => {
        setMenuOpen(false);
        expandButtonRef.current?.focus();
    };
    const onMenuKeyDown = (event) => {
        const links = menuLinks();
        const index = links.indexOf(document.activeElement);
        if (event.key === 'Escape') {
            event.preventDefault();
            closeMenuAndRestoreFocus();
        }
        else if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
            event.preventDefault();
            const step = event.key === 'ArrowDown' ? 1 : -1;
            links[(index + step + links.length) % links.length]?.focus();
        }
    };
    const lastIndex = items.length - 1;
    const hidden = items.slice(1, 1 + hiddenCount);
    const renderItem = (item, index) => index === lastIndex ? (_jsx("li", { className: clsx(styles.item, styles['current-item']), children: _jsx("span", { className: styles.current, "aria-current": "page", children: item.text }) }, index)) : (_jsxs("li", { className: styles.item, children: [_jsx("a", { className: styles.link, href: item.href, onClick: event => follow(item, event), children: item.text }), separator] }, index));
    const ellipsis = hiddenCount > 0 && (_jsxs("li", { className: clsx(styles.item, styles['ellipsis-item']), onBlur: event => {
            if (!event.currentTarget.contains(event.relatedTarget)) {
                setMenuOpen(false);
            }
        }, children: [_jsx(Dropdown, { className: styles.dropdown, open: menuOpen, onOutsideClick: () => setMenuOpen(false), trigger: _jsx("button", { ref: expandButtonRef, type: "button", className: styles['expand-button'], "aria-label": i18n('expandAriaLabel', expandAriaLabel), "aria-expanded": menuOpen, "aria-controls": menuOpen ? menuId : undefined, onClick: () => setMenuOpen(!menuOpen), onKeyDown: event => {
                        if (event.key === 'ArrowDown' && !menuOpen) {
                            event.preventDefault();
                            setMenuOpen(true);
                        }
                    }, children: _jsx(InternalIcon, { name: "more" }) }), children: _jsx("ul", { ref: menuRef, id: menuId, className: styles.menu, onKeyDown: onMenuKeyDown, children: hidden.map((item, index) => (_jsx("li", { children: _jsx("a", { className: styles['menu-link'], href: item.href, onClick: event => {
                                follow(item, event);
                                setMenuOpen(false);
                            }, children: item.text }) }, index))) }) }), separator] }, "ellipsis"));
    return (_jsxs("nav", { ...rest, ref: navRef, className: styles.root, "aria-label": i18n('ariaLabel', ariaLabel), children: [_jsxs("ol", { className: styles.list, children: [items.slice(0, 1).map(renderItem), ellipsis, items.slice(1 + hiddenCount).map((item, offset) => renderItem(item, 1 + hiddenCount + offset))] }), _jsx("div", { className: styles.measure, "aria-hidden": "true", children: _jsxs("ol", { ref: measureRef, className: clsx(styles.list, styles['measure-list']), children: [items.map((item, index) => (_jsxs("li", { className: clsx(styles.item, index === lastIndex && styles['current-item']), children: [_jsx("span", { className: index === lastIndex ? styles.current : styles.link, children: item.text }), index !== lastIndex && separator] }, index))), _jsxs("li", { className: styles.item, children: [_jsx("span", { className: styles['expand-button'], children: _jsx(InternalIcon, { name: "more" }) }), separator] })] }) })] }));
}
