import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { useSyncExternalStore } from 'react';
import clsx from 'clsx';
import { resolveLocale } from '../internal/dates/locale';
import { useInternalI18n } from '../internal/i18n/context';
import { warnOnce } from '../internal/logging';
import { dayIndexes, formatClockTime, formatDayName, parseClockTime, toDateTimeAttribute } from './format';
import styles from './styles.css.js';
// A page left open overnight shows the new day when the visitor comes back to it.
function subscribeToDayChange(onChange) {
    document.addEventListener('visibilitychange', onChange);
    return () => document.removeEventListener('visibilitychange', onChange);
}
const getVisitorDay = () => new Date().getDay();
const getServerDay = () => null;
/**
 * The visitor's day of the week, from 0 for Sunday. A server cannot know it, so server markup has no
 * day and hydration fills it in from the visitor's clock.
 */
function useVisitorDay(enabled) {
    const day = useSyncExternalStore(subscribeToDayChange, getVisitorDay, getServerDay);
    return enabled ? day : null;
}
function TimeRange({ opens, closes, locale, timeFormat, }) {
    const times = [opens, closes].map((value, index) => {
        const parsed = parseClockTime(value);
        if (!parsed) {
            warnOnce('OpeningHours', `"${value}" is not a time on a 24-hour clock, such as 08:00 or 17:30.`);
            return _jsx("span", { children: value }, index);
        }
        return (_jsx("time", { dateTime: toDateTimeAttribute(parsed), children: formatClockTime(parsed, locale, timeFormat) }, index));
    });
    return (_jsxs(_Fragment, { children: [times[0], '\u2009\u2013\u2009', times[1]] }));
}
export function InternalOpeningHours({ days, rows, highlightToday = false, caption, closedText, todayText, timeFormat, locale: localeProp, variant = 'default', ...rest }) {
    const i18n = useInternalI18n('opening-hours');
    const visitorDay = useVisitorDay(highlightToday && days !== undefined);
    const locale = resolveLocale(localeProp);
    const closedLabel = i18n('closedText', closedText);
    const displayRows = days
        ? days.map((entry, index) => {
            const closed = entry.closed === true || !entry.opens || !entry.closes;
            return {
                key: `${entry.day}-${index}`,
                label: entry.label ?? formatDayName(entry.day, locale),
                value: closed ? (closedLabel) : (_jsx(TimeRange, { opens: entry.opens, closes: entry.closes, locale: locale, timeFormat: timeFormat })),
                note: entry.note,
                closed,
                today: visitorDay === dayIndexes[entry.day],
            };
        })
        : (rows ?? []).map((row, index) => ({
            key: String(index),
            label: row.label,
            value: row.value,
            closed: false,
            today: false,
        }));
    return (_jsx("div", { ...rest, className: clsx(styles.root, styles[`variant-${variant}`]), children: _jsxs("table", { className: styles.table, children: [caption && _jsx("caption", { className: styles.caption, children: caption }), _jsx("tbody", { children: displayRows.map(row => (_jsxs("tr", { className: clsx(styles.row, row.closed && styles.closed, row.today && styles.today), children: [_jsxs("th", { scope: "row", className: styles.day, children: [_jsx("span", { className: styles['day-label'], children: row.label }), row.today && (_jsxs(_Fragment, { children: [_jsx("span", { className: styles['screenreader-only'], children: ", " }), _jsx("span", { className: styles['today-marker'], children: i18n('todayText', todayText) })] }))] }), _jsxs("td", { className: styles.hours, children: [_jsx("span", { className: styles.value, children: row.value }), row.note && _jsx("span", { className: styles.note, children: row.note })] })] }, row.key))) })] }) }));
}
