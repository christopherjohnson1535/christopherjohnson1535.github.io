// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalOpeningHours } from './internal';
export default function OpeningHours({ days, rows, highlightToday = false, caption, closedText, todayText, timeFormat, locale, variant = 'default', ...props }) {
    return (_jsx(InternalOpeningHours, { ...getBaseProps(props), days: days, rows: rows, highlightToday: highlightToday, caption: caption, closedText: closedText, todayText: todayText, timeFormat: timeFormat, locale: locale, variant: variant }));
}
