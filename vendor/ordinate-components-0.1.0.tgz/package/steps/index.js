// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalSteps } from './internal';
export default function Steps({ steps, orientation = 'vertical', ariaLabel, ariaLabelledby, ...props }) {
    return (_jsx(InternalSteps, { ...getBaseProps(props), steps: steps, orientation: orientation, ariaLabel: ariaLabel, ariaLabelledby: ariaLabelledby }));
}
