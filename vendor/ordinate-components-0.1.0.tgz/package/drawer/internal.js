import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import clsx from 'clsx';
import { LoadingStatus } from '../internal/components/loading-status';
import { useInternalI18n } from '../internal/i18n/context';
import styles from './styles.css.js';
export function InternalDrawer({ kind = 'neutral', reference, header, children, footer, loading = false, loadingText, disableContentPaddings = false, ...rest }) {
    const i18n = useInternalI18n('drawer');
    return (_jsxs("div", { ...rest, className: clsx(styles.root, styles[`kind-${kind}`]), "aria-busy": loading ? 'true' : undefined, children: [(header || reference) && (_jsxs("div", { className: styles['header-block'], children: [reference && _jsx("span", { className: styles.reference, children: reference }), header && _jsx("h2", { className: styles.header, children: header })] })), loading ? (_jsx(LoadingStatus, { className: styles.loading, text: i18n('loadingText', loadingText) })) : (_jsx("div", { className: clsx(styles.content, disableContentPaddings && styles['no-paddings']), children: children })), footer && !loading && _jsx("div", { className: styles.footer, children: footer })] }));
}
