// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalDrawer } from './internal';
export default function Drawer({ kind = 'neutral', reference, header, children, footer, loading = false, loadingText, disableContentPaddings = false, ...props }) {
    return (_jsx(InternalDrawer, { ...getBaseProps(props), kind: kind, reference: reference, header: header, footer: footer, loading: loading, loadingText: loadingText, disableContentPaddings: disableContentPaddings, children: children }));
}
