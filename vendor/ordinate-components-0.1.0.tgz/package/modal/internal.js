import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { useEffect, useId, useRef } from 'react';
import clsx from 'clsx';
import { InternalButton } from '../button/internal';
import { fireNonCancelableEvent } from '../internal/events';
import { useInternalI18n } from '../internal/i18n/context';
import styles from './styles.css.js';
const bodyOpenClassName = 'ord-modal-open';
export function InternalModal({ visible, onDismiss, header, footer, children, size = 'medium', position = 'center', disableContentPaddings = false, hideDismissButton = false, closeAriaLabel, ...rest }) {
    const i18n = useInternalI18n('modal');
    const dialogRef = useRef(null);
    const headingId = useId();
    useEffect(() => {
        const dialog = dialogRef.current;
        if (!dialog) {
            return;
        }
        if (visible && !dialog.open) {
            dialog.showModal();
        }
        else if (!visible && dialog.open) {
            dialog.close();
        }
    }, [visible]);
    useEffect(() => {
        if (!visible) {
            return;
        }
        document.body.classList.add(bodyOpenClassName);
        return () => document.body.classList.remove(bodyOpenClassName);
    }, [visible]);
    const dismiss = (reason) => fireNonCancelableEvent(onDismiss, { reason });
    return (_jsx("dialog", { ...rest, ref: dialogRef, className: clsx(styles.dialog, styles[`size-${size}`], styles[`position-${position}`]), "aria-labelledby": header ? headingId : undefined, onCancel: event => {
            event.preventDefault();
            dismiss('keyboard');
        }, onClick: event => {
            if (event.target === event.currentTarget) {
                dismiss('overlay');
            }
        }, children: _jsxs("div", { className: styles.container, children: [(header || !hideDismissButton) && (_jsxs("div", { className: clsx(styles.header, hideDismissButton && styles['header-without-dismiss']), children: [header && (_jsx("h2", { id: headingId, className: styles.heading, children: header })), !hideDismissButton && (_jsx(InternalButton, { className: styles['close-button'], variant: "icon", formAction: "none", iconName: "close", ariaLabel: i18n('closeAriaLabel', closeAriaLabel), onClick: () => dismiss('closeButton') }))] })), _jsx("div", { className: clsx(styles.content, disableContentPaddings && styles['no-paddings']), children: children }), footer && _jsx("div", { className: styles.footer, children: footer })] }) }));
}
