// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalModal } from './internal';
export default function Modal({ visible, onDismiss, header, footer, children, size = 'medium', position = 'center', disableContentPaddings = false, hideDismissButton = false, closeAriaLabel, ...props }) {
    return (_jsx(InternalModal, { ...getBaseProps(props), visible: visible, onDismiss: onDismiss, header: header, footer: footer, size: size, position: position, disableContentPaddings: disableContentPaddings, hideDismissButton: hideDismissButton, closeAriaLabel: closeAriaLabel, children: children }));
}
