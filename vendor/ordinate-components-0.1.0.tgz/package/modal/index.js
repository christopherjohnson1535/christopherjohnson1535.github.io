// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalModal } from './internal';
export default function Modal({ kind = 'neutral', reference, visible, onDismiss, header, footer, children, size = 'medium', position = 'center', disableContentPaddings = false, hideDismissButton = false, closeAriaLabel, ...props }) {
    return (_jsx(InternalModal, { ...getBaseProps(props), kind: kind, reference: reference, visible: visible, onDismiss: onDismiss, header: header, footer: footer, size: size, position: position, disableContentPaddings: disableContentPaddings, hideDismissButton: hideDismissButton, closeAriaLabel: closeAriaLabel, children: children }));
}
