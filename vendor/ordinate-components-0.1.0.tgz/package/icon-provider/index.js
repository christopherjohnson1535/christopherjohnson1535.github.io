// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { useContext, useMemo } from 'react';
import { IconProviderContext } from './context';
export default function IconProvider({ icons, children }) {
    const parent = useContext(IconProviderContext);
    const value = useMemo(() => (icons === null ? {} : { ...parent, ...icons }), [icons, parent]);
    return _jsx(IconProviderContext.Provider, { value: value, children: children });
}
