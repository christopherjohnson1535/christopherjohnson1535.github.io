// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { createContext } from 'react';
export const IconProviderContext = createContext({});
