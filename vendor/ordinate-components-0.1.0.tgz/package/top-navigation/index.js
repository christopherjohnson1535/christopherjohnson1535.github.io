// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalTopNavigation } from './internal';
export default function TopNavigation({ identity, utilities = [], search, i18nStrings, ...props }) {
    return (_jsx(InternalTopNavigation, { ...getBaseProps(props), identity: identity, utilities: utilities, search: search, i18nStrings: i18nStrings }));
}
