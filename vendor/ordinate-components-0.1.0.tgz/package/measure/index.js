// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalMeasure } from './internal';
export default function Measure({ label, value, unit, description, max, current, limit, limitLabel, format, i18nStrings, ...props }) {
    return (_jsx(InternalMeasure, { ...getBaseProps(props), label: label, value: value, unit: unit, description: description, max: max, current: current, limit: limit, limitLabel: limitLabel, format: format, i18nStrings: i18nStrings }));
}
