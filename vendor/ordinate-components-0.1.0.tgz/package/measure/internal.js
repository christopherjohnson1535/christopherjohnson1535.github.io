import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import clsx from 'clsx';
import { useFormatLocale } from '../file-token-group/format';
import { useInternalI18n } from '../internal/i18n/context';
import { warnOnce } from '../internal/logging';
import { getTicks, toPosition } from './scale';
import styles from './styles.css.js';
/**
 * The ruler under the reading. It only repeats numbers the text already says, so it is hidden from
 * screen readers.
 */
function Ruler({ max, current, limit, formattedZero, formattedMax }) {
    return (_jsxs("div", { className: styles.ruler, "aria-hidden": "true", children: [_jsxs("div", { className: styles.scale, children: [current !== undefined && (_jsx("span", { className: styles.run, style: { inlineSize: `${toPosition(current, max)}%` } })), getTicks(max).map(({ position, major }) => (_jsx("span", { className: clsx(styles.tick, major && styles['tick-major']), style: { insetInlineStart: `${position}%` } }, position))), limit !== undefined && (_jsx("span", { className: styles['limit-mark'], style: { insetInlineStart: `${toPosition(limit, max)}%` } }))] }), _jsxs("div", { className: styles.ends, children: [_jsx("span", { children: formattedZero }), _jsx("span", { children: formattedMax })] })] }));
}
export function InternalMeasure({ label, value, unit, description, max, current, limit, limitLabel, format, i18nStrings, className, ...rest }) {
    const i18n = useInternalI18n('measure');
    const locale = useFormatLocale();
    const formatNumber = format ?? new Intl.NumberFormat(locale).format;
    const hasScale = max !== undefined && max > 0 && Number.isFinite(max);
    if (max !== undefined && !hasScale) {
        warnOnce('Measure', '`max` must be a number above zero to draw a ruler.');
    }
    if (limit !== undefined && !hasScale) {
        warnOnce('Measure', '`limit` needs `max` to be placed on the ruler.');
    }
    const formattedMax = hasScale ? formatNumber(max) : '';
    const run = current ?? (typeof value === 'number' ? value : undefined);
    const showLimit = hasScale && limit !== undefined;
    const limitPosition = showLimit ? toPosition(limit, max) : 0;
    const limitText = showLimit
        ? (limitLabel ?? i18n('limitLabel', i18nStrings?.limitLabel?.(formatNumber(limit)), { limit: formatNumber(limit) }))
        : null;
    return (_jsxs("div", { ...rest, className: clsx(styles.root, className), children: [label && _jsx("div", { className: styles.label, children: label }), _jsxs("div", { className: styles.reading, children: [_jsx("span", { className: styles.value, children: typeof value === 'number' ? formatNumber(value) : value }), hasScale && (_jsxs(_Fragment, { children: [' ', _jsx("span", { className: styles.of, children: i18n('ofMax', i18nStrings?.ofMax?.(formattedMax), { max: formattedMax }) })] })), unit && (_jsxs(_Fragment, { children: [' ', _jsx("span", { className: styles.unit, children: unit })] }))] }), hasScale && (_jsx(Ruler, { max: max, current: run, limit: showLimit ? limit : undefined, formattedZero: formatNumber(0), formattedMax: formattedMax })), limitText && (_jsx("div", { className: styles['limit-row'], children: _jsx("span", { className: clsx(styles['limit-label'], limitPosition > 50 && styles['limit-label-end']), style: limitPosition <= 50
                        ? { marginInlineStart: `${limitPosition}%` }
                        : { marginInlineStart: 'auto', marginInlineEnd: `${100 - limitPosition}%` }, children: limitText }) })), description && _jsx("div", { className: styles.description, children: description })] }));
}
