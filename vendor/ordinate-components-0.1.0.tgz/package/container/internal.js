import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { useId } from 'react';
import clsx from 'clsx';
import { ConstructionTopLine, RuleEndMarks } from '../internal/components/construction';
import { DimensionLine } from '../internal/components/dimension-line';
import { Heading } from '../internal/components/heading';
import styles from './styles.css.js';
const isPresent = (node) => node !== undefined && node !== null && node !== false && node !== '';
/**
 * A section drawn like a detail on a drawing: construction lines that run past their corners, a dimension
 * line along the top of the content, hash marks wherever lines end or meet, and the heading in a margin
 * column. The marks are drawing only and stay out of the accessibility tree.
 */
export function InternalContainer({ kind = 'neutral', reference, heading, headingLevel = 2, description, measure, actions, footer, fitHeight = false, children, ...rest }) {
    const headingId = useId();
    const hasHeading = isPresent(heading);
    const hasMargin = hasHeading || isPresent(reference) || isPresent(description);
    const Root = hasHeading ? 'section' : 'div';
    return (_jsxs(Root, { ...rest, "aria-labelledby": hasHeading ? headingId : undefined, className: clsx(styles.root, styles[`kind-${kind}`], fitHeight && styles['fit-height']), children: [_jsx(ConstructionTopLine, { kind: kind }), _jsxs("div", { className: clsx(styles.layout, !hasMargin && styles['no-margin']), children: [hasMargin && (_jsxs("div", { className: styles.margin, children: [isPresent(reference) && _jsx("span", { className: clsx(styles.ink, styles.reference), children: reference }), hasHeading && (_jsx(Heading, { level: headingLevel, defaultLevel: 2, className: styles.heading, children: _jsx("span", { id: headingId, children: heading }) })), isPresent(description) && _jsx("p", { className: styles.description, children: description })] })), _jsxs("div", { className: styles.main, children: [_jsx("span", { className: clsx(styles.ink, styles['side-line']), "aria-hidden": "true" }), _jsx("span", { className: clsx(styles.ink, styles.mark, styles['mark-side-start']), "aria-hidden": "true" }), _jsx("span", { className: clsx(styles.ink, styles.mark, styles['mark-side-end']), "aria-hidden": "true" }), isPresent(measure) && _jsx(DimensionLine, { label: measure, className: clsx(styles.ink, styles.measure) }), isPresent(actions) && _jsx("div", { className: styles.actions, children: actions }), _jsx("div", { className: styles.content, children: children }), isPresent(footer) && (_jsxs("div", { className: styles.footer, children: [_jsx(RuleEndMarks, { kind: kind }), footer] }))] })] })] }));
}
