import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import clsx from 'clsx';
import styles from './styles.css.js';
export function InternalContainer({ header, disableHeaderPaddings = false, disableContentPaddings = false, footer, disableFooterPaddings = false, fitHeight = false, variant = 'default', className, children, ...rest }) {
    return (_jsxs("div", { ...rest, className: clsx(styles.root, styles[`variant-${variant}`], fitHeight && styles['fit-height'], className), children: [header && (_jsx("div", { className: clsx(styles.header, disableHeaderPaddings && styles['no-paddings']), children: typeof header === 'string' ? _jsx("div", { className: styles.label, children: header }) : header })), _jsx("div", { className: clsx(styles.content, disableContentPaddings && styles['no-paddings']), children: children }), footer && _jsx("div", { className: clsx(styles.footer, disableFooterPaddings && styles['no-paddings']), children: footer })] }));
}
