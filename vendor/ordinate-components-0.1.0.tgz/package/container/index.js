// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalContainer } from './internal';
export default function Container({ header, disableHeaderPaddings = false, disableContentPaddings = false, footer, disableFooterPaddings = false, fitHeight = false, variant = 'default', children, ...props }) {
    return (_jsx(InternalContainer, { ...getBaseProps(props), header: header, disableHeaderPaddings: disableHeaderPaddings, disableContentPaddings: disableContentPaddings, footer: footer, disableFooterPaddings: disableFooterPaddings, fitHeight: fitHeight, variant: variant, children: children }));
}
