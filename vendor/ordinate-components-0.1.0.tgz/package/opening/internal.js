import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import clsx from 'clsx';
import { Band } from '../internal/components/band';
import { Heading } from '../internal/components/heading';
import { SiteLinkList } from '../internal/components/site-link-list';
import { useInternalI18n } from '../internal/i18n/context';
import styles from './styles.css.js';
function OpeningMedia({ media, caption }) {
    if (!caption) {
        return (_jsx("div", { className: styles.media, children: _jsx("div", { className: styles['media-frame'], children: media }) }));
    }
    return (_jsxs("figure", { className: styles.media, children: [_jsx("div", { className: styles['media-frame'], children: media }), _jsx("figcaption", { className: styles['media-caption'], children: caption })] }));
}
export function InternalOpening({ variant = 'statement', title, kicker, meta, description, actions, links, navigationAriaLabel, onFollow, badge, media, mediaCaption, mediaPosition = 'end', headingLevel, ...rest }) {
    const i18n = useInternalI18n('opening');
    const isMasthead = variant === 'masthead';
    const hasLinks = links !== undefined && links.length > 0;
    const linksRow = hasLinks && (_jsx("nav", { className: styles.navigation, "aria-label": i18n('navigationAriaLabel', navigationAriaLabel), children: _jsx(SiteLinkList, { links: links, className: styles.links, linkClassName: styles.link, onFollow: onFollow }) }));
    const mediaBlock = media ? _jsx(OpeningMedia, { media: media, caption: mediaCaption }) : null;
    return (_jsx(Band, { ...rest, spacing: isMasthead ? 'small' : 'default', className: clsx(styles.root, styles[`variant-${variant}`]), innerClassName: styles.frame, children: _jsxs("div", { className: clsx(styles.layout, mediaBlock && !isMasthead && styles['has-media'], styles[`media-position-${mediaPosition}`]), children: [_jsxs("div", { className: styles.text, children: [meta && _jsx("div", { className: styles.meta, children: meta }), badge && (_jsx("div", { className: styles['badge-row'], children: _jsx("span", { className: styles.badge, children: badge }) })), kicker && _jsx("p", { className: styles.kicker, children: kicker }), _jsx(Heading, { level: headingLevel, defaultLevel: 1, className: styles.title, children: title }), description && _jsx("div", { className: styles.description, children: description }), actions && _jsx("div", { className: styles.actions, children: actions }), linksRow, isMasthead && _jsx("div", { className: styles['double-rule'], "aria-hidden": "true" })] }), mediaBlock] }) }));
}
