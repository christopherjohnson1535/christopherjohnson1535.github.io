import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { LoadingStatus } from '../internal/components/loading-status';
import { useInternalI18n } from '../internal/i18n/context';
import { InternalTextContent } from '../text-content/internal';
import styles from './styles.css.js';
/**
 * Help drawn as a margin note: a faint construction line down the start edge, a mono caption above the
 * title, and the help text beside the line.
 */
export function InternalHelpPanel({ header, children, footer, loading = false, loadingText, ...rest }) {
    const i18n = useInternalI18n('help-panel');
    if (loading) {
        return (_jsx("div", { ...rest, className: styles.root, "aria-busy": "true", children: _jsx(LoadingStatus, { className: styles.loading, text: i18n('loadingText', loadingText) }) }));
    }
    return (_jsxs("div", { ...rest, className: styles.root, children: [header && (_jsxs("div", { className: styles['header-block'], children: [_jsx("span", { className: styles.caption, children: i18n('captionText') }), _jsx("h2", { className: styles.header, children: header })] })), children !== undefined && children !== null && (_jsx(InternalTextContent, { className: styles.content, children: children })), footer && _jsx(InternalTextContent, { className: styles.footer, children: footer })] }));
}
