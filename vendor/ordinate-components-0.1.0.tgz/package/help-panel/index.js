// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalHelpPanel } from './internal';
export default function HelpPanel({ header, children, footer, loading = false, loadingText, ...props }) {
    return (_jsx(InternalHelpPanel, { ...getBaseProps(props), header: header, footer: footer, loading: loading, loadingText: loadingText, children: children }));
}
