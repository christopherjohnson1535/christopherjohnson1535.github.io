// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import React from 'react';
import { getBaseProps } from '../internal/base-component';
import { InternalTiles } from './internal';
const Tiles = React.forwardRef(({ value, items, onChange, columns, kind = 'neutral', name, readOnly = false, ariaLabel, ariaRequired, ariaControls, ariaLabelledby, ariaDescribedby, ...props }, ref) => (_jsx(InternalTiles, { ...getBaseProps(props), ref: ref, value: value, items: items, onChange: onChange, columns: columns, kind: kind, name: name, readOnly: readOnly, ariaLabel: ariaLabel, ariaRequired: ariaRequired, ariaControls: ariaControls, ariaLabelledby: ariaLabelledby, ariaDescribedby: ariaDescribedby })));
Tiles.displayName = 'Tiles';
export default Tiles;
