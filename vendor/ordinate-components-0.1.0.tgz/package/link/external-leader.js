import { jsx as _jsx } from "react/jsx-runtime";
import clsx from 'clsx';
import styles from './styles.css.js';
/**
 * A short diagonal leader, the mark for a link that leaves the application. It is drawn with the same strokes
 * as `Leader`, as tall as the capitals of the text beside it, and points the other way in right-to-left pages.
 */
export function ExternalLeader({ ariaLabel, className }) {
    return (_jsx("span", { className: clsx(styles['external-leader'], className), ...(ariaLabel ? { role: 'img', 'aria-label': ariaLabel } : { 'aria-hidden': true }), children: _jsx("svg", { viewBox: "0 0 10 10", focusable: "false", "aria-hidden": "true", children: _jsx("path", { d: "M2 8 8 2M4 2h4v4" }) }) }));
}
