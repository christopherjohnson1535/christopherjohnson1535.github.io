// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import React from 'react';
import { getBaseProps } from '../internal/base-component';
import { InternalLink } from './internal';
const Link = React.forwardRef(({ children, variant = 'secondary', href, external = false, externalIconAriaLabel, target, rel, fontSize = 'body-m', color = 'normal', ariaLabel, onFollow, onClick, ...props }, ref) => (_jsx(InternalLink, { ...getBaseProps(props), ref: ref, variant: variant, href: href, external: external, externalIconAriaLabel: externalIconAriaLabel, target: target, rel: rel, fontSize: fontSize, color: color, ariaLabel: ariaLabel, onFollow: onFollow, onClick: onClick, children: children })));
Link.displayName = 'Link';
export default Link;
