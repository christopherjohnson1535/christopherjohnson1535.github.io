import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import clsx from 'clsx';
import styles from './styles.css.js';
function isGroup(item) {
    return item.type === 'group';
}
function Pair({ pair }) {
    return (_jsxs("div", { className: styles.pair, children: [_jsxs("dt", { id: pair.id, className: styles.label, children: [_jsx("span", { className: styles['label-text'], children: pair.label }), pair.info && _jsx("span", { className: styles.info, children: pair.info })] }), _jsx("dd", { className: styles.value, children: pair.value })] }));
}
// A group is one term (its title) whose description is a nested list of pairs, which keeps the markup a
// valid description list at every level.
function Group({ group }) {
    return (_jsxs("div", { className: styles.group, children: [_jsx("dt", { className: styles['group-title'], children: group.title }), _jsx("dd", { className: styles['group-content'], children: _jsx("dl", { className: styles['group-list'], children: group.items.map((pair, index) => (_jsx(Pair, { pair: pair }, index))) }) })] }));
}
export function InternalKeyValuePairs({ items, columns = 1, ariaLabel, ariaLabelledby, className, ...rest }) {
    return (_jsx("div", { ...rest, className: clsx(styles.root, className), children: _jsx("dl", { className: clsx(styles.list, styles[`columns-${columns}`]), "aria-label": ariaLabel, "aria-labelledby": ariaLabelledby, children: items.map((item, index) => isGroup(item) ? _jsx(Group, { group: item }, index) : _jsx(Pair, { pair: item }, index)) }) }));
}
