// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalKeyValuePairs } from './internal';
export default function KeyValuePairs({ items, columns = 1, ariaLabel, ariaLabelledby, ...props }) {
    return (_jsx(InternalKeyValuePairs, { ...getBaseProps(props), items: items, columns: columns, ariaLabel: ariaLabel, ariaLabelledby: ariaLabelledby }));
}
