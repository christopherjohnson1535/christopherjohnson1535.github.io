// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalTutorialPanel } from './internal';
export default function TutorialPanel({ tutorials, loading = false, onFeedbackClick, downloadUrl, i18nStrings, ...props }) {
    return (_jsx(InternalTutorialPanel, { ...getBaseProps(props), tutorials: tutorials, loading: loading, onFeedbackClick: onFeedbackClick, downloadUrl: downloadUrl, i18nStrings: i18nStrings }));
}
