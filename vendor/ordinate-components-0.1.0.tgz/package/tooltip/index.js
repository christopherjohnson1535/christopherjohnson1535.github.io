// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalTooltip } from './internal';
export default function Tooltip({ content, children, position = 'top', ...props }) {
    return (_jsx(InternalTooltip, { ...getBaseProps(props), content: content, position: position, children: children }));
}
