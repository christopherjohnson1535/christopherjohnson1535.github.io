// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalPullQuote } from './internal';
/**
 * A line lifted from the text and set large, to draw readers in. It renders a `<figure>` with a
 * `<blockquote>` and a `<figcaption>` for the attribution.
 */
export default function PullQuote({ children, attribution, variant = 'default', ...props }) {
    return (_jsx(InternalPullQuote, { ...getBaseProps(props), attribution: attribution, variant: variant, children: children }));
}
