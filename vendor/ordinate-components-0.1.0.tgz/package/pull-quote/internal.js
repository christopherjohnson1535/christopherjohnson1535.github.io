import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import clsx from 'clsx';
import styles from './styles.css.js';
export function InternalPullQuote({ children, attribution, variant = 'default', ...rest }) {
    return (_jsxs("figure", { ...rest, className: clsx(styles.root, styles[`variant-${variant}`]), children: [variant === 'hanging' && (_jsx("span", { className: styles.mark, "aria-hidden": "true", children: '“' })), _jsx("blockquote", { className: styles.quote, children: children }), attribution && _jsx("figcaption", { className: styles.attribution, children: attribution })] }));
}
