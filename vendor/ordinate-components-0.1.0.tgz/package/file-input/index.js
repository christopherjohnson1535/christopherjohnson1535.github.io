// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import React from 'react';
import { getBaseProps } from '../internal/base-component';
import { InternalFileInput } from './internal';
const FileInput = React.forwardRef(({ value, onChange, multiple = false, accept, variant = 'button', children, ariaLabel, ariaRequired, disabled = false, controlId, ariaLabelledby, ariaDescribedby, invalid, warning, ...props }, ref) => (_jsx(InternalFileInput, { ...getBaseProps(props), ref: ref, value: value, onChange: onChange, multiple: multiple, accept: accept, variant: variant, ariaLabel: ariaLabel, ariaRequired: ariaRequired, disabled: disabled, controlId: controlId, ariaLabelledby: ariaLabelledby, ariaDescribedby: ariaDescribedby, invalid: invalid, warning: warning, children: children })));
FileInput.displayName = 'FileInput';
export default FileInput;
