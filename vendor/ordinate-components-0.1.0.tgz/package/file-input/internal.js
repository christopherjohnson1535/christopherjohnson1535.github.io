import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React, { useEffect, useId, useImperativeHandle, useRef } from 'react';
import clsx from 'clsx';
import { InternalButton } from '../button/internal';
import { useFormFieldContext } from '../internal/context/form-field-context';
import { fireNonCancelableEvent } from '../internal/events';
import { useInternalI18n } from '../internal/i18n/context';
import styles from './styles.css.js';
// Keeps the native input holding the same files as `value`, so that screen readers announce the
// chosen files and a surrounding form submits them. Browsers without a DataTransfer constructor keep
// whatever the user last picked.
function syncNativeFiles(input, files) {
    if (!input || typeof DataTransfer === 'undefined') {
        return;
    }
    try {
        const transfer = new DataTransfer();
        files.forEach(file => transfer.items.add(file));
        input.files = transfer.files;
    }
    catch {
        // Some older browsers expose DataTransfer but do not let scripts construct or assign it.
    }
}
export const InternalFileInput = React.forwardRef(({ value, onChange, multiple = false, accept, variant = 'button', children, ariaLabel, ariaRequired, disabled = false, controlId, ariaLabelledby, ariaDescribedby, invalid, warning, className, ...rest }, ref) => {
    const i18n = useInternalI18n('file-input');
    const field = useFormFieldContext({ controlId, ariaLabelledby, ariaDescribedby, invalid, warning });
    const inputRef = useRef(null);
    const textId = useId();
    useImperativeHandle(ref, () => ({ focus: () => inputRef.current?.focus() }));
    useEffect(() => syncNativeFiles(inputRef.current, value), [value]);
    const text = children ?? i18n('uploadButtonText', undefined, { multiple: String(multiple) });
    const handleChange = (event) => {
        const picked = Array.from(event.target.files ?? []);
        // Cancelling the file chooser can clear the native input without the value changing.
        if (picked.length === 0) {
            syncNativeFiles(inputRef.current, value);
            return;
        }
        fireNonCancelableEvent(onChange, { value: multiple ? [...value, ...picked] : picked.slice(0, 1) });
    };
    const labelledBy = ariaLabel
        ? ariaLabelledby
        : [field.ariaLabelledby, textId].filter(Boolean).join(' ') || undefined;
    return (_jsxs("span", { ...rest, className: clsx(styles.root, className), children: [_jsx("span", { id: textId, hidden: true, children: text }), _jsx("input", { ref: inputRef, type: "file", id: field.controlId, className: styles['native-input'], multiple: multiple, accept: accept, disabled: disabled, "aria-label": ariaLabel, "aria-labelledby": labelledBy, "aria-describedby": field.ariaDescribedby, "aria-invalid": field.invalid ? 'true' : undefined, "aria-required": ariaRequired ? 'true' : undefined, onChange: handleChange }), _jsx(InternalButton, { className: clsx(styles.trigger, field.invalid && styles.invalid, field.warning && !field.invalid && styles.warning), variant: variant === 'icon' ? 'icon' : 'normal', iconName: "upload", formAction: "none", disabled: disabled, ariaLabel: variant === 'icon' ? (ariaLabel ?? (typeof text === 'string' ? text : undefined)) : undefined, tabIndex: -1, "aria-hidden": "true", onClick: () => inputRef.current?.click(), children: variant === 'button' ? text : undefined })] }));
});
