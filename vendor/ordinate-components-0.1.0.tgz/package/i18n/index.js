// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { useMemo } from 'react';
import { I18nContext, mergeMessages } from '../internal/i18n/context';
/**
 * Supplies translated labels to every Ordinate component inside it. A label passed
 * to a component as a prop always takes precedence.
 */
export default function I18nProvider({ locale, messages, children }) {
    const value = useMemo(() => ({ locale: locale ?? null, messages: mergeMessages(messages) }), [locale, messages]);
    return _jsx(I18nContext.Provider, { value: value, children: children });
}
