// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalErrorBoundary } from './internal';
export default function ErrorBoundary({ children, errorBoundaryId, onError, renderFallback, feedbackHref, i18nStrings, ...props }) {
    return (_jsx(InternalErrorBoundary, { ...getBaseProps(props), errorBoundaryId: errorBoundaryId, onError: onError, renderFallback: renderFallback, feedbackHref: feedbackHref, i18nStrings: i18nStrings, children: children }));
}
