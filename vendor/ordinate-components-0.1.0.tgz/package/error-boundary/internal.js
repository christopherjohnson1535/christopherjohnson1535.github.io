import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React from 'react';
import clsx from 'clsx';
import { InternalAlert } from '../alert/internal';
import { InternalButton } from '../button/internal';
import { getBaseProps } from '../internal/base-component';
import { fireNonCancelableEvent } from '../internal/events';
import { useInternalI18n } from '../internal/i18n/context';
import { InternalLink } from '../link/internal';
import styles from './styles.css.js';
// Anything can be thrown, but consumers should only ever have to handle an Error.
function toError(thrown) {
    return thrown instanceof Error ? thrown : new Error(String(thrown));
}
function DefaultFallback({ feedbackHref, i18nStrings }) {
    const i18n = useInternalI18n('error-boundary');
    return (_jsxs(InternalAlert, { type: "fault", header: _jsx("span", { className: styles.header, children: i18n('headerText', i18nStrings?.headerText) }), action: _jsx(InternalButton, { className: styles['refresh-button'], formAction: "none", iconName: "refresh", onClick: () => window.location.reload(), children: i18n('refreshActionText', i18nStrings?.refreshActionText) }), children: [_jsx("span", { className: styles.description, children: i18n('descriptionText', i18nStrings?.descriptionText) }), feedbackHref && (_jsxs(_Fragment, { children: [' ', _jsx(InternalLink, { className: styles['feedback-link'], variant: "primary", href: feedbackHref, children: i18n('feedbackLinkText', i18nStrings?.feedbackLinkText) })] }))] }));
}
// Error boundaries can only be class components; the fallback is a function component so it can use hooks.
export class InternalErrorBoundary extends React.Component {
    constructor() {
        super(...arguments);
        this.state = { error: null };
    }
    static getDerivedStateFromError(thrown) {
        return { error: toError(thrown) };
    }
    componentDidCatch(thrown, errorInfo) {
        fireNonCancelableEvent(this.props.onError, {
            error: toError(thrown),
            errorInfo,
            errorBoundaryId: this.props.errorBoundaryId,
        });
    }
    render() {
        const { children, errorBoundaryId, renderFallback, feedbackHref, i18nStrings, className } = this.props;
        const { error } = this.state;
        if (!error) {
            return children;
        }
        // The fallback replaces content the user may have been reading, so it is announced as it appears.
        return (_jsx("div", { ...getBaseProps(this.props), className: clsx(styles.root, className), role: "alert", children: renderFallback ? (renderFallback({ error, errorBoundaryId })) : (_jsx(DefaultFallback, { feedbackHref: feedbackHref, i18nStrings: i18nStrings })) }));
    }
}
