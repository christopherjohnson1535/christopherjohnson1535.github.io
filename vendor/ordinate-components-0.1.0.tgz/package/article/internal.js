import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import clsx from 'clsx';
import { warnOnce } from '../internal/logging';
import { InternalTextContent } from '../text-content/internal';
import styles from './styles.css.js';
function getColumns(columns) {
    if (columns !== 1 && columns !== 2) {
        warnOnce('Article', '`columns` must be 1 or 2.');
        return 1;
    }
    return columns;
}
export function InternalArticle({ children, lead, byline, dropCap = false, columns = 1, measure = 'default', ...rest }) {
    return (_jsx("div", { ...rest, className: clsx(styles.root, styles[`measure-${measure}`], styles[`columns-${getColumns(columns)}`], dropCap && styles['drop-cap']), children: _jsxs("div", { className: styles.measure, children: [lead && _jsx("p", { className: styles.lead, children: lead }), byline && _jsx("div", { className: styles.byline, children: byline }), _jsx(InternalTextContent, { className: styles.body, children: children })] }) }));
}
