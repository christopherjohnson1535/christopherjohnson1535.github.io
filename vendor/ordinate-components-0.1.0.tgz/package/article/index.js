// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalArticle } from './internal';
export default function Article({ children, lead, byline, dropCap = false, columns = 1, measure = 'default', ...props }) {
    return (_jsx(InternalArticle, { ...getBaseProps(props), lead: lead, byline: byline, dropCap: dropCap, columns: columns, measure: measure, children: children }));
}
