// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalHeader } from './internal';
export default function Header({ variant = 'h2', headingTagOverride, description, actions, counter, info, code, children, ...props }) {
    return (_jsx(InternalHeader, { ...getBaseProps(props), variant: variant, headingTagOverride: headingTagOverride, description: description, actions: actions, counter: counter, info: info, code: code, children: children }));
}
