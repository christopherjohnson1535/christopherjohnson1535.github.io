import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
import clsx from 'clsx';
import styles from './styles.css.js';
export function InternalHeader({ variant = 'h2', headingTagOverride, description, actions, counter, info, code, className, children, ...rest }) {
    const HeadingTag = headingTagOverride ?? variant;
    return (_jsxs("div", { ...rest, className: clsx(styles.root, styles[`variant-${variant}`], className), children: [_jsxs("div", { className: styles.main, children: [_jsxs("div", { className: styles['heading-group'], children: [code && _jsx("div", { className: styles.code, children: code }), _jsxs("div", { className: styles.title, children: [_jsxs(HeadingTag, { className: styles.heading, children: [_jsx("span", { className: styles['heading-text'], children: children }), counter !== undefined && counter !== null && (_jsxs(_Fragment, { children: [' ', _jsx("span", { className: styles.counter, children: counter })] }))] }), info && _jsx("span", { className: styles.info, children: info })] })] }), actions && _jsx("div", { className: styles.actions, children: actions })] }), description && _jsx("p", { className: styles.description, children: description })] }));
}
