// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalTreeView } from './internal';
export default function TreeView({ items, getItemId, getItemChildren, renderItem, expandedItems, onItemToggle, renderItemToggleIcon, ariaLabel, ariaLabelledby, ariaDescribedby, i18nStrings, ...props }) {
    return (_jsx(InternalTreeView, { ...getBaseProps(props), items: items, getItemId: getItemId, getItemChildren: getItemChildren, renderItem: renderItem, expandedItems: expandedItems, onItemToggle: onItemToggle, renderItemToggleIcon: renderItemToggleIcon, ariaLabel: ariaLabel, ariaLabelledby: ariaLabelledby, ariaDescribedby: ariaDescribedby, i18nStrings: i18nStrings }));
}
