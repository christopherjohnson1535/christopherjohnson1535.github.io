import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import clsx from 'clsx';
import { LeaderRow } from '../internal/components/leader-row';
import { StretchedLink } from '../internal/components/stretched-link';
import { fireCancelableEvent } from '../internal/events';
import styles from './styles.css.js';
function rowNumber(item, index, ordered, variant) {
    if (item.number !== undefined) {
        return { text: item.number, automatic: false };
    }
    if (!ordered) {
        return undefined;
    }
    const position = String(index + 1);
    return { text: variant === 'numbered' ? position.padStart(2, '0') : position, automatic: true };
}
function NumberCell({ number }) {
    return (_jsx("span", { className: styles.number, "aria-hidden": number?.automatic || undefined, children: number?.text }));
}
export function InternalIndexList({ items, variant = 'leaders', size = 'default', ordered = false, ariaLabel, onFollow, ...rest }) {
    const List = ordered ? 'ol' : 'ul';
    const numbers = items.map((item, index) => rowNumber(item, index, ordered, variant));
    const hasNumbers = numbers.some(number => number !== undefined);
    const renderLabel = (item) => item.href ? (_jsx(StretchedLink, { href: item.href, onFollow: event => fireCancelableEvent(onFollow, { id: item.id, href: item.href }, event), children: item.label })) : (item.label);
    return (_jsx("div", { ...rest, className: clsx(styles.root, styles[`variant-${variant}`], styles[`size-${size}`], hasNumbers && styles['has-numbers']), children: _jsx(List, { className: styles.list, "aria-label": ariaLabel, children: items.map((item, index) => (_jsxs("li", { className: styles.item, children: [hasNumbers && _jsx(NumberCell, { number: numbers[index] }), variant === 'leaders' ? (_jsxs("span", { className: styles.body, children: [_jsx(LeaderRow, { label: renderLabel(item), value: item.value, labelClassName: styles.label, valueClassName: styles.value }), item.meta && _jsx("span", { className: styles.meta, children: item.meta })] })) : (_jsxs(_Fragment, { children: [_jsx("span", { className: styles.label, children: renderLabel(item) }), (item.meta || item.value) && (_jsxs("span", { className: styles.details, children: [item.meta && _jsx("span", { className: styles.meta, children: item.meta }), item.meta && item.value && ' ', item.value && _jsx("span", { className: styles.value, children: item.value })] }))] }))] }, item.id))) }) }));
}
