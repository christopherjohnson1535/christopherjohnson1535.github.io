import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { useCallback, useId, useRef } from 'react';
import { InternalButton } from '../button/internal';
import { fireNonCancelableEvent } from '../internal/events';
import { useInternalI18n } from '../internal/i18n/context';
import styles from './styles.css.js';
/**
 * Focuses the element when it mounts and, when it unmounts with focus still inside,
 * gives focus back to whatever had it before. A ref callback runs on detach while the
 * element is still in the document, which an effect cleanup does not guarantee.
 */
function useFocusOnMount() {
    const elementRef = useRef(null);
    const previousRef = useRef(null);
    return useCallback((element) => {
        if (element) {
            const active = element.ownerDocument.activeElement;
            previousRef.current = active instanceof HTMLElement && !element.contains(active) ? active : null;
            elementRef.current = element;
            element.focus({ preventScroll: true });
            return;
        }
        const mounted = elementRef.current;
        if (mounted?.contains(mounted.ownerDocument.activeElement) && previousRef.current?.isConnected) {
            previousRef.current.focus({ preventScroll: true });
        }
        elementRef.current = null;
        previousRef.current = null;
    }, []);
}
export function InternalDialog({ header, children, footer, onDismiss, dismissAriaLabel, ariaLabel, ...rest }) {
    const i18n = useInternalI18n('dialog');
    const headingId = useId();
    const focusRef = useFocusOnMount();
    const dismiss = (reason) => fireNonCancelableEvent(onDismiss, { reason });
    const closeButton = (_jsx(InternalButton, { className: styles['close-button'], variant: "icon", formAction: "none", iconName: "close", ariaLabel: i18n('dismissAriaLabel', dismissAriaLabel), onClick: () => dismiss('closeButton') }));
    return (_jsxs("div", { ...rest, ref: focusRef, role: "dialog", tabIndex: -1, className: styles.dialog, "aria-labelledby": header ? headingId : undefined, "aria-label": header ? undefined : ariaLabel, onKeyDown: event => {
            if (event.key === 'Escape') {
                // Closes only this dialog, not a modal or panel around it.
                event.preventDefault();
                event.stopPropagation();
                dismiss('keyboard');
            }
        }, children: [header ? (_jsxs(_Fragment, { children: [_jsxs("div", { className: styles.header, children: [_jsx("h2", { id: headingId, className: styles.heading, children: header }), closeButton] }), children && _jsx("div", { className: styles.content, children: children })] })) : (_jsxs("div", { className: styles['content-row'], children: [_jsx("div", { className: styles.content, children: children }), closeButton] })), footer && _jsx("div", { className: styles.footer, children: footer })] }));
}
