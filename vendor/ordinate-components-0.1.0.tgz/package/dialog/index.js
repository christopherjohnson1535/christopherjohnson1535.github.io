// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalDialog } from './internal';
export default function Dialog({ header, children, footer, onDismiss, dismissAriaLabel, ariaLabel, ...props }) {
    return (_jsx(InternalDialog, { ...getBaseProps(props), header: header, footer: footer, onDismiss: onDismiss, dismissAriaLabel: dismissAriaLabel, ariaLabel: ariaLabel, children: children }));
}
