import { jsx as _jsx } from "react/jsx-runtime";
// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { useState } from 'react';
import clsx from 'clsx';
import { fireNonCancelableEvent } from '../internal/events';
import { hasFiles, useFilesDragging } from '../internal/hooks/use-files-dragging';
import styles from './styles.css.js';
export function InternalFileDropzone({ onChange, children, className, ...rest }) {
    const pageDragging = useFilesDragging();
    const [over, setOver] = useState(false);
    const accept = (event) => {
        if (!hasFiles(event.dataTransfer)) {
            return;
        }
        event.preventDefault();
        event.dataTransfer.dropEffect = 'copy';
        setOver(true);
    };
    const leave = (event) => {
        // Leave also fires when the pointer moves onto a child of the zone, which is still over it.
        const next = event.relatedTarget;
        if (!(next instanceof Node && event.currentTarget.contains(next))) {
            setOver(false);
        }
    };
    const drop = (event) => {
        event.preventDefault();
        setOver(false);
        const files = Array.from(event.dataTransfer.files ?? []);
        if (files.length > 0) {
            fireNonCancelableEvent(onChange, { value: files });
        }
    };
    // A drag that ends elsewhere, such as outside the window, never leaves the zone.
    const active = over && pageDragging;
    return (_jsx("div", { ...rest, className: clsx(styles.root, pageDragging && styles['page-dragging'], active && styles.active, className), onDragEnter: accept, onDragOver: accept, onDragLeave: leave, onDrop: drop, children: _jsx("div", { className: styles.content, children: children }) }));
}
