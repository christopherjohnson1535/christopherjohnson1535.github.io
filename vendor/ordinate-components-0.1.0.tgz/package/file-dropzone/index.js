// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalFileDropzone } from './internal';
export default function FileDropzone({ onChange, children, ...props }) {
    return (_jsx(InternalFileDropzone, { ...getBaseProps(props), onChange: onChange, children: children }));
}
