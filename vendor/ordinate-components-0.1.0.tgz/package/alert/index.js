// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import React from 'react';
import { getBaseProps } from '../internal/base-component';
import { warnOnce } from '../internal/logging';
import { InternalAlert } from './internal';
const legacyTypes = {
    info: 'note',
    success: 'complete',
    warning: 'caution',
    error: 'fault',
};
function resolveType(type) {
    if (Object.prototype.hasOwnProperty.call(legacyTypes, type)) {
        const current = legacyTypes[type];
        warnOnce('Alert', `The type "${type}" is now called "${current}". The old name stops working in the next major version.`);
        return current;
    }
    return type;
}
const Alert = React.forwardRef(({ type = 'note', header, children, action, dismissible = false, onDismiss, dismissAriaLabel, statusIconAriaLabel, i18nStrings, ...props }, ref) => (_jsx(InternalAlert, { ...getBaseProps(props), ref: ref, type: resolveType(type), header: header, action: action, dismissible: dismissible, onDismiss: onDismiss, dismissAriaLabel: dismissAriaLabel, statusIconAriaLabel: statusIconAriaLabel, i18nStrings: i18nStrings, children: children })));
Alert.displayName = 'Alert';
export default Alert;
