// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import React from 'react';
import { getBaseProps } from '../internal/base-component';
import { InternalAlert } from './internal';
const Alert = React.forwardRef(({ type = 'info', header, children, action, dismissible = false, onDismiss, dismissAriaLabel, statusIconAriaLabel, ...props }, ref) => (_jsx(InternalAlert, { ...getBaseProps(props), ref: ref, type: type, header: header, action: action, dismissible: dismissible, onDismiss: onDismiss, dismissAriaLabel: dismissAriaLabel, statusIconAriaLabel: statusIconAriaLabel, children: children })));
Alert.displayName = 'Alert';
export default Alert;
