import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React, { useId, useImperativeHandle, useRef } from 'react';
import clsx from 'clsx';
import { InternalButton } from '../button/internal';
import { InternalIcon } from '../icon/internal';
import { ConstructionTopLine } from '../internal/components/construction';
import { fireNonCancelableEvent } from '../internal/events';
import { useInternalI18n } from '../internal/i18n/context';
import { InternalLiveRegion } from '../live-region/internal';
import { InternalSpinner } from '../spinner/internal';
import styles from './styles.css.js';
/**
 * A note drawn like a section: a construction line in the note's color opens it, the icon and the kind of
 * note sit in the margin, and the title, text and action follow in ink. Flashbar draws its items with it.
 */
export const InternalAlert = React.forwardRef(({ type = 'note', header, children, action, dismissible = false, onDismiss, dismissAriaLabel, statusIconAriaLabel, i18nStrings, loading = false, caption, announce, className, ...rest }, ref) => {
    const i18n = useInternalI18n('alert');
    const focusRef = useRef(null);
    const headerId = useId();
    const labelKey = `${type}Label`;
    const label = caption ?? i18n(labelKey, i18nStrings?.[labelKey]);
    // The group only becomes focusable for the moment it is focused, so it never joins the tab order.
    useImperativeHandle(ref, () => ({
        focus: () => {
            if (focusRef.current) {
                focusRef.current.tabIndex = -1;
                focusRef.current.focus();
            }
        },
    }));
    const note = (_jsxs(_Fragment, { children: [_jsxs("div", { className: styles.side, children: [_jsx("span", { className: styles.icon, children: loading ? (_jsx("span", { role: statusIconAriaLabel ? 'img' : undefined, "aria-label": statusIconAriaLabel, "aria-hidden": statusIconAriaLabel ? undefined : 'true', children: _jsx(InternalSpinner, {}) })) : (_jsx(InternalIcon, { name: type, ariaLabel: statusIconAriaLabel })) }), _jsx("span", { className: styles.label, children: label })] }), (header || children) && (_jsxs("div", { className: styles.message, children: [header && (_jsx("div", { id: headerId, className: styles.header, children: header })), children && _jsx("div", { className: styles.content, children: children })] }))] }));
    return (_jsxs("div", { ...rest, className: clsx(styles.alert, styles[`type-${type}`], loading && styles.loading, className), children: [_jsx(ConstructionTopLine, { kind: type }), _jsxs("div", { className: styles.layout, children: [_jsxs("div", { ref: focusRef, className: styles.body, role: "group", "aria-labelledby": header ? headerId : undefined, onBlur: () => focusRef.current?.removeAttribute('tabindex'), children: [announce ? _jsx(InternalLiveRegion, { assertive: announce === 'assertive', children: note }) : note, action && _jsx("div", { className: styles['action-slot'], children: action })] }), dismissible && (_jsx("div", { className: styles.dismiss, children: _jsx(InternalButton, { variant: "icon", formAction: "none", ariaLabel: i18n('dismissAriaLabel', dismissAriaLabel), iconSvg: _jsx(InternalIcon, { name: "close" }), onClick: () => fireNonCancelableEvent(onDismiss, null) }) }))] })] }));
});
