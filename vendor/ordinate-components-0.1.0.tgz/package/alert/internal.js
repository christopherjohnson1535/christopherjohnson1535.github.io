import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React, { useId, useImperativeHandle, useRef } from 'react';
import clsx from 'clsx';
import { InternalButton } from '../button/internal';
import { InternalIcon } from '../icon/internal';
import { fireNonCancelableEvent } from '../internal/events';
import { useInternalI18n } from '../internal/i18n/context';
import styles from './styles.css.js';
const typeToIcon = {
    info: 'status-info',
    success: 'status-positive',
    warning: 'status-warning',
    error: 'status-negative',
};
export const InternalAlert = React.forwardRef(({ type = 'info', header, children, action, dismissible = false, onDismiss, dismissAriaLabel, statusIconAriaLabel, ...rest }, ref) => {
    const i18n = useInternalI18n('alert');
    const focusRef = useRef(null);
    const headerId = useId();
    // The group only becomes focusable for the moment it is focused, so it never joins the tab order.
    useImperativeHandle(ref, () => ({
        focus: () => {
            if (focusRef.current) {
                focusRef.current.tabIndex = -1;
                focusRef.current.focus();
            }
        },
    }));
    return (_jsx("div", { ...rest, className: clsx(styles.alert, styles[`type-${type}`]), children: _jsxs("div", { className: styles.layout, children: [_jsxs("div", { ref: focusRef, className: styles.body, role: "group", "aria-labelledby": header ? headerId : undefined, onBlur: () => focusRef.current?.removeAttribute('tabindex'), children: [_jsx("span", { className: styles.icon, children: _jsx(InternalIcon, { name: typeToIcon[type], ariaLabel: statusIconAriaLabel }) }), _jsxs("div", { className: styles.message, children: [header && (_jsx("div", { id: headerId, className: styles.header, children: header })), children && _jsx("div", { className: styles.content, children: children })] })] }), action && _jsx("div", { className: styles['action-slot'], children: action }), dismissible && (_jsx("div", { className: styles.dismiss, children: _jsx(InternalButton, { variant: "icon", formAction: "none", ariaLabel: i18n('dismissAriaLabel', dismissAriaLabel), iconSvg: _jsx(InternalIcon, { name: "close" }), onClick: () => fireNonCancelableEvent(onDismiss, null) }) }))] }) }));
});
