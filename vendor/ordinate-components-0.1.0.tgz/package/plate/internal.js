import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import clsx from 'clsx';
import { Heading } from '../internal/components/heading';
import { raiseInteractiveClassName, StretchedLink } from '../internal/components/stretched-link';
import { fireCancelableEvent } from '../internal/events';
import styles from './styles.css.js';
export function InternalPlate({ media, label, title, href, onFollow, meta, description, headingLevel = 3, ...rest }) {
    return (_jsxs("article", { ...rest, className: clsx(styles.root, href && styles.linked), children: [media && _jsx("div", { className: styles.media, children: media }), _jsxs("div", { className: styles.caption, children: [(label || meta) && (_jsxs("div", { className: styles.line, children: [label && _jsx("span", { className: styles.label, children: label }), label && meta && ' ', meta && _jsx("span", { className: clsx(styles.meta, raiseInteractiveClassName), children: meta })] })), _jsx(Heading, { level: headingLevel, defaultLevel: 3, className: styles.title, children: href ? (_jsx(StretchedLink, { href: href, onFollow: event => fireCancelableEvent(onFollow, { href }, event), children: title })) : (title) }), description && _jsx("div", { className: styles.description, children: description })] })] }));
}
