// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalList } from './internal';
export default function List({ items, renderItem, tagOverride, ariaLabel, sortable = false, onSortingChange, i18nStrings, ...props }) {
    return (_jsx(InternalList, { ...getBaseProps(props), items: items, renderItem: renderItem, tagOverride: tagOverride, ariaLabel: ariaLabel, sortable: sortable, onSortingChange: onSortingChange, i18nStrings: i18nStrings }));
}
