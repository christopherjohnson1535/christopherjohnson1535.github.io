import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { useEffect, useId, useRef } from 'react';
import { InternalButton } from '../button/internal';
import { fireNonCancelableEvent } from '../internal/events';
import { useInternalI18n } from '../internal/i18n/context';
import styles from './styles.css.js';
function move(items, from, to) {
    const next = [...items];
    const [item] = next.splice(from, 1);
    next.splice(to, 0, item);
    return next;
}
export function InternalList({ items, renderItem, tagOverride, ariaLabel, sortable = false, onSortingChange, i18nStrings, ...rest }) {
    const i18n = useInternalI18n('list');
    const baseId = useId();
    const Tag = tagOverride ?? (sortable ? 'ol' : 'ul');
    const rows = items.map(renderItem);
    const buttonRefs = useRef(new Map());
    const pendingFocus = useRef(null);
    // Moving a row moves its element, which drops focus in most browsers. Put it back on the moved row,
    // on the other button once the row reaches an end and its own button is disabled.
    useEffect(() => {
        const pending = pendingFocus.current;
        if (!pending) {
            return;
        }
        pendingFocus.current = null;
        const index = rows.findIndex(row => row.id === pending.id);
        const atEnd = pending.direction === -1 ? index === 0 : index === rows.length - 1;
        const direction = atEnd ? -pending.direction : pending.direction;
        buttonRefs.current.get(`${pending.id}:${direction}`)?.focus();
    });
    const moveRow = (index, direction) => {
        pendingFocus.current = { id: rows[index].id, direction };
        fireNonCancelableEvent(onSortingChange, { items: move(items, index, index + direction) });
    };
    const renderSortButton = (id, index, direction) => (_jsx(InternalButton, { ref: button => {
            buttonRefs.current.set(`${id}:${direction}`, button);
        }, variant: "icon", iconName: direction === -1 ? 'arrow-up' : 'arrow-down', formAction: "none", ariaLabel: direction === -1
            ? i18n('moveUpAriaLabel', i18nStrings?.moveUpAriaLabel)
            : i18n('moveDownAriaLabel', i18nStrings?.moveDownAriaLabel), disabled: direction === -1 ? index === 0 : index === rows.length - 1, onClick: () => moveRow(index, direction) }));
    return (_jsx(Tag, { ...rest, className: styles.root, "aria-label": ariaLabel, children: rows.map((row, index) => {
            const contentId = `${baseId}${index}`;
            return (_jsxs("li", { className: styles.item, children: [_jsxs("div", { className: styles.main, children: [row.icon && _jsx("span", { className: styles.icon, children: row.icon }), _jsxs("div", { className: styles.text, children: [_jsx("div", { id: contentId, className: styles.content, children: row.content }), row.secondaryContent && _jsx("div", { className: styles['secondary-content'], children: row.secondaryContent })] })] }), row.actions && _jsx("div", { className: styles.actions, children: row.actions }), sortable && (_jsxs("div", { className: styles['sort-controls'], role: "group", "aria-labelledby": contentId, children: [renderSortButton(row.id, index, -1), renderSortButton(row.id, index, 1)] }))] }, row.id));
        }) }));
}
