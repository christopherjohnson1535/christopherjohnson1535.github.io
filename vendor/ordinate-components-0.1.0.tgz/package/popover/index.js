// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import React from 'react';
import { getBaseProps } from '../internal/base-component';
import { InternalPopover } from './internal';
const Popover = React.forwardRef(({ children, content, header, position = 'right', size = 'medium', fixedWidth = false, triggerType = 'text', wrapTriggerText = true, dismissButton = true, dismissAriaLabel, renderWithPortal = false, ...props }, ref) => (_jsx(InternalPopover, { ...getBaseProps(props), ref: ref, content: content, header: header, position: position, size: size, fixedWidth: fixedWidth, triggerType: triggerType, wrapTriggerText: wrapTriggerText, dismissButton: dismissButton, dismissAriaLabel: dismissAriaLabel, renderWithPortal: renderWithPortal, children: children })));
Popover.displayName = 'Popover';
export default Popover;
