import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React, { useEffect, useId, useImperativeHandle, useRef, useState } from 'react';
import clsx from 'clsx';
import { InternalButton } from '../button/internal';
import { FloatingPanel } from '../internal/components/floating-panel';
import { getFirstTabbable, wrapTabFocus } from '../internal/focus';
import { useInternalI18n } from '../internal/i18n/context';
import styles from './styles.css.js';
export const InternalPopover = React.forwardRef(({ children, content, header, position = 'right', size = 'medium', fixedWidth = false, triggerType = 'text', wrapTriggerText = true, dismissButton = true, dismissAriaLabel, renderWithPortal = false, ...rest }, ref) => {
    const i18n = useInternalI18n('popover');
    const [open, setOpen] = useState(false);
    const rootRef = useRef(null);
    const triggerRef = useRef(null);
    const panelRef = useRef(null);
    const baseId = useId();
    const triggerId = `${baseId}trigger`;
    const headerId = `${baseId}header`;
    const panelId = `${baseId}panel`;
    const focusTrigger = () => {
        const trigger = triggerRef.current;
        if (trigger) {
            // A custom trigger wraps the consumer's own focusable element.
            (triggerType === 'text' ? trigger : (getFirstTabbable(trigger) ?? trigger)).focus();
        }
    };
    const close = (returnFocus) => {
        setOpen(false);
        if (returnFocus) {
            focusTrigger();
        }
    };
    useImperativeHandle(ref, () => ({ focus: focusTrigger, dismiss: () => setOpen(false) }));
    useEffect(() => {
        if (open && dismissButton) {
            panelRef.current?.focus({ preventScroll: true });
        }
    }, [open, dismissButton]);
    useEffect(() => {
        if (!open) {
            return;
        }
        const handleMouseDown = (event) => {
            const target = event.target;
            if (!rootRef.current?.contains(target) && !panelRef.current?.contains(target)) {
                setOpen(false);
            }
        };
        document.addEventListener('mousedown', handleMouseDown);
        return () => document.removeEventListener('mousedown', handleMouseDown);
    }, [open]);
    const handleKeyDown = (event) => {
        if (open && event.key === 'Escape') {
            // Stops a surrounding modal or dialog from closing too.
            event.preventDefault();
            event.stopPropagation();
            close(true);
        }
    };
    const toggle = () => setOpen(current => !current);
    const trigger = triggerType === 'text' ? (_jsx("button", { ref: triggerRef, id: triggerId, type: "button", className: clsx(styles.trigger, styles['trigger-text'], !wrapTriggerText && styles['no-wrap']), "aria-haspopup": "dialog", "aria-expanded": open, "aria-controls": open ? panelId : undefined, onClick: toggle, children: children })) : (_jsx("span", { ref: triggerRef, id: triggerId, className: clsx(styles.trigger, styles['trigger-custom']), onClick: toggle, children: children }));
    // Sits on the first line of the header, or of the content when there is no header.
    const dismiss = dismissButton && (_jsx("span", { className: styles.dismiss, children: _jsx(InternalButton, { className: styles['dismiss-button'], variant: "icon", formAction: "none", iconName: "close", ariaLabel: i18n('dismissAriaLabel', dismissAriaLabel), onClick: () => close(true) }) }));
    return (_jsxs("span", { ...rest, ref: rootRef, className: styles.root, onKeyDown: handleKeyDown, children: [trigger, open && (_jsxs(FloatingPanel, { ref: panelRef, id: panelId, trigger: triggerRef, preferredSide: position, renderWithPortal: renderWithPortal, role: "dialog", "aria-labelledby": header ? headerId : triggerId, tabIndex: -1, className: clsx(styles.panel, styles[`size-${size}`], fixedWidth && styles['fixed-width']), onKeyDown: dismissButton ? event => wrapTabFocus(event, event.currentTarget) : undefined, children: [header && (_jsxs("span", { className: styles['header-row'], children: [_jsx("span", { id: headerId, className: styles.header, children: header }), dismiss] })), _jsxs("span", { className: styles.body, children: [_jsx("span", { className: styles.content, children: content }), !header && dismiss] })] }))] }));
});
