import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { useId } from 'react';
import clsx from 'clsx';
import { warnOnce } from '../internal/logging';
import styles from './styles.css.js';
export function InternalDivider({ orientation = 'horizontal', className, children, ...rest }) {
    const labelId = useId();
    const hasLabel = children !== undefined && children !== null && children !== false;
    if (hasLabel && orientation === 'vertical') {
        warnOnce('Divider', 'Vertical dividers do not show a label.');
    }
    if (hasLabel && orientation === 'horizontal') {
        // The content of a separator is presentational, so the label names it instead.
        return (_jsxs("div", { ...rest, role: "separator", "aria-labelledby": labelId, className: clsx(styles.divider, styles.labelled, className), children: [_jsx("span", { className: styles.line }), _jsx("span", { id: labelId, className: styles.label, children: children }), _jsx("span", { className: styles.line })] }));
    }
    return (_jsx("hr", { ...rest, "aria-orientation": orientation === 'vertical' ? 'vertical' : undefined, className: clsx(styles.divider, styles[orientation], className) }));
}
