// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalDivider } from './internal';
export default function Divider({ orientation = 'horizontal', children, ...props }) {
    return (_jsx(InternalDivider, { ...getBaseProps(props), orientation: orientation, children: children }));
}
