// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalTruncatedText } from './internal';
export default function TruncatedText({ children, lines = 1, ...props }) {
    return (_jsx(InternalTruncatedText, { ...getBaseProps(props), lines: lines, children: children }));
}
