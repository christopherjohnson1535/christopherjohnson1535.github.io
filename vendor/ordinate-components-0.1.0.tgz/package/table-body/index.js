// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalTableBody } from './internal';
export default function TableBody({ children, ...props }) {
    return _jsx(InternalTableBody, { ...getBaseProps(props), children: children });
}
