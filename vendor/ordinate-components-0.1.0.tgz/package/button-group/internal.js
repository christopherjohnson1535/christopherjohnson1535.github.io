import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React, { useImperativeHandle, useRef, useState } from 'react';
import clsx from 'clsx';
import { getLogicalArrowStep } from '../internal/direction';
import { getRovingIndex } from '../internal/roving-focus';
import { ActionItem, itemAttribute, MenuItem } from './items';
import styles from './styles.css.js';
function getMove(event) {
    switch (event.key) {
        case 'Home':
            return 'first';
        case 'End':
            return 'last';
    }
    const step = getLogicalArrowStep(event.key, event.currentTarget);
    if (step === 0) {
        return null;
    }
    return step === 1 ? 'next' : 'previous';
}
function flattenItems(items) {
    return items.flatMap(entry => (entry.type === 'group' ? entry.items : [entry]));
}
function getFocusTarget(control) {
    return control.querySelector('button');
}
export const InternalButtonGroup = React.forwardRef(({ items, onItemClick, variant = 'icon', ariaLabel, ...rest }, ref) => {
    const rootRef = useRef(null);
    // The action that keeps the tab stop after the user moves through the toolbar.
    const [focusedId, setFocusedId] = useState(null);
    const actions = flattenItems(items);
    const canFocus = (index) => !actions[index]?.disabled;
    const focusedIndex = actions.findIndex(action => action.id === focusedId);
    const tabStopIndex = focusedIndex >= 0 && canFocus(focusedIndex)
        ? focusedIndex
        : getRovingIndex('first', -1, actions.length, canFocus);
    const tabStopId = actions[tabStopIndex]?.id;
    const getControls = () => Array.from(rootRef.current?.querySelectorAll(`[${itemAttribute}]`) ?? []);
    useImperativeHandle(ref, () => ({
        focus: (itemId) => {
            const control = getControls().find(element => element.getAttribute(itemAttribute) === itemId);
            if (control) {
                getFocusTarget(control)?.focus();
            }
        },
    }));
    const handleKeyDown = (event) => {
        // Keys pressed in an open menu belong to the menu, even though they bubble through here.
        const control = event.target.closest(`[${itemAttribute}]`);
        const move = getMove(event);
        if (!control || !event.currentTarget.contains(control) || !move) {
            return;
        }
        event.preventDefault();
        const controls = getControls();
        const next = getRovingIndex(move, controls.indexOf(control), controls.length, index => {
            const target = getFocusTarget(controls[index]);
            return target !== null && !target.disabled;
        });
        if (next >= 0) {
            getFocusTarget(controls[next])?.focus();
        }
    };
    const renderItem = (item) => {
        const props = {
            tabIndex: item.id === tabStopId ? 0 : -1,
            onItemClick,
            onItemFocus: setFocusedId,
        };
        return item.type === 'menu-dropdown' ? (_jsx(MenuItem, { item: item, ...props }, item.id)) : (_jsx(ActionItem, { item: item, ...props }, item.id));
    };
    return (_jsx("div", { ...rest, ref: rootRef, role: "toolbar", "aria-label": ariaLabel, className: clsx(styles.root, styles[`variant-${variant}`]), onKeyDown: handleKeyDown, children: items.map((entry, index) => {
            const previous = items[index - 1];
            const separated = previous !== undefined && (entry.type === 'group' || previous.type === 'group');
            const key = entry.type === 'group' ? `group-${index}` : entry.id;
            return (_jsxs(React.Fragment, { children: [separated && _jsx("span", { className: styles.divider, "aria-hidden": "true" }), entry.type === 'group' ? (_jsx("div", { role: "group", "aria-label": entry.text, className: styles.group, children: entry.items.map(renderItem) })) : (renderItem(entry))] }, key));
        }) }));
});
