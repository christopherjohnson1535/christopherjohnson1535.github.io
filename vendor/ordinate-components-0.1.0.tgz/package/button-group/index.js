// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import React from 'react';
import { getBaseProps } from '../internal/base-component';
import { InternalButtonGroup } from './internal';
const ButtonGroup = React.forwardRef(({ items, onItemClick, variant = 'icon', ariaLabel, ...props }, ref) => (_jsx(InternalButtonGroup, { ...getBaseProps(props), ref: ref, items: items, onItemClick: onItemClick, variant: variant, ariaLabel: ariaLabel })));
ButtonGroup.displayName = 'ButtonGroup';
export default ButtonGroup;
