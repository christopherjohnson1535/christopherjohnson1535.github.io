// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalSplitPanel } from './internal';
export default function SplitPanel({ header, headerTag, headerDescription, headerInfo, headerActions, children, closeBehavior = 'collapse', hidePreferencesButton = false, i18nStrings, ...props }) {
    return (_jsx(InternalSplitPanel, { ...getBaseProps(props), header: header, headerTag: headerTag, headerDescription: headerDescription, headerInfo: headerInfo, headerActions: headerActions, closeBehavior: closeBehavior, hidePreferencesButton: hidePreferencesButton, i18nStrings: i18nStrings, children: children }));
}
