import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { useEffect, useRef, useState } from 'react';
import clsx from 'clsx';
import { InternalButton } from '../button/internal';
import { fireNonCancelableEvent } from '../internal/events';
import { useInternalI18n } from '../internal/i18n/context';
import { InternalModal } from '../modal/internal';
import { ContentDisplay } from './content-display';
import { CheckboxPreference, NumberChoice, StickyColumns } from './preferences';
import { createDraft } from './utils';
import styles from './styles.css.js';
export function InternalCollectionPreferences({ title, confirmLabel, cancelLabel, disabled = false, preferences, onConfirm, onCancel, pageSizePreference, wrapLinesPreference, stripedRowsPreference, contentDensityPreference, stickyColumnsPreference, contentDisplayPreference, customPreference, ...rest }) {
    const i18n = useInternalI18n('collection-preferences');
    const triggerRef = useRef(null);
    const [visible, setVisible] = useState(false);
    const [draft, setDraft] = useState({});
    const returnFocus = useRef(false);
    const update = (changes) => setDraft(current => ({ ...current, ...changes }));
    // Runs after the modal has closed its dialog, when the rest of the page can take focus again.
    useEffect(() => {
        if (!visible && returnFocus.current) {
            returnFocus.current = false;
            triggerRef.current?.focus();
        }
    }, [visible]);
    const open = () => {
        setDraft(createDraft(preferences, contentDisplayPreference?.options));
        setVisible(true);
    };
    const close = () => {
        returnFocus.current = true;
        setVisible(false);
    };
    const confirm = () => {
        close();
        fireNonCancelableEvent(onConfirm, draft);
    };
    const cancel = () => {
        close();
        fireNonCancelableEvent(onCancel, null);
    };
    const heading = i18n('title', title);
    const hasSettings = Boolean(pageSizePreference ||
        wrapLinesPreference ||
        stripedRowsPreference ||
        contentDensityPreference ||
        stickyColumnsPreference ||
        customPreference);
    const twoColumns = hasSettings && Boolean(contentDisplayPreference);
    return (_jsxs("div", { ...rest, className: styles.root, children: [_jsx(InternalButton, { ref: triggerRef, className: styles.trigger, variant: "icon", iconName: "adjust", formAction: "none", ariaLabel: heading, ariaHaspopup: "dialog", disabled: disabled, onClick: open }), _jsx(InternalModal, { visible: visible, header: heading, size: twoColumns ? 'large' : 'medium', onDismiss: cancel, footer: _jsxs(_Fragment, { children: [_jsx(InternalButton, { className: styles['cancel-button'], variant: "link", formAction: "none", onClick: cancel, children: i18n('cancelLabel', cancelLabel) }), _jsx(InternalButton, { className: styles['confirm-button'], variant: "primary", formAction: "none", onClick: confirm, children: i18n('confirmLabel', confirmLabel) })] }), children: _jsx("div", { className: styles['layout-container'], children: _jsxs("div", { className: clsx(styles.layout, twoColumns && styles['two-columns']), children: [hasSettings && (_jsxs("div", { className: styles.column, children: [pageSizePreference && (_jsx(NumberChoice, { className: styles['page-size'], title: i18n('pageSizeTitle', pageSizePreference.title), options: pageSizePreference.options, value: draft.pageSize, onChange: pageSize => update({ pageSize }) })), wrapLinesPreference && (_jsx(CheckboxPreference, { className: styles['wrap-lines'], label: i18n('wrapLinesLabel', wrapLinesPreference.label), description: i18n('wrapLinesDescription', wrapLinesPreference.description), checked: draft.wrapLines ?? false, onChange: wrapLines => update({ wrapLines }) })), stripedRowsPreference && (_jsx(CheckboxPreference, { className: styles['striped-rows'], label: i18n('stripedRowsLabel', stripedRowsPreference.label), description: i18n('stripedRowsDescription', stripedRowsPreference.description), checked: draft.stripedRows ?? false, onChange: stripedRows => update({ stripedRows }) })), contentDensityPreference && (_jsx(CheckboxPreference, { className: styles['content-density'], label: i18n('contentDensityLabel', contentDensityPreference.label), description: i18n('contentDensityDescription', contentDensityPreference.description), checked: draft.contentDensity === 'compact', onChange: compact => update({ contentDensity: compact ? 'compact' : 'comfortable' }) })), stickyColumnsPreference && (_jsx(StickyColumns, { preference: stickyColumnsPreference, value: draft.stickyColumns, onChange: stickyColumns => update({ stickyColumns }), i18n: i18n })), customPreference && (_jsx("div", { className: styles.custom, children: customPreference(draft.custom, custom => update({ custom })) }))] })), contentDisplayPreference && (_jsx("div", { className: clsx(styles.column, twoColumns && styles['secondary-column']), children: _jsx(ContentDisplay, { preference: contentDisplayPreference, value: draft.contentDisplay ?? [], onChange: contentDisplay => update({ contentDisplay }) }) }))] }) }) })] }));
}
