// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalCollectionPreferences } from './internal';
export default function CollectionPreferences({ title, confirmLabel, cancelLabel, disabled = false, preferences, onConfirm, onCancel, pageSizePreference, wrapLinesPreference, stripedRowsPreference, contentDensityPreference, stickyColumnsPreference, contentDisplayPreference, customPreference, ...props }) {
    return (_jsx(InternalCollectionPreferences, { ...getBaseProps(props), title: title, confirmLabel: confirmLabel, cancelLabel: cancelLabel, disabled: disabled, preferences: preferences, onConfirm: onConfirm, onCancel: onCancel, pageSizePreference: pageSizePreference, wrapLinesPreference: wrapLinesPreference, stripedRowsPreference: stripedRowsPreference, contentDensityPreference: contentDensityPreference, stickyColumnsPreference: stickyColumnsPreference, contentDisplayPreference: contentDisplayPreference, customPreference: customPreference }));
}
