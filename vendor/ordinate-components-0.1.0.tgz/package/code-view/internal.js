import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { useEffect, useMemo, useState } from 'react';
import clsx from 'clsx';
import { getLoadedParser, loadParser, toLines } from './highlight';
import styles from './styles.css.js';
export function InternalCodeView({ content, language = 'text', lineNumbers = true, highlightedLines, lineNotes, wrapLines = false, ariaLabel, ariaLabelledby, className, ...rest }) {
    const [loaded, setLoaded] = useState(() => ({ language, parser: getLoadedParser(language) }));
    const parser = loaded.language === language ? loaded.parser : getLoadedParser(language);
    useEffect(() => {
        if (parser !== undefined) {
            return;
        }
        let current = true;
        loadParser(language).then(next => current && setLoaded({ language, parser: next }), () => current && setLoaded({ language, parser: null }));
        return () => {
            current = false;
        };
    }, [language, parser]);
    const code = content.endsWith('\n') ? content.slice(0, -1) : content;
    const lines = useMemo(() => toLines(code, parser, language), [code, parser, language]);
    const highlighted = new Set(highlightedLines);
    const notes = new Map();
    for (const note of lineNotes ?? []) {
        notes.set(note.line, [...(notes.get(note.line) ?? []), note.text]);
    }
    const named = Boolean(ariaLabel || ariaLabelledby);
    return (_jsx("div", { ...rest, className: clsx(styles.root, wrapLines && styles['wrap-lines'], className), role: named ? 'region' : undefined, "aria-label": ariaLabel, "aria-labelledby": ariaLabelledby, 
        // The code can be wider than its frame, and keyboard users need to reach it to scroll.
        tabIndex: 0, dir: "ltr", children: _jsx("pre", { className: styles.pre, children: _jsx("code", { className: styles.code, children: lines.map((segments, index) => {
                    const number = index + 1;
                    const isHighlighted = highlighted.has(number);
                    return (_jsxs("span", { className: clsx(styles.line, isHighlighted && styles['line-highlighted']), "data-line": number, children: [lineNumbers && (_jsx("span", { className: styles['line-number'], "aria-hidden": "true", children: number })), _jsx("span", { className: styles['line-content'], children: segments.map((segment, k) => segment.kinds ? (_jsx("span", { className: clsx(segment.kinds.map(kind => styles[`token-${kind}`])), children: segment.text }, k)) : (segment.text)) }), notes.get(number)?.map((text, k) => (_jsx("span", { className: styles['line-note'], children: text }, k))), '\n'] }, number));
                }) }) }) }));
}
