import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { useEffect, useRef } from 'react';
import clsx from 'clsx';
import { fireCancelableEvent, fireNonCancelableEvent } from '../internal/events';
import { isPlainLeftClick } from '../internal/link-click';
import { useScrollSpy } from './use-scroll-spy';
import { buildAnchorTree, toFollowDetail } from './utils';
import styles from './styles.css.js';
function AnchorList({ nodes, activeHref, onFollow, depth = 1, }) {
    // Levels below the third are drawn like the third, so deep outlines keep their width.
    const level = Math.min(depth, 3);
    return (_jsx("ol", { className: styles.list, children: nodes.map(({ anchor, children }, index) => {
            const active = anchor.href === activeHref;
            return (_jsxs("li", { className: styles.item, children: [_jsxs("div", { className: styles['link-row'], children: [_jsx("a", { className: clsx(styles.link, styles[`level-${level}`], active && styles['link-active']), href: anchor.href, "aria-current": active ? 'true' : undefined, onClick: event => {
                                    if (isPlainLeftClick(event)) {
                                        onFollow(event, anchor);
                                    }
                                }, children: anchor.text }), anchor.info && _jsx("span", { className: styles.info, children: anchor.info })] }), children.length > 0 && (_jsx(AnchorList, { nodes: children, activeHref: activeHref, onFollow: onFollow, depth: depth + 1 }))] }, `${anchor.href}-${index}`));
        }) }));
}
export function InternalAnchorNavigation({ anchors, activeHref: controlledActiveHref, scrollSpyOffset = 0, onFollow, onActiveHrefChange, ariaLabelledby, ...rest }) {
    const isControlled = controlledActiveHref !== undefined;
    const [trackedHref, setTrackedHref] = useScrollSpy(anchors.map(anchor => anchor.href), scrollSpyOffset, !isControlled);
    const activeHref = isControlled ? controlledActiveHref : trackedHref;
    const reportedHref = useRef(undefined);
    useEffect(() => {
        if (isControlled || trackedHref === undefined || trackedHref === reportedHref.current) {
            return;
        }
        reportedHref.current = trackedHref;
        const anchor = anchors.find(candidate => candidate.href === trackedHref);
        if (anchor) {
            fireNonCancelableEvent(onActiveHrefChange, toFollowDetail(anchor));
        }
    });
    const follow = (event, anchor) => {
        const cancelled = fireCancelableEvent(onFollow, toFollowDetail(anchor), event);
        // A section near the end of the page may never scroll up to the line, so mark it right away.
        if (!cancelled && !isControlled) {
            setTrackedHref(anchor.href);
        }
    };
    return (_jsx("nav", { ...rest, className: styles.root, "aria-labelledby": ariaLabelledby, children: _jsx(AnchorList, { nodes: buildAnchorTree(anchors), activeHref: activeHref, onFollow: follow }) }));
}
