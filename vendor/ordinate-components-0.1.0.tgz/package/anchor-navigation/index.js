// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalAnchorNavigation } from './internal';
export default function AnchorNavigation({ anchors, activeHref, scrollSpyOffset = 0, onFollow, onActiveHrefChange, ariaLabelledby, ...props }) {
    return (_jsx(InternalAnchorNavigation, { ...getBaseProps(props), anchors: anchors, activeHref: activeHref, scrollSpyOffset: scrollSpyOffset, onFollow: onFollow, onActiveHrefChange: onActiveHrefChange, ariaLabelledby: ariaLabelledby }));
}
