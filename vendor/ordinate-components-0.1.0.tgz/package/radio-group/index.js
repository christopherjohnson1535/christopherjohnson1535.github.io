// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import React from 'react';
import { getBaseProps } from '../internal/base-component';
import { InternalRadioGroup } from './internal';
const RadioGroup = React.forwardRef(({ value, items, onChange, name, readOnly = false, direction = 'vertical', ariaLabel, ariaRequired, ariaControls, ariaLabelledby, ariaDescribedby, ...props }, ref) => (_jsx(InternalRadioGroup, { ...getBaseProps(props), ref: ref, value: value, items: items, onChange: onChange, name: name, readOnly: readOnly, direction: direction, ariaLabel: ariaLabel, ariaRequired: ariaRequired, ariaControls: ariaControls, ariaLabelledby: ariaLabelledby, ariaDescribedby: ariaDescribedby })));
RadioGroup.displayName = 'RadioGroup';
export default RadioGroup;
