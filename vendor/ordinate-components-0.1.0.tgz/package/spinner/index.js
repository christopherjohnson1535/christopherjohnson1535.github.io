// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalSpinner } from './internal';
export default function Spinner({ size = 'normal', variant = 'normal', ...props }) {
    return _jsx(InternalSpinner, { ...getBaseProps(props), size: size, variant: variant });
}
