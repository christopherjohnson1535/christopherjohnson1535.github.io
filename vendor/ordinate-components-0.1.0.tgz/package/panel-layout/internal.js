import { jsx as _jsx } from "react/jsx-runtime";
// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React, { useId, useImperativeHandle, useRef } from 'react';
import clsx from 'clsx';
import { useContainerWidth } from '../internal/hooks/use-container-width';
import { useInternalI18n } from '../internal/i18n/context';
import { ResizeHandle } from './resize-handle';
import { usePanelSize } from './use-panel-size';
import styles from './styles.css.js';
const fallbackPanelSize = 240;
function focusableAttributes(focusable) {
    if (!focusable) {
        return {};
    }
    return {
        tabIndex: 0,
        role: 'region',
        'aria-label': focusable.ariaLabel,
        'aria-labelledby': focusable.ariaLabelledby,
    };
}
export const InternalPanelLayout = React.forwardRef(({ panelContent, mainContent, panelPosition = 'side-start', panelSize, defaultPanelSize = fallbackPanelSize, minPanelSize = 0, maxPanelSize, resizable = false, display = 'all', panelFocusable, mainFocusable, i18nStrings, onPanelResize, ...rest }, ref) => {
    const i18n = useInternalI18n('panel-layout');
    const rootRef = useRef(null);
    const handleRef = useRef(null);
    const panelId = useId();
    useImperativeHandle(ref, () => ({ focusResizeHandle: () => handleRef.current?.focus() }));
    const containerWidth = useContainerWidth(rootRef);
    const size = usePanelSize({
        panelSize,
        defaultPanelSize,
        minPanelSize,
        maxPanelSize,
        containerWidth,
        onPanelResize,
    });
    const showPanel = display !== 'main-only';
    const showMain = display !== 'panel-only';
    const showSeparator = showPanel && showMain;
    const panel = showPanel && (_jsx("div", { id: panelId, className: styles.panel, ...focusableAttributes(panelFocusable), children: panelContent }, "panel"));
    const separator = showSeparator &&
        (resizable ? (_jsx(ResizeHandle, { handleRef: handleRef, panelId: panelId, panelPosition: panelPosition, panelSize: size, ariaLabel: i18n('resizeHandleAriaLabel', i18nStrings?.resizeHandleAriaLabel) }, "separator")) : (_jsx("div", { className: styles.divider }, "separator")));
    const main = showMain && (_jsx("div", { className: styles.main, ...focusableAttributes(mainFocusable), children: mainContent }, "main"));
    return (_jsx("div", { ...rest, ref: rootRef, className: clsx(styles.root, styles[`display-${display}`]), style: { '--panel-size': `${size.size}px` }, children: panelPosition === 'side-start' ? [panel, separator, main] : [main, separator, panel] }));
});
