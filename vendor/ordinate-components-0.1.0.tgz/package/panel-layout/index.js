// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import React from 'react';
import { getBaseProps } from '../internal/base-component';
import { InternalPanelLayout } from './internal';
const PanelLayout = React.forwardRef(({ panelContent, mainContent, panelPosition = 'side-start', panelSize, defaultPanelSize, minPanelSize, maxPanelSize, resizable = false, display = 'all', panelFocusable, mainFocusable, i18nStrings, onPanelResize, ...props }, ref) => (_jsx(InternalPanelLayout, { ...getBaseProps(props), ref: ref, panelContent: panelContent, mainContent: mainContent, panelPosition: panelPosition, panelSize: panelSize, defaultPanelSize: defaultPanelSize, minPanelSize: minPanelSize, maxPanelSize: maxPanelSize, resizable: resizable, display: display, panelFocusable: panelFocusable, mainFocusable: mainFocusable, i18nStrings: i18nStrings, onPanelResize: onPanelResize })));
PanelLayout.displayName = 'PanelLayout';
export default PanelLayout;
