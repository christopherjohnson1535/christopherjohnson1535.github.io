// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { useInternalI18n } from '../internal/i18n/context';
const operatorKeys = {
    '=': 'operatorEqualsText',
    '!=': 'operatorDoesNotEqualText',
    ':': 'operatorContainsText',
    '!:': 'operatorDoesNotContainText',
    '>': 'operatorGreaterText',
    '>=': 'operatorGreaterOrEqualText',
    '<': 'operatorLessText',
    '<=': 'operatorLessOrEqualText',
    '^': 'operatorStartsWithText',
    '!^': 'operatorDoesNotStartWithText',
};
export function usePropertyFilterStrings(strings = {}, props) {
    const i18n = useInternalI18n('property-filter');
    const text = (key) => i18n(key, strings[key]) ?? '';
    const tokenAriaLabel = (token) => strings.tokenAriaLabel?.(token) ??
        i18n('tokenAriaLabel', undefined, {
            hasProperty: token.propertyLabel === undefined ? 'false' : 'true',
            propertyLabel: token.propertyLabel ?? '',
            // The name repeats the visible text, operator symbol included, so voice control users can say
            // what they see. Screen readers announce the symbols themselves.
            operator: token.operator,
            showOperator: token.propertyLabel !== undefined || token.operator !== ':' ? 'true' : 'false',
            value: token.value,
        }) ??
        '';
    return {
        filteringAriaLabel: i18n('filteringAriaLabel', props.filteringAriaLabel) ?? '',
        filteringPlaceholder: i18n('filteringPlaceholder', props.filteringPlaceholder) ?? '',
        addConditionPlaceholder: text('addConditionPlaceholder'),
        queryStartText: text('queryStartText'),
        operatorName: operator => text(operatorKeys[operator]),
        operationText: operation => text(operation === 'and' ? 'operationAndText' : 'operationOrText'),
        tokenOperatorAriaLabel: text('tokenOperatorAriaLabel'),
        groupPropertiesText: text('groupPropertiesText'),
        groupValuesText: text('groupValuesText'),
        operatorsText: text('operatorsText'),
        groupValuesLabel: property => property.groupValuesLabel ??
            strings.groupValuesLabel?.(property) ??
            i18n('groupValuesLabel', undefined, { propertyLabel: property.propertyLabel }) ??
            '',
        enteredTextLabel: value => strings.enteredTextLabel?.(value) ?? i18n('enteredTextLabel', undefined, { value }) ?? '',
        clearFiltersText: text('clearFiltersText'),
        editTokenHeader: text('editTokenHeader'),
        propertyText: text('propertyText'),
        operatorText: text('operatorText'),
        valueText: text('valueText'),
        allPropertiesLabel: text('allPropertiesLabel'),
        applyActionText: text('applyActionText'),
        cancelActionText: text('cancelActionText'),
        dismissAriaLabel: text('dismissAriaLabel'),
        tokenAriaLabel,
        removeTokenButtonAriaLabel: token => strings.removeTokenButtonAriaLabel?.(token) ??
            i18n('removeTokenButtonAriaLabel', undefined, { token: tokenAriaLabel(token) }) ??
            '',
        tokenLimitShowMore: count => i18n('tokenLimitShowMore', strings.tokenLimitShowMore, { count }) ?? '',
        tokenLimitShowFewer: text('tokenLimitShowFewer'),
        errorIconAriaLabel: text('errorIconAriaLabel'),
    };
}
