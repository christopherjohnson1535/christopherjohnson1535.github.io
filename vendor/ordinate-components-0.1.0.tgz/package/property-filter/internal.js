import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React, { useEffect, useId, useImperativeHandle, useRef, useState } from 'react';
import clsx from 'clsx';
import { InternalButton } from '../button/internal';
import { fireNonCancelableEvent } from '../internal/events';
import { InternalLiveRegion } from '../live-region/internal';
import { FilteringInput } from './filtering-input';
import { usePropertyFilterStrings } from './i18n';
import { getSuggestions } from './suggestions';
import { FilterToken } from './token';
import { createToken, parseText } from './utils';
import styles from './styles.css.js';
export const InternalPropertyFilter = React.forwardRef(({ query, onChange, filteringProperties, filteringOptions = [], filteringPlaceholder, filteringAriaLabel, countText, disableFreeTextFiltering = false, hideOperations = false, tokenLimit, disabled = false, expandToViewport = false, asyncProperties = false, onLoadItems, filteringStatusType = 'finished', filteringLoadingText, filteringFinishedText, filteringErrorText, filteringRecoveryText, filteringEmpty, customControl, customFilterActions, i18nStrings, ...rest }, ref) => {
    const strings = usePropertyFilterStrings(i18nStrings, { filteringAriaLabel, filteringPlaceholder });
    const inputRef = useRef(null);
    useImperativeHandle(ref, () => ({ focus: () => inputRef.current?.focus() }));
    const tokensId = useId();
    const [text, setText] = useState('');
    const [showAllTokens, setShowAllTokens] = useState(false);
    const tokenRefs = useRef([]);
    const tokensRef = useRef(null);
    const pendingFocus = useRef(null);
    const { tokens, operation } = query;
    const hiddenCount = tokenLimit !== undefined && tokenLimit >= 0 ? Math.max(tokens.length - tokenLimit, 0) : 0;
    const visibleTokens = hiddenCount > 0 && !showAllTokens ? tokens.slice(0, tokenLimit) : tokens;
    // Keeps focus near a removed filter: on the next filter's remove button, or on the input when none is left.
    useEffect(() => {
        const index = pendingFocus.current;
        if (index === null) {
            return;
        }
        pendingFocus.current = null;
        if (visibleTokens.length === 0) {
            inputRef.current?.focus();
        }
        else {
            tokenRefs.current[Math.min(index, visibleTokens.length - 1)]?.focus();
        }
    });
    const status = {
        statusType: filteringStatusType,
        loadingText: filteringLoadingText,
        finishedText: filteringFinishedText,
        errorText: filteringErrorText,
        recoveryText: filteringRecoveryText,
        errorIconAriaLabel: strings.errorIconAriaLabel,
        empty: filteringEmpty,
    };
    const loadItems = (detail) => fireNonCancelableEvent(onLoadItems, detail);
    const loadItemsForText = (filteringText, page) => {
        const parsed = parseText(filteringText, filteringProperties);
        if (parsed.step === 'property') {
            loadItems({
                filteringProperty: parsed.property,
                filteringOperator: parsed.operator,
                filteringText: parsed.value,
                ...page,
            });
        }
        else if (asyncProperties) {
            loadItems({ filteringText, ...page });
        }
    };
    const settings = {
        properties: filteringProperties,
        options: filteringOptions,
        strings,
        status,
        asyncProperties,
        disableFreeTextFiltering,
        disabled,
        expandToViewport,
        onLoadItems: loadItems,
    };
    const parsed = parseText(text, filteringProperties);
    const suggestions = getSuggestions(parsed, filteringProperties, filteringOptions, strings);
    const typedToken = createToken(text, parsed, disableFreeTextFiltering);
    const changeQuery = (nextTokens, nextOperation = operation) => fireNonCancelableEvent(onChange, { tokens: nextTokens, operation: nextOperation });
    const changeText = (next) => {
        setText(next);
        loadItemsForText(next, { firstPage: true, samePage: false });
    };
    const addToken = (token) => {
        changeQuery([...tokens, token]);
        setText('');
    };
    const removeToken = (index) => {
        // Only take focus back if it was on the filters, so a pointer user's focus is left where it was.
        if (tokensRef.current?.contains(document.activeElement)) {
            pendingFocus.current = index;
        }
        changeQuery(tokens.filter((_, position) => position !== index));
    };
    const clearFilters = () => {
        changeQuery([]);
        inputRef.current?.focus();
    };
    const showCount = Boolean(countText) && tokens.length > 0;
    const hasTokens = tokens.length > 0;
    // The filters read as one query line: "where status = running and image ^ web", then the input for the
    // next condition and the result count, all on the same ruled line.
    return (_jsxs("div", { ...rest, className: clsx(styles.root, disabled && styles.disabled), children: [customControl && _jsx("div", { className: styles['custom-control'], children: customControl }), _jsxs("div", { ref: tokensRef, className: styles.query, children: [hasTokens && (_jsxs(_Fragment, { children: [_jsx("span", { className: styles['query-word'], children: strings.queryStartText }), _jsx("ul", { id: tokensId, className: styles['token-list'], children: visibleTokens.map((token, index) => (_jsx(FilterToken
                                // Filters are identified by position: editing one must keep its popover trigger in place for focus.
                                , { ref: element => {
                                        tokenRefs.current[index] = element;
                                    }, token: token, settings: settings, operation: index > 0 ? operation : undefined, operationChangeable: !hideOperations, onOperationChange: next => changeQuery(tokens, next), onChange: next => changeQuery(tokens.map((entry, position) => (position === index ? next : entry))), onRemove: () => removeToken(index) }, index))) }), hiddenCount > 0 && (_jsx(InternalButton, { className: styles['token-toggle'], variant: "link", formAction: "none", ariaExpanded: showAllTokens, ariaControls: tokensId, onClick: () => setShowAllTokens(current => !current), children: showAllTokens ? strings.tokenLimitShowFewer : strings.tokenLimitShowMore(hiddenCount) }))] })), _jsx("div", { className: styles.search, children: _jsx(FilteringInput, { ref: inputRef, type: hasTokens ? 'text' : 'search', value: text, onChange: changeText, options: suggestions.options, enteredTextLabel: typedToken ? strings.enteredTextLabel(text) : undefined, onChoose: option => {
                                const action = suggestions.actions.get(option);
                                if (action?.type === 'text') {
                                    changeText(action.text);
                                    return true;
                                }
                                if (action?.type === 'token') {
                                    addToken(action.token);
                                }
                                return false;
                            }, onSubmit: () => typedToken && addToken(typedToken), onLoadItems: page => loadItemsForText(text, page), status: status, placeholder: hasTokens ? strings.addConditionPlaceholder : strings.filteringPlaceholder, ariaLabel: strings.filteringAriaLabel, disabled: disabled, expandToViewport: expandToViewport }) }), _jsx(InternalLiveRegion, { tagName: "span", hidden: !showCount, children: _jsx("span", { className: styles.count, children: showCount ? countText : '' }) })] }), hasTokens && (_jsx("div", { className: styles.actions, children: customFilterActions ?? (_jsx(InternalButton, { className: styles['clear-button'], formAction: "none", disabled: disabled, onClick: clearFilters, children: strings.clearFiltersText })) }))] }));
});
