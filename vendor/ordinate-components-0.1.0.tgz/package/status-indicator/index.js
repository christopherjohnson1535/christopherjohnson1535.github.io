// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalStatusIndicator } from './internal';
import { resolveColorOverride, resolveState } from './legacy';
export default function StatusIndicator({ state, type, children, iconAriaLabel, tone, colorOverride, wrapText = true, ...props }) {
    return (_jsx(InternalStatusIndicator, { ...getBaseProps(props), state: resolveState('StatusIndicator', state ?? type) ?? 'complete', iconAriaLabel: iconAriaLabel, tone: tone ?? resolveColorOverride(colorOverride), wrapText: wrapText, children: children }));
}
