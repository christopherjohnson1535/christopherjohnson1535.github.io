// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalStatusIndicator } from './internal';
export default function StatusIndicator({ type = 'success', children, iconAriaLabel, colorOverride, wrapText = true, ...props }) {
    return (_jsx(InternalStatusIndicator, { ...getBaseProps(props), type: type, iconAriaLabel: iconAriaLabel, colorOverride: colorOverride, wrapText: wrapText, children: children }));
}
