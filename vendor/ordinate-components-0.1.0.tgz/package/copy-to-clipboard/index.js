// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalCopyToClipboard } from './internal';
export default function CopyToClipboard({ textToCopy, variant = 'button', copyButtonText, copyButtonAriaLabel, copySuccessText, copyErrorText, textToDisplay, popoverRenderWithPortal = false, disabled = false, disabledReason, ...props }) {
    return (_jsx(InternalCopyToClipboard, { ...getBaseProps(props), textToCopy: textToCopy, variant: variant, copyButtonText: copyButtonText, copyButtonAriaLabel: copyButtonAriaLabel, copySuccessText: copySuccessText, copyErrorText: copyErrorText, textToDisplay: textToDisplay, popoverRenderWithPortal: popoverRenderWithPortal, disabled: disabled, disabledReason: disabledReason }));
}
