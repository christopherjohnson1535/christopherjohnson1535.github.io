import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { useRef } from 'react';
import clsx from 'clsx';
import { InternalButton } from '../button/internal';
import { InternalIcon } from '../icon/internal';
import { FeedbackPanel, useFeedback } from '../internal/components/feedback-panel';
import { useInternalI18n } from '../internal/i18n/context';
import { InternalTooltip } from '../tooltip/internal';
import styles from './styles.css.js';
// Resolves once the text is on the clipboard; rejects when the browser has no clipboard API or refuses.
function writeToClipboard(text) {
    try {
        const clipboard = typeof navigator === 'undefined' ? undefined : navigator.clipboard;
        if (!clipboard?.writeText) {
            return Promise.reject(new Error('The clipboard is not available.'));
        }
        return clipboard.writeText(text);
    }
    catch (error) {
        return Promise.reject(error);
    }
}
export function InternalCopyToClipboard({ textToCopy, variant = 'button', copyButtonText, copyButtonAriaLabel, copySuccessText, copyErrorText, textToDisplay, popoverRenderWithPortal = false, disabled = false, disabledReason, ...rest }) {
    const i18n = useInternalI18n('copy-to-clipboard');
    const triggerRef = useRef(null);
    const { feedback, start, resolve, dismissHandlers } = useFeedback();
    const buttonText = i18n('copyButtonText', copyButtonText);
    const iconLabel = i18n('copyButtonAriaLabel', copyButtonAriaLabel ?? copyButtonText);
    const showsReason = disabled && Boolean(disabledReason);
    const renderMessage = (succeeded) => (_jsxs("span", { className: styles.feedback, children: [_jsx(InternalIcon, { className: styles['feedback-icon'], name: succeeded ? 'check' : 'status-negative' }), _jsx("span", { children: succeeded ? i18n('copySuccessText', copySuccessText) : i18n('copyErrorText', copyErrorText) })] }));
    const copy = () => {
        const token = start();
        writeToClipboard(textToCopy).then(() => resolve(token, renderMessage(true)), () => resolve(token, renderMessage(false)));
    };
    const button = (_jsx(InternalButton, { className: clsx(styles.button, variant === 'inline' && styles['inline-button']), variant: variant === 'button' ? 'normal' : 'icon', formAction: "none", iconName: "copy", disabled: disabled, focusableWhenDisabled: showsReason, ariaLabel: variant === 'button' ? copyButtonAriaLabel : iconLabel, onClick: copy, children: variant === 'button' ? buttonText : undefined }));
    return (_jsxs("span", { ...rest, className: clsx(styles.root, styles[`variant-${variant}`]), ...dismissHandlers, children: [variant === 'inline' && _jsx("span", { className: styles.text, children: textToDisplay ?? textToCopy }), _jsx("span", { ref: triggerRef, className: styles.trigger, children: showsReason ? _jsx(InternalTooltip, { content: disabledReason, children: button }) : button }), feedback && (_jsx(FeedbackPanel, { trigger: triggerRef, renderWithPortal: popoverRenderWithPortal, children: feedback.content }, feedback.key))] }));
}
