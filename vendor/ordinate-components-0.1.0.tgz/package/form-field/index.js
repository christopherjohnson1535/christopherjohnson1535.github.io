// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalFormField } from './internal';
export default function FormField({ label, info, description, constraintText, characterCountText, errorText, warningText, errorIconAriaLabel, warningIconAriaLabel, controlId, stretch = false, children, secondaryControl, ...props }) {
    return (_jsx(InternalFormField, { ...getBaseProps(props), label: label, info: info, description: description, constraintText: constraintText, characterCountText: characterCountText, errorText: errorText, warningText: warningText, errorIconAriaLabel: errorIconAriaLabel, warningIconAriaLabel: warningIconAriaLabel, controlId: controlId, stretch: stretch, secondaryControl: secondaryControl, children: children }));
}
