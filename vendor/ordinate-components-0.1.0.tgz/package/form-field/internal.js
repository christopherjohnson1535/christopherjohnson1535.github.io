import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { useEffect, useId, useState } from 'react';
import clsx from 'clsx';
import { InternalIcon } from '../icon/internal';
import { FormFieldContext } from '../internal/context/form-field-context';
import { useInternalI18n } from '../internal/i18n/context';
import { warnOnce } from '../internal/logging';
import styles from './styles.css.js';
const characterCountDelay = 1000;
// Screen readers would read the count after every keystroke, so their copy only updates once typing pauses.
function useSettledValue(value, delay) {
    const [settled, setSettled] = useState(value);
    useEffect(() => {
        const timeout = setTimeout(() => setSettled(value), delay);
        return () => clearTimeout(timeout);
    }, [value, delay]);
    return settled;
}
export function InternalFormField({ label, info, description, constraintText, characterCountText, errorText, warningText, errorIconAriaLabel, warningIconAriaLabel, controlId: controlIdProp, stretch = false, children, secondaryControl, ...rest }) {
    const i18n = useInternalI18n('form-field');
    const baseId = useId();
    const controlId = controlIdProp ?? `${baseId}control`;
    const labelId = `${baseId}label`;
    const descriptionId = `${baseId}description`;
    const errorId = `${baseId}error`;
    const warningId = `${baseId}warning`;
    const constraintId = `${baseId}constraint`;
    const characterCountId = `${baseId}character-count`;
    const settledCharacterCount = useSettledValue(characterCountText, characterCountDelay);
    if (errorText && warningText) {
        warnOnce('FormField', '`warningText` is not shown while `errorText` is set.');
    }
    const showWarning = Boolean(warningText) && !errorText;
    const describedBy = [
        errorText && errorId,
        showWarning && warningId,
        description && descriptionId,
        constraintText && constraintId,
        characterCountText && characterCountId,
    ]
        .filter(Boolean)
        .join(' ');
    const sharedContext = {
        ariaLabelledby: label ? labelId : undefined,
        ariaDescribedby: describedBy || undefined,
        invalid: Boolean(errorText),
        warning: showWarning,
    };
    return (_jsxs("div", { ...rest, className: styles.root, children: [(label || info) && (_jsxs("div", { className: styles['label-row'], children: [label && (_jsx("label", { id: labelId, className: styles.label, htmlFor: controlId, children: label })), info && _jsx("span", { className: styles.info, children: info })] })), description && (_jsx("div", { id: descriptionId, className: styles.description, children: description })), _jsxs("div", { className: clsx(styles.controls, stretch && styles.stretch), children: [_jsx("div", { className: styles.control, children: _jsx(FormFieldContext.Provider, { value: { controlId, ...sharedContext }, children: children }) }), secondaryControl && (_jsx("div", { className: styles['secondary-control'], children: _jsx(FormFieldContext.Provider, { value: sharedContext, children: secondaryControl }) }))] }), errorText && (_jsxs("div", { id: errorId, className: styles.error, children: [_jsx(InternalIcon, { className: styles['message-icon'], name: "status-negative", size: "small", ariaLabel: i18n('errorIconAriaLabel', errorIconAriaLabel) }), _jsx("span", { children: errorText })] })), showWarning && (_jsxs("div", { id: warningId, className: styles.warning, children: [_jsx(InternalIcon, { className: styles['message-icon'], name: "status-warning", size: "small", ariaLabel: i18n('warningIconAriaLabel', warningIconAriaLabel) }), _jsx("span", { children: warningText })] })), (constraintText || characterCountText) && (_jsxs("div", { className: styles.hints, children: [constraintText && (_jsx("span", { id: constraintId, className: styles.constraint, children: constraintText })), characterCountText && (_jsxs(_Fragment, { children: [_jsx("span", { className: styles['character-count'], "aria-hidden": "true", children: characterCountText }), _jsx("span", { id: characterCountId, className: styles['screenreader-only'], children: settledCharacterCount })] }))] }))] }));
}
