import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { useCallback, useEffect, useId, useState } from 'react';
import clsx from 'clsx';
import { InternalIcon } from '../icon/internal';
import { DimensionLine } from '../internal/components/dimension-line';
import { FormFieldContext } from '../internal/context/form-field-context';
import { useInternalI18n } from '../internal/i18n/context';
import { warnOnce } from '../internal/logging';
import styles from './styles.css.js';
const characterCountDelay = 1000;
// Screen readers would read the count after every keystroke, so their copy only updates once typing pauses.
function useSettledValue(value, delay) {
    const [settled, setSettled] = useState(value);
    useEffect(() => {
        const timeout = setTimeout(() => setSettled(value), delay);
        return () => clearTimeout(timeout);
    }, [value, delay]);
    return settled;
}
export function InternalFormField({ label, info, description, constraintText, characterCountText, errorText, warningText, errorIconAriaLabel, warningIconAriaLabel, controlId: controlIdProp, stretch = false, children, secondaryControl, layout = 'stacked', ...rest }) {
    const i18n = useInternalI18n('form-field');
    const baseId = useId();
    const controlId = controlIdProp ?? `${baseId}control`;
    const labelId = `${baseId}label`;
    const descriptionId = `${baseId}description`;
    const errorId = `${baseId}error`;
    const warningId = `${baseId}warning`;
    const constraintId = `${baseId}constraint`;
    const characterCountId = `${baseId}character-count`;
    // Checkboxes, radio buttons and toggles keep their own IDs and report them here. One of them takes the
    // label like any control; several of them are labeled together as a group, each by its own label.
    const [choiceControlIds, setChoiceControlIds] = useState([]);
    const registerChoiceControl = useCallback((id) => {
        setChoiceControlIds(ids => [...ids, id]);
        return () => setChoiceControlIds(ids => ids.filter(other => other !== id));
    }, []);
    const isGroup = choiceControlIds.length > 1;
    const labelFor = isGroup ? undefined : (choiceControlIds[0] ?? controlId);
    const settledCharacterCount = useSettledValue(characterCountText, characterCountDelay);
    if (errorText && warningText) {
        warnOnce('FormField', '`warningText` is not shown while `errorText` is set.');
    }
    const showWarning = Boolean(warningText) && !errorText;
    const describedBy = [
        errorText && errorId,
        showWarning && warningId,
        description && descriptionId,
        constraintText && constraintId,
        characterCountText && characterCountId,
    ]
        .filter(Boolean)
        .join(' ');
    const sharedContext = {
        ariaLabelledby: label ? labelId : undefined,
        ariaDescribedby: describedBy || undefined,
        invalid: Boolean(errorText),
        warning: showWarning,
    };
    return (_jsx("div", { ...rest, className: clsx(styles.root, layout === 'margin' && styles['layout-margin']), children: _jsxs("div", { className: styles.frame, children: [_jsxs("div", { className: styles.margin, children: [(label || info) && (_jsxs("div", { className: styles['label-row'], children: [label && (_jsx("label", { id: labelId, className: styles.label, htmlFor: labelFor, children: label })), info && _jsx("span", { className: styles.info, children: info })] })), description && (_jsx("div", { id: descriptionId, className: styles.description, children: description }))] }), _jsxs("div", { className: styles.body, children: [_jsxs("div", { className: clsx(styles.controls, stretch && styles.stretch), children: [_jsx("div", { className: styles.control, role: isGroup ? 'group' : undefined, "aria-labelledby": isGroup ? sharedContext.ariaLabelledby : undefined, "aria-describedby": isGroup ? sharedContext.ariaDescribedby : undefined, children: _jsx(FormFieldContext.Provider, { value: isGroup
                                            ? { invalid: sharedContext.invalid, warning: sharedContext.warning, registerChoiceControl }
                                            : { controlId, ...sharedContext, registerChoiceControl }, children: children }) }), secondaryControl && (_jsx("div", { className: styles['secondary-control'], children: _jsx(FormFieldContext.Provider, { value: sharedContext, children: secondaryControl }) }))] }), characterCountText && (_jsxs(_Fragment, { children: [_jsx("div", { className: styles['character-count'], "aria-hidden": "true", children: _jsx(DimensionLine, { label: characterCountText }) }), _jsx("span", { id: characterCountId, className: styles['screenreader-only'], children: settledCharacterCount })] })), errorText && (_jsxs("div", { id: errorId, className: styles.error, children: [_jsx(InternalIcon, { name: "fault", size: "small", ariaLabel: i18n('errorIconAriaLabel', errorIconAriaLabel) }), _jsx("span", { children: errorText })] })), showWarning && (_jsxs("div", { id: warningId, className: styles.warning, children: [_jsx(InternalIcon, { name: "caution", size: "small", ariaLabel: i18n('warningIconAriaLabel', warningIconAriaLabel) }), _jsx("span", { children: warningText })] })), constraintText && (_jsx("div", { id: constraintId, className: styles.constraint, children: constraintText }))] })] }) }));
}
