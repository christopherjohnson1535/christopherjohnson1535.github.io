// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalTableBodyCell } from './internal';
export default function TableBodyCell({ children, isRowHeader = false, verticalAlign = 'middle', colSpan, rowTag, selectionType, selected = false, selectionDisabled = false, selectionName, selectionAriaLabel, onSelectionChange, ...props }) {
    return (_jsx(InternalTableBodyCell, { ...getBaseProps(props), isRowHeader: isRowHeader, verticalAlign: verticalAlign, colSpan: colSpan, rowTag: rowTag, selectionType: selectionType, selected: selected, selectionDisabled: selectionDisabled, selectionName: selectionName, selectionAriaLabel: selectionAriaLabel, onSelectionChange: onSelectionChange, children: children }));
}
