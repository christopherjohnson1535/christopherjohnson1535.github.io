// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalCallToAction } from './internal';
export default function CallToAction({ heading, description, actions, children, tone = 'inverted', headingLevel = 2, ...props }) {
    return (_jsx(InternalCallToAction, { ...getBaseProps(props), heading: heading, description: description, actions: actions, tone: tone, headingLevel: headingLevel, children: children }));
}
