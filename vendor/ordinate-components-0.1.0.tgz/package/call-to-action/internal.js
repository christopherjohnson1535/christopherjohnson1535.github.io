import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import clsx from 'clsx';
import { Band } from '../internal/components/band';
import { Heading } from '../internal/components/heading';
import styles from './styles.css.js';
export function InternalCallToAction({ heading, description, actions, children, tone = 'inverted', headingLevel, ...rest }) {
    const hasText = Boolean(heading || description);
    const hasActions = Boolean(actions || children);
    return (_jsx(Band, { ...rest, tag: "section", tone: tone, spacing: "small", className: clsx(styles.root, styles[`tone-${tone}`]), innerClassName: styles.frame, children: _jsxs("div", { className: styles.layout, children: [hasText && (_jsxs("div", { className: styles.text, children: [heading && (_jsx(Heading, { level: headingLevel, defaultLevel: 2, className: styles.heading, children: heading })), description && _jsx("div", { className: styles.description, children: description })] })), hasActions && (_jsxs("div", { className: styles['action-area'], children: [children && _jsx("div", { className: styles.content, children: children }), actions && _jsx("div", { className: styles.actions, children: actions })] }))] }) }));
}
