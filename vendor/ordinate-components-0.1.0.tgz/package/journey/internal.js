import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React, { useEffect, useId, useRef } from 'react';
import { InternalButton } from '../button/internal';
import { InternalIcon } from '../icon/internal';
import { QuestionContext } from '../internal/context/question-context';
import { fireNonCancelableEvent } from '../internal/events';
import { getHeadingTag } from '../internal/heading-level';
import { useControllable } from '../internal/hooks/use-controllable';
import { useInternalI18n } from '../internal/i18n/context';
import { warnOnce } from '../internal/logging';
import { ProgressRuler } from './progress-ruler';
import styles from './styles.css.js';
function clampIndex(index, count) {
    return Math.min(Math.max(index, 0), Math.max(count - 1, 0));
}
/**
 * Moves focus to the question whenever the step changes, so keyboard and screen reader users start
 * on the new question instead of on a button that may have moved or gone.
 */
function useFocusOnStepChange(activeStepIndex) {
    const headingRef = useRef(null);
    const shownIndex = useRef(activeStepIndex);
    useEffect(() => {
        if (shownIndex.current !== activeStepIndex) {
            shownIndex.current = activeStepIndex;
            headingRef.current?.focus();
        }
    }, [activeStepIndex]);
    return headingRef;
}
export function InternalJourney({ steps, activeStepIndex: controlledActiveStepIndex, onNavigate, onFinish, isLoading = false, finishButtonText, headingLevel, i18nStrings, ...rest }) {
    const i18n = useInternalI18n('journey');
    const [currentIndex, setCurrentIndex] = useControllable(controlledActiveStepIndex, 0);
    const activeStepIndex = clampIndex(currentIndex, steps.length);
    const headingRef = useFocusOnStepChange(activeStepIndex);
    const baseId = useId();
    if (steps.length === 0) {
        warnOnce('Journey', 'The journey needs at least one step.');
        return null;
    }
    const step = steps[activeStepIndex];
    const isLastStep = activeStepIndex === steps.length - 1;
    const questionId = `${baseId}question`;
    const counterId = `${baseId}counter`;
    const descriptionId = step.description ? `${baseId}description` : undefined;
    const navigate = (requestedStepIndex, reason) => {
        setCurrentIndex(requestedStepIndex);
        fireNonCancelableEvent(onNavigate, { requestedStepIndex, reason });
    };
    // The journey is a form so that Enter in a text field continues, as visitors expect on a website.
    const handleSubmit = (event) => {
        event.preventDefault();
        if (isLoading) {
            return;
        }
        if (isLastStep) {
            fireNonCancelableEvent(onFinish, null);
        }
        else {
            navigate(activeStepIndex + 1, 'next');
        }
    };
    const counterText = i18n('questionCounterText', i18nStrings?.questionCounterText?.(activeStepIndex + 1, steps.length), { questionNumber: activeStepIndex + 1, questionsCount: steps.length });
    return (_jsxs("form", { ...rest, className: styles.root, noValidate: true, onSubmit: handleSubmit, children: [_jsxs("div", { className: styles.progress, children: [_jsx(ProgressRuler, { count: steps.length, activeIndex: activeStepIndex }), _jsxs("p", { id: counterId, className: styles.counter, children: [_jsx("span", { className: styles['counter-text'], children: counterText }), step.isOptional && _jsx("span", { className: styles.optional, children: i18n('optional', i18nStrings?.optional) })] })] }), _jsxs("div", { className: styles.header, children: [React.createElement(getHeadingTag('Journey', headingLevel, 2), {
                        ref: headingRef,
                        id: questionId,
                        className: styles.question,
                        tabIndex: -1,
                        'aria-describedby': counterId,
                    }, step.question), step.description && (_jsx("div", { id: descriptionId, className: styles.description, children: step.description }))] }), _jsx(QuestionContext.Provider, { value: { questionId, descriptionId }, children: _jsx("div", { className: styles.content, children: step.content }, step.id) }), _jsx("div", { role: "alert", className: styles['error-region'], children: step.errorText && (_jsxs("div", { className: styles.error, children: [_jsx(InternalIcon, { className: styles['error-icon'], name: "status-negative", variant: "error", ariaLabel: i18n('errorIconAriaLabel', i18nStrings?.errorIconAriaLabel) }), _jsx("div", { className: styles['error-text'], children: step.errorText })] })) }), _jsxs("div", { className: styles.actions, children: [activeStepIndex > 0 && (_jsx(InternalButton, { className: styles['back-button'], variant: "link", iconName: "angle-left", formAction: "none", disabled: isLoading, onClick: () => navigate(activeStepIndex - 1, 'back'), children: i18n('backButton', i18nStrings?.backButton) })), _jsx(InternalButton, { className: styles['continue-button'], variant: "primary", formAction: "submit", loading: isLoading, loadingText: i18n('loadingText', i18nStrings?.loadingText), children: isLastStep
                            ? (finishButtonText ?? i18n('finishButton', i18nStrings?.finishButton))
                            : i18n('continueButton', i18nStrings?.continueButton) })] })] }));
}
