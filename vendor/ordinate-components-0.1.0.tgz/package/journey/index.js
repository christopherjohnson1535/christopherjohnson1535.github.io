// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalJourney } from './internal';
export default function Journey({ steps, activeStepIndex, onNavigate, onFinish, isLoading = false, finishButtonText, headingLevel = 2, i18nStrings, ...props }) {
    return (_jsx(InternalJourney, { ...getBaseProps(props), steps: steps, activeStepIndex: activeStepIndex, onNavigate: onNavigate, onFinish: onFinish, isLoading: isLoading, finishButtonText: finishButtonText, headingLevel: headingLevel, i18nStrings: i18nStrings }));
}
