// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalProgressBar } from './internal';
export default function ProgressBar({ value = 0, label, description, additionalInfo, status = 'in-progress', resultText, resultButtonText, onResultButtonClick, variant = 'standalone', ariaLabel, ariaLabelledby, ariaDescribedby, ...props }) {
    return (_jsx(InternalProgressBar, { ...getBaseProps(props), value: value, label: label, description: description, additionalInfo: additionalInfo, status: status, resultText: resultText, resultButtonText: resultButtonText, onResultButtonClick: onResultButtonClick, variant: variant, ariaLabel: ariaLabel, ariaLabelledby: ariaLabelledby, ariaDescribedby: ariaDescribedby }));
}
