// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { warnOnce } from '../internal/logging';
import { InternalProgressBar } from './internal';
const legacyStatuses = {
    'in-progress': 'underway',
    success: 'complete',
    error: 'fault',
};
function resolveStatus(status) {
    if (Object.prototype.hasOwnProperty.call(legacyStatuses, status)) {
        const current = legacyStatuses[status];
        warnOnce('ProgressBar', `The status "${status}" is now called "${current}". The old name stops working in the next major version.`);
        return current;
    }
    return status;
}
export default function ProgressBar({ value = 0, label, description, additionalInfo, status = 'underway', resultText, resultButtonText, onResultButtonClick, variant = 'standalone', ariaLabel, ariaLabelledby, ariaDescribedby, ...props }) {
    return (_jsx(InternalProgressBar, { ...getBaseProps(props), value: value, label: label, description: description, additionalInfo: additionalInfo, status: resolveStatus(status), resultText: resultText, resultButtonText: resultButtonText, onResultButtonClick: onResultButtonClick, variant: variant, ariaLabel: ariaLabel, ariaLabelledby: ariaLabelledby, ariaDescribedby: ariaDescribedby }));
}
