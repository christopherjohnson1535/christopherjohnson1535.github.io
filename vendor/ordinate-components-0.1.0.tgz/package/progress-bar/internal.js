import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React, { useId } from 'react';
import clsx from 'clsx';
import { InternalButton } from '../button/internal';
import { fireNonCancelableEvent } from '../internal/events';
import { InternalLiveRegion } from '../live-region/internal';
import { InternalStatusIndicator } from '../status-indicator/internal';
import styles from './styles.css.js';
function clamp(value) {
    return Number.isFinite(value) ? Math.min(100, Math.max(0, value)) : 0;
}
export function InternalProgressBar({ value = 0, label, description, additionalInfo, status = 'in-progress', resultText, resultButtonText, onResultButtonClick, variant = 'standalone', ariaLabel, ariaLabelledby, ariaDescribedby, className, ...rest }) {
    const id = useId();
    const labelId = `${id}-label`;
    const descriptionId = `${id}-description`;
    const additionalInfoId = `${id}-additional-info`;
    const percent = Math.round(clamp(value));
    // A flash announces its own content when it changes, so a second live region would read the result twice.
    const ResultRegion = variant === 'flash' ? React.Fragment : InternalLiveRegion;
    const describedBy = [description && descriptionId, additionalInfo && additionalInfoId, ariaDescribedby]
        .filter(Boolean)
        .join(' ');
    return (_jsxs("div", { ...rest, className: clsx(styles.root, styles[`variant-${variant}`], className), children: [label && (_jsx("div", { id: labelId, className: styles.label, children: label })), description && (_jsx("div", { id: descriptionId, className: styles.description, children: description })), status === 'in-progress' ? (_jsxs("div", { className: styles.progress, children: [_jsx("div", { className: styles.track, role: "progressbar", "aria-valuemin": 0, "aria-valuemax": 100, "aria-valuenow": percent, "aria-label": ariaLabel, "aria-labelledby": ariaLabelledby ?? (label && !ariaLabel ? labelId : undefined), "aria-describedby": describedBy || undefined, children: _jsx("div", { className: styles.fill, style: { inlineSize: `${percent}%` } }) }), _jsxs("span", { className: styles.percentage, "aria-hidden": "true", children: [percent, "%"] })] })) : (_jsx(ResultRegion, { children: _jsxs("div", { className: styles.result, children: [_jsx(InternalStatusIndicator, { type: status, children: _jsx("span", { className: styles['result-text'], children: resultText }) }), resultButtonText && (_jsx(InternalButton, { className: styles['result-button'], formAction: "none", onClick: () => fireNonCancelableEvent(onResultButtonClick, null), children: resultButtonText }))] }) })), additionalInfo && (_jsx("div", { id: additionalInfoId, className: styles['additional-info'], children: additionalInfo }))] }));
}
