// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import React from 'react';
import { getBaseProps } from '../internal/base-component';
import { InternalToggle } from './internal';
const Toggle = React.forwardRef(({ checked, onChange, children, description, disabled = false, readOnly = false, name, ariaLabel, ariaControls, onFocus, onBlur, controlId, ariaLabelledby, ariaDescribedby, ...props }, ref) => (_jsx(InternalToggle, { ...getBaseProps(props), ref: ref, checked: checked, onChange: onChange, description: description, disabled: disabled, readOnly: readOnly, name: name, ariaLabel: ariaLabel, ariaControls: ariaControls, onFocus: onFocus, onBlur: onBlur, controlId: controlId, ariaLabelledby: ariaLabelledby, ariaDescribedby: ariaDescribedby, children: children })));
Toggle.displayName = 'Toggle';
export default Toggle;
