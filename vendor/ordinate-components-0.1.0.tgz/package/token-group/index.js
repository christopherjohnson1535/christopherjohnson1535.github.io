// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalTokenGroup } from './internal';
export default function TokenGroup({ items, onDismiss, alignment = 'horizontal', limit, readOnly = false, ariaLabel, i18nStrings, ...props }) {
    return (_jsx(InternalTokenGroup, { ...getBaseProps(props), items: items, onDismiss: onDismiss, alignment: alignment, limit: limit, readOnly: readOnly, ariaLabel: ariaLabel, i18nStrings: i18nStrings }));
}
