// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalTableRow } from './internal';
export default function TableRow({ children, selected = false, ariaRowindex, onClick, ...props }) {
    return (_jsx(InternalTableRow, { ...getBaseProps(props), selected: selected, ariaRowindex: ariaRowindex, onClick: onClick, children: children }));
}
