// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalControlGroup } from './internal';
export default function ControlGroup({ children, ariaLabel, ariaLabelledby, ariaDescribedby, ...props }) {
    return (_jsx(InternalControlGroup, { ...getBaseProps(props), ariaLabel: ariaLabel, ariaLabelledby: ariaLabelledby, ariaDescribedby: ariaDescribedby, children: children }));
}
