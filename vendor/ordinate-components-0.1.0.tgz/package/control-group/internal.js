import { jsx as _jsx } from "react/jsx-runtime";
// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { useContext } from 'react';
import { FormFieldContext } from '../internal/context/form-field-context';
import { childKey, flattenChildren } from '../internal/flatten-children';
import styles from './styles.css.js';
export function InternalControlGroup({ children, ariaLabel, ariaLabelledby, ariaDescribedby, ...rest }) {
    const field = useContext(FormFieldContext);
    // Only one control can own the field's control ID, or the label would point at several elements.
    const sharedField = { ...field, controlId: undefined };
    const items = flattenChildren(children);
    return (_jsx("div", { ...rest, role: "group", className: styles.root, "aria-label": ariaLabel, "aria-labelledby": ariaLabelledby ?? (ariaLabel ? undefined : field.ariaLabelledby), "aria-describedby": ariaDescribedby, children: items.map((child, index) => (_jsx("div", { className: styles.item, children: _jsx(FormFieldContext.Provider, { value: index === 0 ? field : sharedField, children: child }) }, childKey(child, index)))) }));
}
