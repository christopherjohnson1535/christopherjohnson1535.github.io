// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalFigure } from './internal';
/**
 * A picture with its caption, label and credit, as a `<figure>` and `<figcaption>`.
 */
export default function Figure({ media, caption, label, credit, ...props }) {
    return _jsx(InternalFigure, { ...getBaseProps(props), media: media, caption: caption, label: label, credit: credit });
}
