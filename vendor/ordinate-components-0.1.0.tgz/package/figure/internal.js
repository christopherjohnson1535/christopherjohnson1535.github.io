import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import clsx from 'clsx';
import styles from './styles.css.js';
export function InternalFigure({ media, caption, label, credit, className, ...rest }) {
    const hasCaption = Boolean(caption || label || credit);
    return (_jsxs("figure", { ...rest, className: clsx(styles.root, className), children: [media && _jsx("div", { className: styles.media, children: media }), hasCaption && (_jsxs("figcaption", { className: styles.caption, children: [(label || caption) && (_jsxs("span", { className: styles.line, children: [label && _jsx("span", { className: styles.label, children: label }), label && caption && ' ', caption && _jsx("span", { className: styles.text, children: caption })] })), credit && (_jsxs(_Fragment, { children: [(label || caption) && ' ', _jsx("span", { className: styles.credit, children: credit })] }))] }))] }));
}
