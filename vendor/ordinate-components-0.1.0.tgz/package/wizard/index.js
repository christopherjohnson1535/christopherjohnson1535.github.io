// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalWizard } from './internal';
export default function Wizard({ variant = 'checklist', kind = 'neutral', reference, steps, activeStepIndex, onNavigate, onSubmit, onCancel, isLoadingNextStep = false, allowSkipTo = false, submitButtonText, secondaryActions, aside, i18nStrings, ...props }) {
    return (_jsx(InternalWizard, { ...getBaseProps(props), variant: variant, kind: kind, reference: reference, steps: steps, activeStepIndex: activeStepIndex, onNavigate: onNavigate, onSubmit: onSubmit, onCancel: onCancel, isLoadingNextStep: isLoadingNextStep, allowSkipTo: allowSkipTo, submitButtonText: submitButtonText, secondaryActions: secondaryActions, aside: aside, i18nStrings: i18nStrings }));
}
