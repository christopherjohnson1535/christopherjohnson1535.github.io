import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { useId } from 'react';
import clsx from 'clsx';
import { InternalButton } from '../button/internal';
import { InternalIcon } from '../icon/internal';
import { RevisionCloud } from '../internal/components/revision-cloud';
import styles from './styles.css.js';
function Marker({ index, state }) {
    const checked = state.status === 'visited' && state.revision === null;
    return (_jsx("span", { className: styles['item-marker'], children: checked ? _jsx(InternalIcon, { name: "check", className: styles['item-marker-check'] }) : index + 1 }));
}
/**
 * One item on the checklist sheet. The open item shows its content; the others fold to their
 * title and one line, a summary once checked or the description before, with a button to open them.
 */
export function ChecklistItem({ step, index, state, labels, headerRef, isLoadingNextStep, hasNext, onOpen, onNext, }) {
    const id = useId();
    const titleId = `${id}-title`;
    const errorId = `${id}-error`;
    const { status, revision } = state;
    const isActive = status === 'active';
    const hasError = revision !== null;
    const revisionMark = hasError ? `△${revision}` : undefined;
    const line = status === 'visited' ? (step.summary ?? labels.doneSummary) : step.description;
    return (_jsxs("li", { className: clsx(styles.item, styles[`item-${status}`], step.isOptional && styles['item-optional'], hasError && styles['item-has-error']), "aria-current": isActive ? 'step' : undefined, children: [_jsxs("div", { className: styles['item-margin'], "aria-hidden": "true", children: [_jsx(Marker, { index: index, state: state }), step.isOptional && _jsx("span", { className: styles['item-optional-label'], children: labels.optional })] }), _jsxs("div", { className: styles['item-body'], role: "group", "aria-labelledby": titleId, "aria-describedby": hasError ? errorId : undefined, children: [_jsxs("div", { ref: isActive ? headerRef : undefined, className: clsx(styles['item-header'], isActive && styles['step-header']), children: [_jsxs("h2", { id: titleId, className: styles['item-title'], children: [_jsx("span", { className: styles['screenreader-only'], children: labels.stepNumber }), " ", step.title, step.isOptional && (_jsxs(_Fragment, { children: [' ', _jsxs("span", { className: styles['screenreader-only'], children: ["- ", labels.optional] })] }))] }), isActive && step.info && _jsx("span", { className: styles['item-info'], children: step.info }), !isActive && (_jsx(InternalButton, { className: clsx(styles['item-action'], styles[status === 'visited' ? 'change-button' : 'open-button']), variant: "link", formAction: "none", disabled: isLoadingNextStep, ariaLabel: labels.actionAriaLabel, onClick: onOpen, children: labels.action }))] }), isActive && step.description && _jsx("div", { className: styles['item-description'], children: step.description }), (isActive || line || hasError) && (_jsx(RevisionCloud, { active: hasError, marker: revisionMark, children: isActive ? (_jsx("div", { className: styles.content, children: step.content })) : (line && _jsx("div", { className: styles['item-summary'], children: line })) })), hasError && (_jsxs("div", { id: errorId, className: styles['item-error'], children: [_jsx("span", { className: styles['item-error-mark'], "aria-hidden": "true", children: revisionMark }), _jsxs("span", { className: styles['screenreader-only'], children: [labels.errorIcon, ":"] }), ' ', _jsx("span", { className: styles['item-error-text'], children: step.errorText })] })), isActive && hasNext && (_jsx("div", { className: styles['item-actions'], children: _jsx(InternalButton, { className: styles['next-button'], formAction: "none", loading: isLoadingNextStep, loadingText: labels.loadingNext, onClick: onNext, children: labels.next }) }))] })] }));
}
