// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import React from 'react';
import { getBaseProps } from '../internal/base-component';
import { InternalCodeEditor } from './internal';
const CodeEditor = React.forwardRef(({ value, onChange, onDelayedChange, language, languageLabel, preferences, onPreferencesChange, editorContentHeight, onEditorContentResize, loading = false, readOnly = false, ariaLabel, controlId, ariaLabelledby, ariaDescribedby, invalid, warning, i18nStrings, ...props }, ref) => (_jsx(InternalCodeEditor, { ...getBaseProps(props), ref: ref, value: value, onChange: onChange, onDelayedChange: onDelayedChange, language: language, languageLabel: languageLabel, preferences: preferences, onPreferencesChange: onPreferencesChange, editorContentHeight: editorContentHeight, onEditorContentResize: onEditorContentResize, loading: loading, readOnly: readOnly, ariaLabel: ariaLabel, controlId: controlId, ariaLabelledby: ariaLabelledby, ariaDescribedby: ariaDescribedby, invalid: invalid, warning: warning, i18nStrings: i18nStrings })));
CodeEditor.displayName = 'CodeEditor';
export default CodeEditor;
