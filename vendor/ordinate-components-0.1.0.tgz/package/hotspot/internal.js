import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { useId, useRef } from 'react';
import clsx from 'clsx';
import { Annotation } from '../annotation-context/annotation';
import { useAnnotationContext } from '../internal/context/annotation-context';
import { useInternalI18n } from '../internal/i18n/context';
import styles from './styles.css.js';
// A hotspot shows a marker while any step of the current task points at it. When several
// steps of the task do, the current one wins, then the earliest.
function findOwnStep(context, hotspotId) {
    if (!context?.currentTutorial || context.currentTutorial.completed) {
        return undefined;
    }
    const current = context.steps[context.currentStepIndex];
    if (!current) {
        return undefined;
    }
    if (current.step.hotspotId === hotspotId) {
        return current;
    }
    return context.steps.find(entry => entry.taskIndex === current.taskIndex && entry.step.hotspotId === hotspotId);
}
export function InternalHotspot({ hotspotId, children, side = 'right', direction = 'top', ...rest }) {
    const i18n = useInternalI18n('annotation-context');
    const context = useAnnotationContext();
    const markerRef = useRef(null);
    const annotationId = useId();
    const ownStep = findOwnStep(context, hotspotId);
    const isCurrent = ownStep !== undefined && ownStep.index === context?.currentStepIndex;
    const open = isCurrent && Boolean(context?.annotationOpen);
    const onMarkerClick = () => {
        if (!context || !ownStep) {
            return;
        }
        if (isCurrent) {
            context.setAnnotationOpen(!open);
        }
        else {
            context.goToStep(ownStep.index, 'open');
        }
    };
    const dismiss = () => {
        context?.setAnnotationOpen(false);
        markerRef.current?.focus();
    };
    // The marker is a circled number, as a drawing numbers the places a note refers to. The number is the
    // step's place in its task; the label reads it in words.
    const marker = ownStep && context && (_jsxs("span", { className: styles['marker-slot'], children: [_jsx("button", { ref: markerRef, type: "button", className: clsx(styles.marker, isCurrent && styles['marker-current']), "aria-label": i18n('labelHotspot', context.i18nStrings?.labelHotspot?.(open, ownStep.indexInTask + 1, ownStep.taskStepCount), {
                    open: open ? 'true' : 'false',
                    stepNumber: ownStep.indexInTask + 1,
                    totalStepCount: ownStep.taskStepCount,
                }), "aria-haspopup": "dialog", "aria-expanded": open, "aria-controls": open ? annotationId : undefined, onClick: onMarkerClick, children: ownStep.indexInTask + 1 }), open && (_jsx(Annotation, { id: annotationId, context: context, tutorialStep: ownStep, trigger: markerRef, direction: direction, onDismiss: dismiss }, ownStep.index))] }));
    return (_jsxs("span", { ...rest, className: clsx(styles.root, children !== undefined && styles['with-children']), "data-hotspot-id": hotspotId, children: [side === 'left' && marker, children !== undefined && _jsx("span", { className: styles.content, children: children }), side === 'right' && marker] }));
}
