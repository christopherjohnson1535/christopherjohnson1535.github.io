// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalHotspot } from './internal';
export default function Hotspot({ hotspotId, children, side = 'right', direction = 'top', ...props }) {
    return (_jsx(InternalHotspot, { ...getBaseProps(props), hotspotId: hotspotId, side: side, direction: direction, children: children }));
}
