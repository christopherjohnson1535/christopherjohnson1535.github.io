// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalTextContent } from './internal';
export default function TextContent({ children, ...props }) {
    return _jsx(InternalTextContent, { ...getBaseProps(props), children: children });
}
