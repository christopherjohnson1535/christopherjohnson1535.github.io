import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import clsx from 'clsx';
import { fireNonCancelableEvent } from '../internal/events';
import { useInternalI18n } from '../internal/i18n/context';
import { TriggerButton } from './trigger-button';
import styles from './styles.css.js';
export function InternalAppLayoutToolbar({ breadcrumbs, navigationOpen = false, navigationHide = false, onNavigationChange, drawers = [], activeDrawerId = null, onDrawerChange, ariaLabels, className, navigationToggleRef, drawerTriggerRef, navigationControlsId, drawerControlsId, ...rest }) {
    const i18n = useInternalI18n('app-layout-toolbar');
    return (_jsxs("div", { ...rest, className: clsx(styles.root, className), children: [!navigationHide && (_jsx(TriggerButton, { ref: navigationToggleRef, className: styles['navigation-toggle'], iconName: "menu", ariaLabel: navigationOpen
                    ? i18n('navigationClose', ariaLabels?.navigationClose)
                    : i18n('navigationToggle', ariaLabels?.navigationToggle), expanded: navigationOpen, ariaControls: navigationControlsId, onClick: () => fireNonCancelableEvent(onNavigationChange, { open: !navigationOpen }) })), _jsx("div", { className: styles.breadcrumbs, children: breadcrumbs }), drawers.length > 0 && (_jsx("div", { role: "group", className: styles.drawers, "aria-label": i18n('drawers', ariaLabels?.drawers), children: drawers.map(drawer => {
                    const active = drawer.id === activeDrawerId;
                    return (_jsx(TriggerButton, { ref: drawerTriggerRef?.(drawer.id), "data-trigger-id": drawer.id, iconName: drawer.iconName, iconSvg: drawer.iconSvg, ariaLabel: drawer.ariaLabel, badge: drawer.badge, expanded: active, ariaControls: active ? drawerControlsId : undefined, onClick: () => fireNonCancelableEvent(onDrawerChange, { activeDrawerId: active ? null : drawer.id }) }, drawer.id));
                }) }))] }));
}
