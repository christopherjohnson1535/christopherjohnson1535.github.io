// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { getBaseProps } from '../internal/base-component';
import { InternalAppLayoutToolbar } from './internal';
export default function AppLayoutToolbar({ breadcrumbs, navigationOpen = false, navigationHide = false, onNavigationChange, drawers, activeDrawerId = null, onDrawerChange, ariaLabels, ...props }) {
    return (_jsx(InternalAppLayoutToolbar, { ...getBaseProps(props), breadcrumbs: breadcrumbs, navigationOpen: navigationOpen, navigationHide: navigationHide, onNavigationChange: onNavigationChange, drawers: drawers, activeDrawerId: activeDrawerId, onDrawerChange: onDrawerChange, ariaLabels: ariaLabels }));
}
