// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { warnOnce } from './logging';
/**
 * The heading element for `level`. A value outside 1 to 6 warns and falls back to `fallback`, so a
 * typo never drops the heading from the page outline.
 */
export function getHeadingTag(component, level, fallback) {
    if (level === undefined) {
        return `h${fallback}`;
    }
    if (!Number.isInteger(level) || level < 1 || level > 6) {
        warnOnce(component, '`headingLevel` must be a whole number from 1 to 6.');
        return `h${fallback}`;
    }
    return `h${level}`;
}
