// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { createContext, useContext } from 'react';
export const FormFieldContext = createContext({});
/**
 * Lets a control pick up its label, description and validation state from the
 * surrounding form field. Props set directly on the control win.
 */
export function useFormFieldContext(props) {
    const context = useContext(FormFieldContext);
    return {
        controlId: props.controlId ?? context.controlId,
        ariaLabelledby: props.ariaLabelledby ?? context.ariaLabelledby,
        ariaDescribedby: props.ariaDescribedby ?? context.ariaDescribedby,
        invalid: props.invalid ?? context.invalid,
        warning: props.warning ?? context.warning,
    };
}
