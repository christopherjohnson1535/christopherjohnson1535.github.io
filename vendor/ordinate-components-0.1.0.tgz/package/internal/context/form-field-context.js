// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { createContext, useContext, useId } from 'react';
import { useBrowserLayoutEffect } from '../hooks/use-browser-layout-effect';
export const FormFieldContext = createContext({});
/**
 * Lets a control pick up its label, description and validation state from the
 * surrounding form field. Props set directly on the control win.
 */
export function useFormFieldContext(props) {
    const context = useContext(FormFieldContext);
    return {
        controlId: props.controlId ?? context.controlId,
        ariaLabelledby: props.ariaLabelledby ?? context.ariaLabelledby,
        ariaDescribedby: props.ariaDescribedby ?? context.ariaDescribedby,
        invalid: props.invalid ?? context.invalid,
        warning: props.warning ?? context.warning,
    };
}
/**
 * The form field context for a checkbox, radio button or toggle. These carry their own label, so they
 * never take the field's control ID: a field can hold several of them, and each needs an ID of its own.
 * The control tells the field its ID instead, so the field can point its label at a single control or
 * label several of them as a group.
 */
export function useChoiceControlFieldContext(props) {
    const context = useContext(FormFieldContext);
    const generatedId = useId();
    const controlId = props.controlId ?? `${generatedId}control`;
    const register = context.registerChoiceControl;
    useBrowserLayoutEffect(() => register?.(controlId), [register, controlId]);
    return { ...useFormFieldContext(props), controlId };
}
