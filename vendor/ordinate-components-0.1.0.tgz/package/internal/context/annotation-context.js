// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { createContext, useContext } from 'react';
export const AnnotationContextContext = createContext(null);
/**
 * The tutorial state, or `null` outside an `AnnotationContext`.
 */
export function useAnnotationContext() {
    return useContext(AnnotationContextContext);
}
/**
 * Lists every step of a tutorial in order, each with its task and position.
 */
export function flattenSteps(tutorial) {
    if (!tutorial) {
        return [];
    }
    const steps = [];
    tutorial.tasks.forEach((task, taskIndex) => task.steps.forEach((step, indexInTask) => steps.push({ step, index: steps.length, taskIndex, indexInTask, taskStepCount: task.steps.length })));
    return steps;
}
