// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { createContext, useContext } from 'react';
import english from '../../i18n/messages/all.en';
import { formatMessage } from './format';
export const namespace = '@ordinate/components';
const fallbackLocale = 'en';
export const I18nContext = createContext({ locale: null, messages: {} });
function documentLocale() {
    return typeof document === 'undefined' ? null : document.documentElement.lang || null;
}
/**
 * Picks the closest available locale: an exact match, then the same language
 * (`pt-BR` falls back to `pt`, and `zh` to `zh-CN`), then English.
 */
export function matchLocale(requested, available) {
    if (!requested) {
        return fallbackLocale;
    }
    const lower = requested.toLowerCase();
    const language = lower.split('-')[0];
    const candidates = available.map(locale => [locale, locale.toLowerCase()]);
    const exact = candidates.find(([, candidate]) => candidate === lower);
    const sameLanguage = candidates.find(([, candidate]) => candidate === language) ??
        candidates.find(([, candidate]) => candidate.split('-')[0] === language);
    return (exact ?? sameLanguage)?.[0] ?? fallbackLocale;
}
/**
 * Merges message sets for Ordinate's namespace. Later sets win.
 */
export function mergeMessages(sets) {
    const merged = {};
    for (const set of sets) {
        for (const [locale, components] of Object.entries(set[namespace] ?? {})) {
            const target = (merged[locale] ?? (merged[locale] = {}));
            for (const [component, values] of Object.entries(components)) {
                target[component] = { ...target[component], ...values };
            }
        }
    }
    return merged;
}
/**
 * Returns a lookup for one component's messages. A value passed as a prop always wins;
 * otherwise the message comes from the provider's locale, then from English.
 */
export function useInternalI18n(component) {
    const { locale: providerLocale, messages } = useContext(I18nContext);
    return (key, provided, params) => {
        if (provided !== undefined) {
            return provided;
        }
        const locale = matchLocale(providerLocale ?? documentLocale(), Object.keys(messages));
        const template = messages[locale]?.[component]?.[key] ?? english[namespace][fallbackLocale][component]?.[key] ?? undefined;
        return template === undefined ? undefined : formatMessage(template, params, locale);
    };
}
