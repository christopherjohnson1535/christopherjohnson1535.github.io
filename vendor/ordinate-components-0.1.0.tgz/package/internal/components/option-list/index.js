import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { useId } from 'react';
import clsx from 'clsx';
import { InternalIcon } from '../../../icon/internal';
import { getLabel } from './utils';
import styles from './styles.css.js';
export function OptionContent({ option, disabled }) {
    return (_jsxs("span", { className: styles['option-content'], children: [_jsxs("span", { className: styles['option-main'], children: [option.iconName && (_jsx(InternalIcon, { className: styles['option-icon'], name: option.iconName, ariaLabel: option.iconAriaLabel, variant: disabled ? 'disabled' : 'normal' })), _jsx("span", { className: styles['option-label'], lang: option.lang, children: getLabel(option) }), option.labelTag && _jsx("span", { className: styles['option-label-tag'], children: option.labelTag })] }), option.description && _jsx("span", { className: styles['option-description'], children: option.description }), option.tags && option.tags.length > 0 && (_jsx("span", { className: styles['option-tags'], children: option.tags.map((tag, index) => (_jsx("span", { className: styles['option-tag'], children: tag }, index))) }))] }));
}
function Checkbox({ state, disabled }) {
    const mark = state.indeterminate ? 'indeterminate' : state.selected ? 'checked' : 'unchecked';
    return (_jsx("span", { className: styles['checkbox-line'], children: _jsx("span", { className: clsx(styles.checkbox, styles[`checkbox-${mark}`], disabled && styles['checkbox-disabled']), children: mark === 'checked' && _jsx(InternalIcon, { name: "check", size: "small" }) }) }));
}
/**
 * The listbox of a select, multiselect or autosuggest: options, group labels and the selection indicator.
 * The host owns the highlight and the selection, so the same list serves each component's keyboard model.
 */
export function OptionList({ id, listRef, items, getOptionId, highlight, indicator, getOptionState, onOptionClick, multiselectable = false, focusable = false, ariaLabelledby, ariaLabel, }) {
    const baseId = useId();
    const { highlightedIndex } = highlight;
    const renderOption = (item, index) => {
        const state = getOptionState(item, index);
        const highlighted = index === highlightedIndex;
        return (_jsxs("li", { id: getOptionId(index), role: "option", className: clsx(styles.option, item.group && styles['option-in-group'], item.extra && styles['option-extra'], state.selected && indicator === 'check' && styles['option-selected'], highlighted && styles['option-highlighted'], highlighted && highlight.source === 'keyboard' && styles['option-keyboard'], item.disabled && styles['option-disabled']), "aria-selected": state.selected, "aria-disabled": item.disabled ? 'true' : undefined, "data-value": item.option.value, onMouseMove: () => highlight.hoverOption(index), onClick: () => onOptionClick(index), children: [indicator === 'checkbox' && _jsx(Checkbox, { state: state, disabled: item.disabled }), _jsx(OptionContent, { option: item.option, disabled: item.disabled }), indicator === 'check' && (_jsx("span", { className: styles['option-check'], children: state.selected && _jsx(InternalIcon, { name: "check" }) }))] }, `option-${index}`));
    };
    // Options are numbered in the order they appear, across groups, to match the host's flat option list.
    const nodes = [];
    let optionIndex = 0;
    for (let position = 0; position < items.length; position++) {
        const item = items[position];
        if (item.type === 'option') {
            nodes.push(renderOption(item, optionIndex++));
            continue;
        }
        const groupLabelId = `${baseId}group-${position}`;
        const children = [];
        while (position + 1 < items.length) {
            const next = items[position + 1];
            if (next.type !== 'option' || next.group !== item.option) {
                break;
            }
            children.push(renderOption(next, optionIndex++));
            position++;
        }
        nodes.push(_jsxs("li", { role: "presentation", className: styles.group, children: [_jsx("div", { id: groupLabelId, className: clsx(styles['group-label'], item.disabled && styles['option-disabled']), children: _jsx(OptionContent, { option: item.option, disabled: item.disabled }) }), _jsx("ul", { role: "group", "aria-labelledby": groupLabelId, className: styles['group-options'], children: children })] }, `group-${position}`));
    }
    return (_jsx("ul", { ref: listRef, id: id, role: "listbox", className: styles.list, tabIndex: focusable ? -1 : undefined, "aria-label": ariaLabel, "aria-labelledby": ariaLabelledby, "aria-multiselectable": multiselectable ? 'true' : undefined, "aria-activedescendant": focusable && highlightedIndex >= 0 ? getOptionId(highlightedIndex) : undefined, children: nodes }));
}
