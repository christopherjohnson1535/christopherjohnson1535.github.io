import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
import clsx from 'clsx';
import { followLink } from '../../site-links';
import styles from './styles.css.js';
/**
 * The logo and name of a site, as shown in its header and footer.
 */
export function SiteBrandMark({ brand, className, onFollow }) {
    const content = (_jsxs(_Fragment, { children: [brand.logo && (_jsx("span", { className: styles.logo, "aria-hidden": "true", children: brand.logo })), _jsx("span", { className: styles.name, children: brand.name })] }));
    if (brand.href === undefined) {
        return _jsx("span", { className: clsx(styles.brand, className), children: content });
    }
    return (_jsx("a", { className: clsx(styles.brand, styles.link, className), href: brand.href, onClick: event => followLink(onFollow, { href: brand.href, text: brand.name }, event), children: content }));
}
