import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React, { useCallback, useRef } from 'react';
import { createPortal } from 'react-dom';
import clsx from 'clsx';
import { useFloatingPosition } from './use-floating-position';
import styles from './styles.css.js';
export { computeFloatingPosition, toPhysicalSide } from './position';
export { useFloatingPosition } from './use-floating-position';
/**
 * A panel that floats next to a trigger with an arrow pointing at it. It flips to the
 * opposite side when the preferred side has no room and stays inside the viewport.
 *
 * It only positions and frames its content. The component that owns it decides when it
 * is shown, what role it has and how it is dismissed. Keep it mounted with `hidden` when
 * other elements refer to it by ID, as a tooltip's trigger does.
 *
 * ```tsx
 * <FloatingPanel trigger={buttonRef} preferredSide="top" role="tooltip" id={id}>
 *   Copied
 * </FloatingPanel>
 * ```
 */
export const FloatingPanel = React.forwardRef(({ trigger, preferredSide, variant = 'sheet', renderWithPortal = false, gap, hidden, className, children, ...rest }, ref) => {
    const panelRef = useRef(null);
    const arrowRef = useRef(null);
    const { physicalSide, panelStyle, arrowStyle } = useFloatingPosition({
        open: !hidden,
        trigger,
        panel: panelRef,
        arrow: arrowRef,
        preferredSide,
        gap,
    });
    const setRefs = useCallback((element) => {
        panelRef.current = element;
        if (typeof ref === 'function') {
            ref(element);
        }
        else if (ref) {
            ref.current = element;
        }
    }, [ref]);
    const panel = (_jsxs("span", { ...rest, ref: setRefs, hidden: hidden, className: clsx(styles.panel, styles[`variant-${variant}`], styles[`side-${physicalSide}`], className), style: panelStyle, children: [children, _jsx("span", { ref: arrowRef, className: clsx(styles.arrow, styles[`arrow-${physicalSide}`]), style: arrowStyle })] }));
    return renderWithPortal && typeof document !== 'undefined' ? createPortal(panel, document.body) : panel;
});
