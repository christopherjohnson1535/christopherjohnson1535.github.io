// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import React from 'react';
function resolveLevel(level, defaultLevel) {
    const valid = level !== undefined && Number.isInteger(level) && level >= 1 && level <= 6;
    return valid ? level : defaultLevel;
}
/**
 * A heading element whose level is chosen by the page, so website components keep the outline in order.
 */
export function Heading({ level, defaultLevel = 2, className, children }) {
    return React.createElement(`h${resolveLevel(level, defaultLevel)}`, { className }, children);
}
