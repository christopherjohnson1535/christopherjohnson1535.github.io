import { jsxs as _jsxs, jsx as _jsx } from "react/jsx-runtime";
// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { useId } from 'react';
import clsx from 'clsx';
import styles from './styles.css.js';
function joinIds(...ids) {
    return ids.filter(Boolean).join(' ') || undefined;
}
/**
 * Shared layout for checkbox, radio button and toggle: a native input laid over a
 * drawn control, followed by a label and an optional description.
 */
export function AbstractSwitch({ className, controlId, label, description, disabled = false, ariaLabelledby, ariaDescribedby, nativeControl, styledControl, ...rest }) {
    const baseId = useId();
    const id = controlId ?? `${baseId}control`;
    const labelId = `${baseId}label`;
    const descriptionId = `${baseId}description`;
    // The <label for> names the input on its own. Once aria-labelledby comes from a form
    // field it replaces that name, so the switch's own label has to be listed there too.
    const labelledBy = ariaLabelledby ? joinIds(ariaLabelledby, Boolean(label) && labelId) : undefined;
    const describedBy = joinIds(ariaDescribedby, Boolean(description) && descriptionId);
    return (_jsxs("span", { ...rest, className: clsx(styles.root, disabled && styles.disabled, className), children: [_jsxs("span", { className: styles.control, children: [nativeControl({
                        id,
                        className: styles['native-input'],
                        'aria-labelledby': labelledBy,
                        'aria-describedby': describedBy,
                    }), styledControl] }), (label || description) && (_jsxs("span", { className: styles.content, children: [label && (_jsx("label", { id: labelId, htmlFor: id, className: styles.label, children: label })), description && (_jsx("span", { id: descriptionId, className: styles.description, children: description }))] }))] }));
}
