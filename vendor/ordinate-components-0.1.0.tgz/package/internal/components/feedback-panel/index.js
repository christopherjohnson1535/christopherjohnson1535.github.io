import { jsx as _jsx } from "react/jsx-runtime";
import clsx from 'clsx';
import { FloatingPanel } from '../floating-panel';
import styles from './styles.css.js';
export { feedbackDuration, useFeedback } from './use-feedback';
/**
 * A short status message in an ink panel next to a control, such as "Copied". Pair it with
 * `useFeedback`, and mount it with the feedback's `key` when the user acts.
 *
 * The panel is a polite live region. `useFeedback` mounts it empty and fills it in a later
 * render, because screen readers only announce changes to a live region already in the page.
 */
export function FeedbackPanel({ trigger, children, preferredSide = 'top', renderWithPortal = false, className, }) {
    const filled = children !== null && children !== undefined;
    return (_jsx(FloatingPanel, { trigger: trigger, preferredSide: preferredSide, variant: "inverse", role: "status", renderWithPortal: renderWithPortal, className: clsx(styles.panel, !filled && styles.empty, className), children: children }));
}
