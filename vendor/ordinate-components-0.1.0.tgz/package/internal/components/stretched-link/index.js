import { jsx as _jsx } from "react/jsx-runtime";
import clsx from 'clsx';
import { isPlainLeftClick } from '../../link-click';
import styles from './styles.css.js';
/**
 * A link whose click area covers its nearest positioned ancestor, so a whole card or row follows the
 * link while the link stays the only interactive element in it. The ancestor sets
 * `position: relative`. A part that may hold links or buttons of its own, such as the byline, takes
 * `raiseInteractiveClassName` so those stay clickable above the card's link.
 */
export function StretchedLink({ href, children, onFollow, className }) {
    return (_jsx("a", { className: clsx(styles.link, className), href: href, onClick: event => {
            if (isPlainLeftClick(event)) {
                onFollow?.(event);
            }
        }, children: children }));
}
export const raiseInteractiveClassName = styles['raise-interactive'];
