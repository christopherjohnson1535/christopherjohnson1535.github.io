import { createElement as _createElement } from "react";
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { useId } from 'react';
import clsx from 'clsx';
import { InternalButton } from '../../../button/internal';
import { isSameDay, isSameMonth } from '../../dates/arithmetic';
import { getMonthGrid, getYearGrid } from '../../dates/grid';
import { formatIsoDate } from '../../dates/iso';
import { formatDayNumber, formatFullDate, formatMonthName, formatMonthYear, getWeekdayNames } from '../../dates/locale';
import styles from './styles.css.js';
export { tabStopSelector, useGridKeyboard } from './use-grid-keyboard';
const maxShortWeekdayLength = 4;
// Voice control users name a cell by what it shows, so the accessible name must contain the
// visible text as a word: a month shown as "Jan" is named "Jan, January 2026".
function includesWord(label, word) {
    return label
        .toLocaleLowerCase()
        .split(/[\s,.]+/)
        .includes(word.toLocaleLowerCase());
}
function GridCell({ date, label, text, isCurrent, isFocused, outside = false, className, currentAriaLabel, isEnabled, getCellState, getDisabledReason, onSelect, onFocusDate, onHoverDate, }) {
    const reasonId = useId();
    const enabled = isEnabled(date);
    const state = getCellState(date);
    const reason = enabled ? undefined : getDisabledReason?.(date);
    const named = includesWord(label, text) ? label : `${text}, ${label}`;
    const name = isCurrent && currentAriaLabel ? `${currentAriaLabel}, ${named}` : named;
    return (_jsxs("td", { role: "gridcell", className: clsx(styles.cell, className, outside && styles.outside, !enabled && styles.disabled, isCurrent && styles.current, state.selected && styles.selected, state.inRange && styles['in-range'], state.rangeStart && styles['range-start'], state.rangeEnd && styles['range-end']), tabIndex: isFocused ? 0 : -1, "aria-label": name, "aria-selected": Boolean(state.selected), "aria-disabled": enabled ? undefined : true, "aria-current": isCurrent ? 'date' : undefined, "aria-describedby": reason ? reasonId : undefined, "data-date": formatIsoDate(date), onClick: event => {
            // Popups keep focus where it was on a press, so the clicked day takes it here.
            event.currentTarget.focus();
            onFocusDate(date);
            if (enabled) {
                onSelect(date);
            }
        }, onFocus: () => {
            if (!isFocused) {
                onFocusDate(date);
            }
        }, onMouseEnter: onHoverDate && (() => onHoverDate(date)), children: [_jsx("span", { className: styles.mark, "aria-hidden": "true", children: text }), reason && (_jsx("span", { id: reasonId, hidden: true, children: reason }))] }));
}
/**
 * A month as a WAI-ARIA grid of days. It draws the days and reports clicks and focus; the host
 * owns the focused and selected dates and handles keys through `useGridKeyboard`.
 */
export function MonthGrid(props) {
    const { month, weekStart, locale, focusedDate, today, showOutsideDays = true, ariaLabelledby, ariaDescribedby, onHoverDate, onKeyDown, } = props;
    const shortWeekdays = getWeekdayNames(locale, weekStart, 'short');
    // Some locales, such as Arabic, have short names too wide for a day column; their narrow names fit.
    const weekdays = shortWeekdays.some(({ name }) => name.length > maxShortWeekdayLength)
        ? getWeekdayNames(locale, weekStart, 'narrow')
        : shortWeekdays;
    const longWeekdays = getWeekdayNames(locale, weekStart, 'long');
    return (_jsxs("table", { role: "grid", className: styles.grid, "aria-labelledby": ariaLabelledby, "aria-describedby": ariaDescribedby, onKeyDown: onKeyDown, onMouseLeave: onHoverDate && (() => onHoverDate(null)), children: [_jsx("thead", { children: _jsx("tr", { children: weekdays.map(({ day, name }, index) => (_jsxs("th", { scope: "col", className: styles.weekday, children: [_jsx("span", { "aria-hidden": "true", children: name }), _jsx("span", { className: styles['screenreader-only'], children: longWeekdays[index].name })] }, day))) }) }), _jsx("tbody", { children: getMonthGrid(month, weekStart).map(week => (_jsx("tr", { children: week.map(date => {
                        const outside = !isSameMonth(date, month);
                        if (outside && !showOutsideDays) {
                            return _jsx("td", { role: "gridcell", className: styles.cell }, formatIsoDate(date));
                        }
                        return (_createElement(GridCell, { ...props, key: formatIsoDate(date), date: date, label: formatFullDate(date, locale), text: formatDayNumber(date, locale), isCurrent: isSameDay(date, today), isFocused: isSameDay(date, focusedDate) && !outside, outside: outside }));
                    }) }, formatIsoDate(week[0])))) })] }));
}
/**
 * A year as a WAI-ARIA grid of months, for picking a month rather than a day.
 */
export function YearGrid(props) {
    const { year, locale, focusedDate, today, ariaLabelledby, ariaDescribedby, onHoverDate, onKeyDown } = props;
    return (_jsx("table", { role: "grid", className: clsx(styles.grid, styles['year-grid']), "aria-labelledby": ariaLabelledby, "aria-describedby": ariaDescribedby, onKeyDown: onKeyDown, onMouseLeave: onHoverDate && (() => onHoverDate(null)), children: _jsx("tbody", { children: getYearGrid(year).map(row => (_jsx("tr", { children: row.map(date => (_createElement(GridCell, { ...props, key: date.getMonth(), className: styles['month-cell'], date: date, label: formatMonthYear(date, locale), text: formatMonthName(date, locale, 'short'), isCurrent: isSameMonth(date, today), isFocused: isSameMonth(date, focusedDate) }))) }, row[0].getMonth()))) }) }));
}
/**
 * The title of a month or year grid with the buttons that page to the previous and next one.
 * The title is a polite live region, so paging is announced.
 */
export function GridHeader({ title, titleId, previousAriaLabel, nextAriaLabel, onPrevious, onNext }) {
    return (_jsxs("div", { className: styles.header, children: [_jsx("div", { className: styles['header-slot'], children: onPrevious && (_jsx(InternalButton, { className: styles['page-button'], variant: "icon", formAction: "none", iconName: "angle-left", ariaLabel: previousAriaLabel, onClick: onPrevious })) }), _jsx("div", { id: titleId, className: styles.title, "aria-live": "polite", children: title }), _jsx("div", { className: styles['header-slot'], children: onNext && (_jsx(InternalButton, { className: styles['page-button'], variant: "icon", formAction: "none", iconName: "angle-right", ariaLabel: nextAriaLabel, onClick: onNext })) })] }));
}
