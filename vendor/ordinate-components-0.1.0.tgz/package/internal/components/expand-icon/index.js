import { jsx as _jsx } from "react/jsx-runtime";
import clsx from 'clsx';
import { InternalIcon } from '../../../icon/internal';
import styles from './styles.css.js';
/**
 * The caret of a disclosure button. It turns with motion when the state changes.
 */
export function ExpandIcon({ expanded, collapsedDirection = 'inline-end', className }) {
    return (_jsx("span", { className: clsx(styles.root, styles[`collapsed-${collapsedDirection}`], expanded && styles.expanded, className), children: _jsx(InternalIcon, { name: "caret-down-solid" }) }));
}
