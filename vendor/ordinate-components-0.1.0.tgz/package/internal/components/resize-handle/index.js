import { jsx as _jsx } from "react/jsx-runtime";
// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { useRef } from 'react';
import clsx from 'clsx';
import { InternalIcon } from '../../../icon/internal';
import { getIsRtl, getLogicalArrowStep } from '../../direction';
import styles from './styles.css.js';
const isBlockEdge = (edge) => edge !== 'inline-start';
const keyboardStep = 16;
export function clampSize(size, minSize, maxSize) {
    return Math.round(Math.max(minSize, Math.min(size, Math.max(minSize, maxSize))));
}
// Screen readers announce the position as a share of the range, which reads better than pixels.
function toPercent(size, minSize, maxSize) {
    if (maxSize <= minSize) {
        return 100;
    }
    return Math.round(((clampSize(size, minSize, maxSize) - minSize) / (maxSize - minSize)) * 100);
}
function getKeyboardDelta(event, edge) {
    if (isBlockEdge(edge)) {
        const grow = edge === 'block-start' ? 'ArrowUp' : 'ArrowDown';
        const shrink = edge === 'block-start' ? 'ArrowDown' : 'ArrowUp';
        if (event.key === grow) {
            return keyboardStep;
        }
        return event.key === shrink ? -keyboardStep : 0;
    }
    // Moving the edge toward the start of the line makes a panel at the end wider.
    return -getLogicalArrowStep(event.key, event.currentTarget) * keyboardStep;
}
/**
 * A separator on the edge of a panel that resizes it with a pointer drag or the arrow keys.
 * Home and End jump to the smallest and largest size.
 */
export function ResizeHandle({ edge, size, minSize, maxSize, onResize, ariaLabel, ariaControls, className, }) {
    const drag = useRef(null);
    const resize = (next) => {
        const clamped = clampSize(next, minSize, maxSize);
        if (clamped !== size) {
            onResize(clamped);
        }
    };
    const handlePointerDown = (event) => {
        if (event.button !== 0) {
            return;
        }
        // Keeps the drag from selecting text on the page.
        event.preventDefault();
        event.currentTarget.setPointerCapture?.(event.pointerId);
        event.currentTarget.focus();
        drag.current = { x: event.clientX, y: event.clientY, size, rtl: getIsRtl(event.currentTarget) };
    };
    const handlePointerMove = (event) => {
        const start = drag.current;
        if (!start) {
            return;
        }
        let delta;
        if (edge === 'block-start') {
            delta = start.y - event.clientY;
        }
        else if (edge === 'block-end') {
            delta = event.clientY - start.y;
        }
        else {
            delta = start.rtl ? event.clientX - start.x : start.x - event.clientX;
        }
        resize(start.size + delta);
    };
    const endDrag = (event) => {
        drag.current = null;
        event.currentTarget.releasePointerCapture?.(event.pointerId);
    };
    const handleKeyDown = (event) => {
        let next;
        if (event.key === 'Home') {
            next = minSize;
        }
        else if (event.key === 'End') {
            next = maxSize;
        }
        else {
            const delta = getKeyboardDelta(event, edge);
            next = delta === 0 ? null : size + delta;
        }
        if (next !== null) {
            event.preventDefault();
            resize(next);
        }
    };
    return (_jsx("div", { role: "separator", tabIndex: 0, "aria-label": ariaLabel, "aria-controls": ariaControls, "aria-orientation": isBlockEdge(edge) ? 'horizontal' : 'vertical', "aria-valuemin": 0, "aria-valuemax": 100, "aria-valuenow": toPercent(size, minSize, maxSize), className: clsx(styles.handle, styles[`edge-${edge}`], className), onPointerDown: handlePointerDown, onPointerMove: handlePointerMove, onPointerUp: endDrag, onPointerCancel: endDrag, onKeyDown: handleKeyDown, children: _jsx(InternalIcon, { className: styles.grip, name: "drag-indicator", size: "small" }) }));
}
