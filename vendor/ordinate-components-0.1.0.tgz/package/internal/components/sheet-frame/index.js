import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import clsx from 'clsx';
import { ConstructionTopLine, RuleEndMarks } from '../construction';
import styles from './styles.css.js';
/**
 * A full-width drawn section with the header on top, for collections such as Table and Cards that need
 * the whole width for their content. It is drawn like Container: a construction line opens it and runs
 * past both ends, and the rule above the footer carries a hash mark at each end.
 */
export function SheetFrame({ header, footer, className, children, ...rest }) {
    return (_jsxs("div", { ...rest, className: clsx(styles.root, className), children: [_jsx(ConstructionTopLine, {}), header && _jsx("div", { className: styles.header, children: header }), _jsx("div", { className: styles.content, children: children }), footer && (_jsxs("div", { className: styles.footer, children: [_jsx(RuleEndMarks, {}), footer] }))] }));
}
