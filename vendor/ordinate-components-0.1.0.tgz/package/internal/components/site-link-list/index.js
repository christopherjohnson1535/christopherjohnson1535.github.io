import { jsx as _jsx } from "react/jsx-runtime";
import clsx from 'clsx';
import { followLink } from '../../site-links';
import styles from './styles.css.js';
/**
 * A plain list of links, as used in site headers, footers and mastheads. The link to the page being
 * shown carries `aria-current="page"`.
 */
export function SiteLinkList({ links, id, className, itemClassName, linkClassName, onFollow, onLinkClick, }) {
    return (_jsx("ul", { id: id, className: clsx(styles.list, className), children: links.map((link, index) => (_jsx("li", { className: itemClassName, children: _jsx("a", { className: linkClassName, href: link.href, "aria-current": link.current ? 'page' : undefined, onClick: event => {
                    followLink(onFollow, { href: link.href, text: link.text }, event);
                    onLinkClick?.();
                }, children: link.text }) }, `${index}-${link.href}`))) }));
}
