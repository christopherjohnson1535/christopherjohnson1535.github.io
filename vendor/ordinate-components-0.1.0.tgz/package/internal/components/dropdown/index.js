import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import clsx from 'clsx';
import { getIsRtl } from '../../direction';
import styles from './styles.css.js';
// Layout effects do nothing on the server, and React 18 warns when they are used there.
const useBrowserLayoutEffect = typeof window === 'undefined' ? useEffect : useLayoutEffect;
// Keeps the popup clear of the viewport edge when its height is limited by the available space.
const viewportMargin = 8;
function isSamePlacement(a, b) {
    return (a.above === b.above &&
        a.alignEnd === b.alignEnd &&
        a.availableBlockSize === b.availableBlockSize &&
        a.fixed?.top === b.fixed?.top &&
        a.fixed?.bottom === b.fixed?.bottom &&
        a.fixed?.left === b.fixed?.left &&
        a.fixed?.minWidth === b.fixed?.minWidth);
}
function getFixedPosition(rect, width, above, alignEnd, rtl) {
    const alignedToLeftEdge = alignEnd === rtl;
    return {
        top: above ? undefined : rect.bottom,
        bottom: above ? window.innerHeight - rect.top : undefined,
        left: alignedToLeftEdge ? rect.left : rect.right - width,
        minWidth: rect.width,
    };
}
// Aligns the popup to the trigger's end edge when that keeps it inside the viewport and the start edge does not.
function shouldAlignEnd(root, popupWidth) {
    const rect = root.getBoundingClientRect();
    const maxRight = document.documentElement.clientWidth - viewportMargin;
    const fits = (left) => left >= viewportMargin && left + popupWidth <= maxRight;
    const startLeft = getIsRtl(root) ? rect.right - popupWidth : rect.left;
    const endLeft = getIsRtl(root) ? rect.left : rect.right - popupWidth;
    return !fits(startLeft) && fits(endLeft);
}
/**
 * A popup positioned under its trigger, at least as wide as the trigger. It
 * opens above the trigger when there is not enough room below and more room
 * above, and lines up with the trigger's end edge when it would overflow the
 * viewport from the start edge. It holds no state of its own: the host decides
 * when it is open.
 */
export function Dropdown({ open, trigger, header, footer, children, onOutsideClick, onContentScroll, minWidth = 'trigger', maxWidth, ariaRole, ariaLabel, ariaLabelledby, expandToViewport = false, className, }) {
    const rootRef = useRef(null);
    const popupRef = useRef(null);
    const [placement, setPlacement] = useState({ above: false, alignEnd: false });
    useBrowserLayoutEffect(() => {
        if (!open) {
            return;
        }
        const place = () => {
            const root = rootRef.current;
            const popup = popupRef.current;
            if (!root || !popup) {
                return;
            }
            const rect = root.getBoundingClientRect();
            const spaceBelow = window.innerHeight - rect.bottom - viewportMargin;
            const spaceAbove = rect.top - viewportMargin;
            const above = popup.offsetHeight > spaceBelow && spaceAbove > spaceBelow;
            const availableBlockSize = Math.max(above ? spaceAbove : spaceBelow, 0);
            const rtl = getIsRtl(root);
            const width = popup.offsetWidth;
            const alignEnd = shouldAlignEnd(root, width);
            const next = {
                above,
                alignEnd,
                availableBlockSize,
                fixed: expandToViewport ? getFixedPosition(rect, width, above, alignEnd, rtl) : undefined,
            };
            setPlacement(current => (isSamePlacement(current, next) ? current : next));
        };
        place();
        window.addEventListener('resize', place);
        window.addEventListener('scroll', place, true);
        // The popup grows and shrinks as options load or are filtered.
        const observer = typeof ResizeObserver === 'undefined' ? undefined : new ResizeObserver(place);
        if (popupRef.current) {
            observer?.observe(popupRef.current);
        }
        return () => {
            window.removeEventListener('resize', place);
            window.removeEventListener('scroll', place, true);
            observer?.disconnect();
        };
    }, [open, expandToViewport]);
    useEffect(() => {
        if (!open || !onOutsideClick) {
            return;
        }
        const handleMouseDown = (event) => {
            if (!rootRef.current?.contains(event.target)) {
                onOutsideClick();
            }
        };
        document.addEventListener('mousedown', handleMouseDown);
        return () => document.removeEventListener('mousedown', handleMouseDown);
    }, [open, onOutsideClick]);
    const popupStyle = {};
    if (placement.availableBlockSize !== undefined) {
        popupStyle['--dropdown-available-block-size'] = `${placement.availableBlockSize}px`;
    }
    if (expandToViewport && placement.fixed) {
        // Measured from the viewport, so these are physical coordinates in either direction.
        popupStyle.top = placement.fixed.top;
        // Opening upward, the plate stands off by its offset too, which the stylesheet adds.
        if (placement.fixed.bottom !== undefined) {
            popupStyle['--dropdown-fixed-bottom'] = `${placement.fixed.bottom}px`;
        }
        popupStyle.left = placement.fixed.left;
        popupStyle.minWidth = minWidth === 'trigger' ? placement.fixed.minWidth : undefined;
    }
    return (_jsxs("div", { ref: rootRef, className: clsx(styles.root, className), children: [trigger, open && (_jsxs("div", { ref: popupRef, className: clsx(styles.popup, placement.above && styles['popup-above'], placement.alignEnd && styles['popup-align-end'], styles[`min-width-${minWidth}`], maxWidth && styles['fit-content'], maxWidth && styles[`max-width-${maxWidth}`], expandToViewport && styles['popup-fixed']), style: popupStyle, role: ariaRole, "aria-label": ariaLabel, "aria-labelledby": ariaLabelledby, onMouseDown: event => {
                    // Clicking the popup's own surface would otherwise move focus to the page and close it.
                    if (!event.target.closest('input, button, textarea, a[href]')) {
                        event.preventDefault();
                    }
                }, children: [header && _jsx("div", { className: styles.header, children: header }), _jsx("div", { className: styles.content, onScroll: onContentScroll ? event => onContentScroll(event.currentTarget) : undefined, children: children }), footer && _jsx("div", { className: styles.footer, children: footer })] }))] }));
}
