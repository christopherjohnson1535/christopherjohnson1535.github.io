import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
import clsx from 'clsx';
import styles from './styles.css.js';
/**
 * The construction line that opens a drawn section: a thin line along the top edge of the nearest positioned
 * ancestor, running past both ends, with a hash mark at each end. Drawing only, hidden from screen readers.
 * Give the ancestor `position: relative` and enough padding at the top for its content to clear the line.
 */
export function ConstructionTopLine({ kind = 'neutral' }) {
    return (_jsxs(_Fragment, { children: [_jsx("span", { className: clsx(styles[`kind-${kind}`], styles.line, styles['top-line']), "aria-hidden": "true" }), _jsx("span", { className: clsx(styles[`kind-${kind}`], styles.mark, styles['top-start']), "aria-hidden": "true" }), _jsx("span", { className: clsx(styles[`kind-${kind}`], styles.mark, styles['top-end']), "aria-hidden": "true" })] }));
}
/**
 * Hash marks at both ends of a rule drawn along the top edge of the nearest positioned ancestor, such as the
 * rule above a footer. Drawing only, hidden from screen readers.
 */
export function RuleEndMarks({ kind = 'neutral' }) {
    return (_jsxs(_Fragment, { children: [_jsx("span", { className: clsx(styles[`kind-${kind}`], styles.mark, styles['rule-start']), "aria-hidden": "true" }), _jsx("span", { className: clsx(styles[`kind-${kind}`], styles.mark, styles['rule-end']), "aria-hidden": "true" })] }));
}
