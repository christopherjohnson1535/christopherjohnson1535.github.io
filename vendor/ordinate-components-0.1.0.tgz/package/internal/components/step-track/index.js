import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import clsx from 'clsx';
import styles from './styles.css.js';
/**
 * An ordered list of steps joined by a thin drafting line between their markers. Steps and the
 * wizard's navigation both draw their progress with it.
 */
export function StepTrack({ items, orientation = 'vertical', markerSize = 'icon', line = 'ink', ariaLabel, ariaLabelledby, className, }) {
    return (_jsx("ol", { className: clsx(styles.root, styles[`orientation-${orientation}`], styles[`marker-${markerSize}`], styles[`line-${line}`], className), "aria-label": ariaLabel, "aria-labelledby": ariaLabelledby, children: items.map((item, index) => {
            const next = items[index + 1];
            return (_jsxs("li", { ...item.itemProps, className: clsx(styles.item, item.itemProps?.className), children: [item.marker !== undefined && _jsx("span", { className: styles.marker, children: item.marker }), _jsx("div", { className: clsx(styles.head, item.marker === undefined && styles['head-with-marker']), children: item.head }), next && (_jsx("span", { className: clsx(styles.connector, next.upcoming && styles['connector-upcoming']), "aria-hidden": "true" })), item.details !== undefined && item.details !== null && (_jsx("div", { className: styles.details, children: item.details }))] }, item.key));
        }) }));
}
