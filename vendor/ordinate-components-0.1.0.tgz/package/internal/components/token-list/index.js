import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { useEffect, useId, useRef, useState } from 'react';
import clsx from 'clsx';
import { InternalButton } from '../../../button/internal';
import { InternalIcon } from '../../../icon/internal';
import { InternalToken } from '../../../token/internal';
import styles from './styles.css.js';
export function getHiddenTokenCount(count, limit) {
    return limit !== undefined && limit >= 0 ? Math.max(count - limit, 0) : 0;
}
/**
 * A list of tokens, each with an optional dismiss button. Dismissing a focused token moves focus
 * to the next token's button, so focus is not lost with the removed one.
 */
export function TokenList({ items, onDismiss, alignment = 'horizontal', limit, showMoreText, showFewerText, disabled = false, readOnly = false, onEmptied, ariaLabel, className, }) {
    const listId = useId();
    const [expanded, setExpanded] = useState(false);
    const buttonRefs = useRef([]);
    const listRef = useRef(null);
    const pendingFocus = useRef(null);
    const limited = getHiddenTokenCount(items.length, limit) > 0;
    const visible = limited && !expanded ? items.slice(0, limit) : items;
    useEffect(() => {
        const index = pendingFocus.current;
        if (index === null) {
            return;
        }
        pendingFocus.current = null;
        if (visible.length === 0) {
            onEmptied?.();
            return;
        }
        // Disabled tokens have no button, so look for the nearest one that does, forward first.
        const candidates = [
            ...buttonRefs.current.slice(index, visible.length),
            ...buttonRefs.current.slice(0, index).reverse(),
        ];
        candidates.find(Boolean)?.focus();
    });
    if (items.length === 0) {
        return null;
    }
    const dismiss = (index) => {
        // Only take focus back if the removed button had it, so a pointer user's focus is left where it was.
        if (listRef.current?.contains(document.activeElement)) {
            pendingFocus.current = index;
        }
        onDismiss?.(index);
    };
    return (_jsxs("div", { className: clsx(styles.root, styles[`alignment-${alignment}`], className), children: [_jsx("ul", { ref: listRef, id: listId, className: styles.list, "aria-label": ariaLabel, children: visible.map((item, index) => {
                    const itemDisabled = disabled || Boolean(item.disabled);
                    return (_jsx("li", { className: styles.item, children: _jsx(InternalToken, { dismissButtonRef: button => {
                                buttonRefs.current[index] = button;
                            }, label: item.label, labelTag: item.labelTag, description: item.description, tags: item.tags, lang: item.lang, icon: item.iconName && (_jsx(InternalIcon, { name: item.iconName, ariaLabel: item.iconAriaLabel, variant: itemDisabled ? 'disabled' : 'normal' })), disabled: itemDisabled, readOnly: readOnly, dismissLabel: item.dismissLabel, onDismiss: onDismiss ? () => dismiss(index) : undefined }) }, `${index}-${item.label}`));
                }) }), limited && (_jsx(InternalButton, { className: styles.toggle, variant: "link", formAction: "none", ariaExpanded: expanded, ariaControls: listId, onClick: () => setExpanded(current => !current), children: expanded ? showFewerText : showMoreText }))] }));
}
