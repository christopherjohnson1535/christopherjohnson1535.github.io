import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import clsx from 'clsx';
import styles from './styles.css.js';
/**
 * A dimension line: a rule with a hash mark and an extension tick at each end and its label set in the
 * middle, as on a technical drawing. The line breaks around the label, so it needs no background and reads
 * on any surface. It takes the text color of its parent. The marks are drawing only; the label is text.
 */
export function DimensionLine({ label, className }) {
    return (_jsxs("div", { className: clsx(styles.root, className), children: [_jsx("span", { className: styles.end, "aria-hidden": "true" }), _jsx("span", { className: styles.rule, "aria-hidden": "true" }), _jsx("span", { className: styles.label, children: label }), _jsx("span", { className: styles.rule, "aria-hidden": "true" }), _jsx("span", { className: styles.end, "aria-hidden": "true" })] }));
}
