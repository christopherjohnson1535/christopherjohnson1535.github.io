import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
import clsx from 'clsx';
import styles from './styles.css.js';
function isPresent(value) {
    return value !== undefined && value !== null && value !== false && value !== '';
}
/**
 * A label and a value joined by a dotted leader, as on a price list or a contents page. The dots
 * are drawing only and stay out of the accessibility tree. Without a value the label stands alone.
 */
export function LeaderRow({ label, value, className, labelClassName, valueClassName }) {
    return (_jsxs("span", { className: clsx(styles.row, className), children: [_jsx("span", { className: clsx(styles.label, labelClassName), children: label }), isPresent(value) && (_jsxs(_Fragment, { children: [' ', _jsx("span", { className: styles.leader, "aria-hidden": "true" }), _jsx("span", { className: clsx(styles.value, valueClassName), children: value })] }))] }));
}
