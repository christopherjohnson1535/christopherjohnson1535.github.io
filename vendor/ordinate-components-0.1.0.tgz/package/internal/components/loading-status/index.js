import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import clsx from 'clsx';
import { InternalSpinner } from '../../../spinner/internal';
import styles from './styles.css.js';
/**
 * A spinner with a short text, standing in for panel content that is still loading.
 * The text is a status message, so screen readers announce it when it appears.
 */
export function LoadingStatus({ text, className }) {
    return (_jsxs("div", { role: "status", className: clsx(styles.root, className), children: [_jsx(InternalSpinner, {}), text && _jsx("span", { children: text })] }));
}
