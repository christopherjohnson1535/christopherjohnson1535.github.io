import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import clsx from 'clsx';
import styles from './styles.css.js';
/**
 * Marks at the four corners of the nearest positioned ancestor, standing where a border's corners would be.
 * A card drawn this way needs no box. Drawing only, hidden from screen readers. Render it as a direct child of
 * the card, so the card's hover can reach it.
 */
export function CropMarks({ kind = 'neutral', selected = false, interactive = false, open = false }) {
    return (_jsxs("span", { className: clsx(styles.root, styles[`kind-${kind}`], selected && styles.selected, interactive && styles.interactive, open && styles.open), "aria-hidden": "true", children: [_jsx("span", { className: clsx(styles.corner, styles['start-start']) }), _jsx("span", { className: clsx(styles.corner, styles['start-end']) }), _jsx("span", { className: clsx(styles.corner, styles['end-start']) }), _jsx("span", { className: clsx(styles.corner, styles['end-end']) }), _jsx("span", { className: styles.frame })] }));
}
