import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { useRef, useState } from 'react';
import clsx from 'clsx';
import { useResizeObserver } from '../../hooks/use-resize-observer';
import { cloudPath } from './path';
import styles from './styles.css.js';
/**
 * Circles its content with a scalloped outline, as a drawing marks a part that needs revising.
 * The outline is measured from the content box, so it keeps whole scallops at any size.
 */
export function RevisionCloud({ active, marker, className, children }) {
    const rootRef = useRef(null);
    const [size, setSize] = useState(null);
    useResizeObserver(rootRef, () => {
        const element = rootRef.current;
        if (!element) {
            return;
        }
        const width = element.offsetWidth;
        const height = element.offsetHeight;
        setSize(current => (current?.width === width && current.height === height ? current : { width, height }));
    });
    const path = active && size ? cloudPath(size.width, size.height) : '';
    return (_jsxs("div", { ref: rootRef, className: clsx(styles.root, active && styles.active, className), children: [children, path && (_jsx("svg", { className: styles.cloud, "aria-hidden": "true", focusable: "false", width: size.width, height: size.height, viewBox: `0 0 ${size.width} ${size.height}`, children: _jsx("path", { d: path }) })), active && marker && (_jsx("span", { className: styles.marker, "aria-hidden": "true", children: marker }))] }));
}
