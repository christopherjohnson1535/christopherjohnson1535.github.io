import { jsx as _jsx } from "react/jsx-runtime";
// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { useRef } from 'react';
import { InternalCheckbox } from '../../../checkbox/internal';
import { InternalRadioButton } from '../../../radio-button/internal';
import { fireNonCancelableEvent } from '../../events';
import styles from './styles.css.js';
/**
 * The checkbox or radio button of a selection cell. Clicks on the padding around the control count
 * too, so the whole cell is a target, and Shift is passed on for range selection.
 */
export function TableSelectionControl({ type, selected, indeterminate = false, disabled = false, name, ariaLabel, onChange, }) {
    const shiftKeyRef = useRef(false);
    const fire = (nextSelected) => fireNonCancelableEvent(onChange, { selected: nextSelected, shiftKey: shiftKeyRef.current });
    const handleClickCapture = (event) => {
        // A click made with the keyboard (Space) reports no modifiers, so keep the state seen on keydown.
        const fromKeyboard = event.detail === 0;
        shiftKeyRef.current = event.shiftKey || (fromKeyboard && shiftKeyRef.current);
    };
    const handleAreaClick = (event) => {
        if (!disabled && !(event.target instanceof HTMLInputElement)) {
            shiftKeyRef.current = event.shiftKey;
            fire(type === 'single' ? true : indeterminate || !selected);
        }
    };
    return (_jsx("span", { className: styles.root, onClickCapture: handleClickCapture, onClick: handleAreaClick, onKeyDownCapture: event => (shiftKeyRef.current = event.shiftKey), children: type === 'multi' ? (_jsx(InternalCheckbox, { checked: selected, indeterminate: indeterminate, disabled: disabled, ariaLabel: ariaLabel, onChange: event => fire(event.detail.checked) })) : (_jsx(InternalRadioButton, { checked: selected, name: name ?? '', disabled: disabled, ariaLabel: ariaLabel, onSelect: () => fire(true) })) }));
}
