import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import clsx from 'clsx';
import { InternalIcon } from '../../../icon/internal';
import styles from './styles.css.js';
/**
 * The button that opens the list of a select or multiselect and shows its value.
 */
export function SelectTrigger({ triggerRef, id, open, listId, disabled, readOnly, invalid, warning, ariaLabelledby, ariaDescribedby, contentId, children, onClick, onKeyDown, onKeyUp, }) {
    return (_jsxs("button", { ref: triggerRef, id: id, type: "button", className: clsx(styles.trigger, open && styles['trigger-open'], invalid && styles.invalid, warning && !invalid && styles.warning, readOnly && styles['read-only']), disabled: disabled, "aria-haspopup": "listbox", "aria-expanded": open, "aria-controls": open ? listId : undefined, "aria-labelledby": ariaLabelledby ? `${ariaLabelledby} ${contentId}` : undefined, "aria-describedby": ariaDescribedby, "aria-invalid": invalid ? 'true' : undefined, "aria-disabled": readOnly && !disabled ? 'true' : undefined, onClick: onClick, onKeyDown: onKeyDown, onKeyUp: onKeyUp, children: [_jsx("span", { id: contentId, className: styles['trigger-content'], children: children }), _jsx(InternalIcon, { className: styles['trigger-icon'], name: "chevron-down" })] }));
}
export function TriggerLabel({ children, lang, iconName, iconAriaLabel }) {
    return (_jsxs(_Fragment, { children: [iconName && _jsx(InternalIcon, { className: styles['trigger-label-icon'], name: iconName, ariaLabel: iconAriaLabel }), _jsx("span", { className: styles['trigger-label'], lang: lang, children: children })] }));
}
export function TriggerPlaceholder({ children }) {
    return _jsx("span", { className: styles.placeholder, children: children });
}
/**
 * The text input at the top of an open list that filters its options. It keeps focus while the
 * arrow keys move the highlight, so it points at the highlighted option.
 */
export function FilterInput({ filterRef, value, listId, activeDescendant, placeholder, ariaLabel, onChange, }) {
    return (_jsx("input", { ref: filterRef, className: styles['filter-input'], type: "text", role: "combobox", value: value, placeholder: placeholder, autoComplete: "off", "aria-label": ariaLabel, "aria-expanded": true, "aria-controls": listId, "aria-autocomplete": "list", "aria-activedescendant": activeDescendant, onChange: event => onChange(event.target.value) }));
}
