import { jsx as _jsx } from "react/jsx-runtime";
import clsx from 'clsx';
import styles from './styles.css.js';
/**
 * A full-width stripe of a website page. The background runs edge to edge while the content keeps
 * to a centered column, so bands stacked on one page line up. The inverted tone switches its content
 * to dark colors, which keeps text, links and buttons inside readable without variants of their own.
 */
export function Band({ tag: Tag = 'div', tone = 'default', width = 'default', spacing = 'default', className, innerClassName, children, ...rest }) {
    return (_jsx(Tag, { ...rest, className: clsx(styles.band, styles[`tone-${tone}`], styles[`spacing-${spacing}`], className), children: _jsx("div", { className: clsx(styles.inner, styles[`width-${width}`], innerClassName), children: children }) }));
}
