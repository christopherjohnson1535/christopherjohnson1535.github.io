// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { compareDays, compareMonths } from './arithmetic';
/**
 * Whether `date` lies within `min` and `max`, compared by day or by month.
 */
export function isWithinBounds(date, { min, max }, granularity = 'day') {
    const compare = granularity === 'month' ? compareMonths : compareDays;
    return (!min || compare(date, min) >= 0) && (!max || compare(date, max) <= 0);
}
/**
 * Whether the user may choose `date`: inside the bounds and not ruled out by `isDateEnabled`.
 */
export function isDateSelectable(date, constraints, granularity = 'day') {
    return isWithinBounds(date, constraints, granularity) && (constraints.isDateEnabled?.(date) ?? true);
}
