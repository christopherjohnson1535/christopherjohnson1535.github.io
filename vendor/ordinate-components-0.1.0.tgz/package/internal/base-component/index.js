// Copyright Christopher Johnson. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
// Every public component imports this module, so the revision tokens load once with the first component.
import './styles.css.js';
/**
 * Picks the props that may reach the root element. Styling props such as
 * `className` and `style` are deliberately not part of the public API.
 */
export function getBaseProps(props) {
    const baseProps = {};
    for (const [name, value] of Object.entries(props)) {
        if (name === 'id' || name.startsWith('data-')) {
            baseProps[name] = value;
        }
    }
    return baseProps;
}
