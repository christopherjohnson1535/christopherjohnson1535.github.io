function createCustomEvent(detail, cancelable) {
    return new CustomEvent('ordinate', { detail, cancelable });
}
export function fireNonCancelableEvent(handler, detail) {
    handler?.(createCustomEvent(detail, false));
}
/**
 * Calls `handler` with a cancelable event. When the handler calls
 * `preventDefault()`, the default action of `sourceEvent` is prevented too.
 * Returns whether the event was cancelled.
 */
export function fireCancelableEvent(handler, detail, sourceEvent) {
    if (!handler) {
        return false;
    }
    const event = createCustomEvent(detail, true);
    handler(event);
    if (event.defaultPrevented) {
        sourceEvent?.preventDefault();
    }
    return event.defaultPrevented;
}
/**
 * Calls `handler` with the key and modifiers of a React keyboard event.
 * Calling `preventDefault()` in the handler prevents the native default.
 */
export function fireKeyboardEvent(handler, event) {
    const { key, ctrlKey, shiftKey, altKey, metaKey } = event;
    return fireCancelableEvent(handler, { key, ctrlKey, shiftKey, altKey, metaKey, isComposing: event.nativeEvent.isComposing }, event);
}
